/**
 * Group Admin — Meeting Attendance & Lateness Fines
 *
 * IMPORTANT DESIGN PRINCIPLES:
 * - Attendance is recorded manually by an authorized admin — NOT auto-imposed from digital check-in.
 * - A fine is only generated after admin review, not automatically on absence alone.
 * - Admins can correct attendance records with a reason.
 * - Members can dispute fines.
 */

import React, { useState } from 'react'
import { motion } from 'framer-motion'
import {
  Calendar, Users, Clock, CheckCircle, XCircle, AlertTriangle,
  Edit, Plus, ChevronDown, ChevronUp, Save, AlertCircle
} from 'lucide-react'
import { PageHeader } from '@/components/shared/PageHeader'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Switch } from '@/components/ui/switch'
import { Separator } from '@/components/ui/separator'
import { formatDate, getInitials } from '@/lib/utils'
import { toast } from 'sonner'
import type { MeetingAttendanceRecord } from '@/types'

const meetings = [
  {
    id: 'm1',
    title: 'August Monthly Meeting',
    scheduled_at: '2026-08-15T10:00:00',
    venue: 'Community Hall, Nairobi',
    status: 'completed',
    grace_period_minutes: 15,
    lateness_fine_amount: 50,
    absence_fine_amount: 300,
    requires_approval: true,
  },
  {
    id: 'm2',
    title: 'July Monthly Meeting',
    scheduled_at: '2026-07-18T10:00:00',
    venue: 'Community Hall, Nairobi',
    status: 'completed',
    grace_period_minutes: 15,
    lateness_fine_amount: 50,
    absence_fine_amount: 300,
    requires_approval: true,
  },
]

const memberList = [
  { id: 'm1', name: 'Alice Wanjiku', number: 'PAM-0001' },
  { id: 'm2', name: 'Bob Kipchoge', number: 'PAM-0002' },
  { id: 'm3', name: 'Carol Achieng', number: 'PAM-0003' },
  { id: 'm4', name: 'David Mwenda', number: 'PAM-0004' },
  { id: 'm5', name: 'Eva Njoki', number: 'PAM-0005' },
]

type AttendanceStatus = 'present' | 'absent' | 'excused' | 'late'

const initialAttendance: Record<string, AttendanceStatus> = {
  m1: 'present', m2: 'late', m3: 'present', m4: 'absent', m5: 'excused',
}

const arrivalTimes: Record<string, string> = {
  m1: '10:08', m2: '10:31', m3: '10:05',
}

export function MeetingAttendancePage() {
  const [selectedMeeting, setSelectedMeeting] = useState(meetings[0])
  const [attendance, setAttendance] = useState<Record<string, AttendanceStatus>>(initialAttendance)
  const [correctionOpen, setCorrectionOpen] = useState(false)
  const [correctionMember, setCorrectionMember] = useState<typeof memberList[0] | null>(null)
  const [correctionReason, setCorrectionReason] = useState('')
  const [correctionStatus, setCorrectionStatus] = useState<AttendanceStatus>('present')
  const [savingAttendance, setSavingAttendance] = useState(false)
  const [fineRulesOpen, setFineRulesOpen] = useState(false)
  const [gracePeriod, setGracePeriod] = useState(String(selectedMeeting.grace_period_minutes))
  const [latenessFine, setLatenessFine] = useState(String(selectedMeeting.lateness_fine_amount))
  const [absenceFine, setAbsenceFine] = useState(String(selectedMeeting.absence_fine_amount))
  const [requiresApproval, setRequiresApproval] = useState(selectedMeeting.requires_approval)

  const presentCount = Object.values(attendance).filter(s => s === 'present').length
  const lateCount = Object.values(attendance).filter(s => s === 'late').length
  const absentCount = Object.values(attendance).filter(s => s === 'absent').length
  const excusedCount = Object.values(attendance).filter(s => s === 'excused').length

  // Fines that would be generated
  const pendingFines = memberList.filter(m => {
    const s = attendance[m.id]
    return s === 'absent' || s === 'late'
  })

  const handleSaveAttendance = async () => {
    setSavingAttendance(true)
    await new Promise(r => setTimeout(r, 1200))
    setSavingAttendance(false)
    toast.success('Attendance saved', {
      description: `${presentCount + lateCount} present, ${absentCount} absent, ${excusedCount} excused.`,
    })
  }

  const handleGenerateFines = async () => {
    if (pendingFines.length === 0) {
      toast.info('No fines to generate for this meeting')
      return
    }
    await new Promise(r => setTimeout(r, 800))
    toast.success(`${pendingFines.length} fine(s) generated for review`, {
      description: requiresApproval
        ? 'Fines are in pending_approval status. Approve them before members are notified.'
        : 'Fines approved and members notified.',
    })
  }

  const openCorrection = (member: typeof memberList[0]) => {
    setCorrectionMember(member)
    setCorrectionStatus(attendance[member.id] ?? 'present')
    setCorrectionReason('')
    setCorrectionOpen(true)
  }

  const saveCorrection = async () => {
    if (!correctionReason.trim()) {
      toast.error('A reason is required for attendance corrections')
      return
    }
    if (correctionMember) {
      setAttendance(prev => ({ ...prev, [correctionMember.id]: correctionStatus }))
    }
    setCorrectionOpen(false)
    toast.success('Attendance corrected', { description: correctionReason })
  }

  const statusColors: Record<AttendanceStatus, string> = {
    present: 'success',
    late: 'warning',
    absent: 'destructive',
    excused: 'secondary',
  }

  const statusIcons: Record<AttendanceStatus, React.ReactNode> = {
    present: <CheckCircle className="h-4 w-4 text-emerald-500" />,
    late: <Clock className="h-4 w-4 text-yellow-500" />,
    absent: <XCircle className="h-4 w-4 text-red-500" />,
    excused: <AlertCircle className="h-4 w-4 text-gray-400" />,
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Meeting Attendance & Fines"
        description="Record attendance and manage lateness or absence fines"
        actions={
          <Button variant="outline" onClick={() => setFineRulesOpen(true)}>
            <AlertTriangle className="h-4 w-4" /> Fine Rules
          </Button>
        }
      />

      {/* Important notice */}
      <Card className="border-blue-200 bg-blue-50 dark:bg-blue-950/20">
        <CardContent className="p-4 flex gap-3">
          <AlertCircle className="h-5 w-5 text-blue-600 shrink-0 mt-0.5" />
          <div className="text-sm text-blue-700 dark:text-blue-400 space-y-1">
            <p className="font-semibold">Attendance and fine policy</p>
            <p>Fines are only generated after manual admin review — not automatically from digital check-in data.
            All corrections require a reason and are logged. Members can dispute any fine they believe is incorrect.</p>
          </div>
        </CardContent>
      </Card>

      {/* Meeting selector */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-4 flex-wrap">
            <Label className="shrink-0">Select Meeting:</Label>
            <Select
              value={selectedMeeting.id}
              onValueChange={id => setSelectedMeeting(meetings.find(m => m.id === id) ?? meetings[0])}
            >
              <SelectTrigger className="w-64">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {meetings.map(m => (
                  <SelectItem key={m.id} value={m.id}>
                    {m.title} — {formatDate(m.scheduled_at)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Badge variant={selectedMeeting.status === 'completed' ? 'success' : 'info'} className="capitalize">
              {selectedMeeting.status}
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Summary stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: 'Present', count: presentCount, color: 'text-emerald-600', bg: 'bg-emerald-50 dark:bg-emerald-950/20' },
          { label: 'Late', count: lateCount, color: 'text-yellow-600', bg: 'bg-yellow-50 dark:bg-yellow-950/20' },
          { label: 'Absent', count: absentCount, color: 'text-red-600', bg: 'bg-red-50 dark:bg-red-950/20' },
          { label: 'Excused', count: excusedCount, color: 'text-gray-500', bg: 'bg-gray-50 dark:bg-gray-950/20' },
        ].map(stat => (
          <div key={stat.label} className={`rounded-xl p-4 text-center ${stat.bg}`}>
            <p className={`text-3xl font-bold ${stat.color}`}>{stat.count}</p>
            <p className="text-sm text-muted-foreground">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Attendance register */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <CardTitle className="text-base">Attendance Register</CardTitle>
              <CardDescription>
                {selectedMeeting.title} · Grace period: {selectedMeeting.grace_period_minutes} min after scheduled time
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Button onClick={handleSaveAttendance} loading={savingAttendance} variant="outline" size="sm">
                <Save className="h-4 w-4" /> Save
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="divide-y divide-border">
            {memberList.map(member => {
              const status = attendance[member.id] ?? 'absent'
              const arrivalTime = arrivalTimes[member.id]
              const isLate = status === 'late'
              const fineAmount = status === 'late' ? selectedMeeting.lateness_fine_amount : status === 'absent' ? selectedMeeting.absence_fine_amount : 0

              return (
                <div key={member.id} className="flex items-center gap-4 py-3 first:pt-0 last:pb-0 flex-wrap">
                  <Avatar className="h-9 w-9 shrink-0">
                    <AvatarFallback className="text-xs">{getInitials(member.name)}</AvatarFallback>
                  </Avatar>

                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm">{member.name}</p>
                    <p className="text-xs text-muted-foreground">{member.number}</p>
                    {arrivalTime && (
                      <p className="text-xs text-muted-foreground">
                        Arrived: {arrivalTime}
                        {isLate && <span className="text-yellow-600 ml-1">(late)</span>}
                      </p>
                    )}
                  </div>

                  <Select
                    value={status}
                    onValueChange={(v) => setAttendance(prev => ({ ...prev, [member.id]: v as AttendanceStatus }))}
                  >
                    <SelectTrigger className="w-32 h-8 text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="present">✅ Present</SelectItem>
                      <SelectItem value="late">🕐 Late</SelectItem>
                      <SelectItem value="absent">❌ Absent</SelectItem>
                      <SelectItem value="excused">🟡 Excused</SelectItem>
                    </SelectContent>
                  </Select>

                  {fineAmount > 0 && (
                    <span className="text-xs text-destructive font-medium shrink-0">
                      Fine: KSh {fineAmount}
                    </span>
                  )}

                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 shrink-0"
                    onClick={() => openCorrection(member)}
                    title="Correct attendance with reason"
                  >
                    <Edit className="h-3.5 w-3.5" />
                  </Button>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Generate fines */}
      {pendingFines.length > 0 && (
        <Card className="border-orange-200 bg-orange-50 dark:bg-orange-950/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div>
                <p className="font-semibold text-orange-800 dark:text-orange-300">
                  {pendingFines.length} fine(s) ready to generate
                </p>
                <div className="flex flex-wrap gap-2 mt-1">
                  {pendingFines.map(m => (
                    <span key={m.id} className="text-xs bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-400 px-2 py-0.5 rounded-full">
                      {m.name} ({attendance[m.id]}) — KSh {attendance[m.id] === 'late' ? selectedMeeting.lateness_fine_amount : selectedMeeting.absence_fine_amount}
                    </span>
                  ))}
                </div>
                {requiresApproval && (
                  <p className="text-xs text-orange-600 mt-1">Fines will be created in pending_approval status and require your review before members are notified.</p>
                )}
              </div>
              <Button onClick={handleGenerateFines} variant="default" size="sm">
                <AlertTriangle className="h-4 w-4" /> Generate Fines for Review
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Attendance correction dialog */}
      <Dialog open={correctionOpen} onOpenChange={setCorrectionOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Correct Attendance Record</DialogTitle>
            <DialogDescription>
              Corrections require a reason and are permanently logged in the audit trail.
            </DialogDescription>
          </DialogHeader>
          {correctionMember && (
            <div className="space-y-4 py-2">
              <div className="flex items-center gap-3 p-3 bg-muted/40 rounded-lg">
                <Avatar className="h-9 w-9"><AvatarFallback>{getInitials(correctionMember.name)}</AvatarFallback></Avatar>
                <div>
                  <p className="font-medium text-sm">{correctionMember.name}</p>
                  <p className="text-xs text-muted-foreground">Current: <span className="capitalize">{attendance[correctionMember.id]}</span></p>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Correct Status To</Label>
                <Select value={correctionStatus} onValueChange={v => setCorrectionStatus(v as AttendanceStatus)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="present">Present</SelectItem>
                    <SelectItem value="late">Late</SelectItem>
                    <SelectItem value="absent">Absent</SelectItem>
                    <SelectItem value="excused">Excused</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Reason for Correction <span className="text-destructive">*</span></Label>
                <Input
                  placeholder="e.g. Member's check-in was not captured by the system"
                  value={correctionReason}
                  onChange={e => setCorrectionReason(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">This reason is recorded in the audit log and visible to the Super Admin.</p>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setCorrectionOpen(false)}>Cancel</Button>
            <Button onClick={saveCorrection}>Save Correction</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Fine rules dialog */}
      <Dialog open={fineRulesOpen} onOpenChange={setFineRulesOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Meeting Fine Rules</DialogTitle>
            <DialogDescription>
              Configure fine rules for this group. Changes apply to future meetings only.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label>Grace Period (minutes)</Label>
              <Input type="number" min="0" max="60" value={gracePeriod} onChange={e => setGracePeriod(e.target.value)} />
              <p className="text-xs text-muted-foreground">Members arriving within this time of the scheduled start are not marked late</p>
            </div>
            <div className="space-y-2">
              <Label>Lateness Fine Amount (KSh)</Label>
              <Input type="number" min="0" value={latenessFine} onChange={e => setLatenessFine(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Absence Fine Amount (KSh)</Label>
              <Input type="number" min="0" value={absenceFine} onChange={e => setAbsenceFine(e.target.value)} />
            </div>
            <div className="flex items-center justify-between p-3 rounded-lg border">
              <div>
                <p className="text-sm font-medium">Require Approval Before Notifying</p>
                <p className="text-xs text-muted-foreground">Admins review generated fines before members see them</p>
              </div>
              <Switch checked={requiresApproval} onCheckedChange={setRequiresApproval} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setFineRulesOpen(false)}>Cancel</Button>
            <Button onClick={() => { setFineRulesOpen(false); toast.success('Fine rules saved') }}>Save Rules</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
