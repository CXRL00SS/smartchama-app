/**
 * JoinGroupPage — Members browse and join Chama groups in their area.
 */

import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { Search, MapPin, Users, Wallet, CheckCircle, Lock } from 'lucide-react'
import { PageHeader } from '@/components/shared/PageHeader'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { formatCurrency } from '@/lib/utils'
import { toast } from 'sonner'

// Mock available groups — in production fetched from Firestore
const availableGroups = [
  {
    id: 'g1',
    name: 'Pamoja Savings Group',
    location: 'Westlands, Nairobi',
    area: 'Nairobi',
    members: 47,
    max_members: 50,
    monthly_contribution: 5000,
    total_savings: 2450000,
    description: 'A community savings group for Westlands residents focused on financial growth.',
    chairperson: 'Jane Mwangi',
    registration_fee: 500,
    is_open: true,
  },
  {
    id: 'g2',
    name: 'Amani Chama',
    location: 'Mombasa CBD',
    area: 'Mombasa',
    members: 32,
    max_members: 40,
    monthly_contribution: 3000,
    total_savings: 1800000,
    description: 'Coastal savings group helping members achieve financial independence.',
    chairperson: 'Ahmed Omar',
    registration_fee: 300,
    is_open: true,
  },
  {
    id: 'g3',
    name: 'Nguvu Savings',
    location: 'Nakuru Town',
    area: 'Nakuru',
    members: 58,
    max_members: 60,
    monthly_contribution: 4000,
    total_savings: 3200000,
    description: 'One of the largest Chamas in Nakuru with a proven track record.',
    chairperson: 'Peter Njoroge',
    registration_fee: 400,
    is_open: false, // Full
  },
  {
    id: 'g4',
    name: 'Faida Group',
    location: 'Kisumu',
    area: 'Kisumu',
    members: 25,
    max_members: 40,
    monthly_contribution: 2000,
    total_savings: 980000,
    description: 'A young and growing Chama in Kisumu welcoming new members.',
    chairperson: 'Mary Otieno',
    registration_fee: 200,
    is_open: true,
  },
  {
    id: 'g5',
    name: 'Maendeleo Chama',
    location: 'Eldoret',
    area: 'Eldoret',
    members: 18,
    max_members: 30,
    monthly_contribution: 2500,
    total_savings: 450000,
    description: 'Eldoret\'s fastest growing savings group for young professionals.',
    chairperson: 'Samuel Kibet',
    registration_fee: 250,
    is_open: true,
  },
]

const areas = ['All Areas', 'Nairobi', 'Mombasa', 'Kisumu', 'Nakuru', 'Eldoret']

export function JoinGroupPage() {
  const [search, setSearch] = useState('')
  const [selectedArea, setSelectedArea] = useState('All Areas')
  const [selectedGroup, setSelectedGroup] = useState<typeof availableGroups[0] | null>(null)
  const [joinDialogOpen, setJoinDialogOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [joinedGroups, setJoinedGroups] = useState<string[]>([])

  const filtered = availableGroups.filter(g => {
    const matchesSearch = g.name.toLowerCase().includes(search.toLowerCase()) ||
      g.location.toLowerCase().includes(search.toLowerCase())
    const matchesArea = selectedArea === 'All Areas' || g.area === selectedArea
    return matchesSearch && matchesArea
  })

  const handleJoinRequest = async () => {
    if (!selectedGroup) return
    setLoading(true)
    // In production: create a join request in Firestore, notify chairperson
    await new Promise(r => setTimeout(r, 1500))
    setLoading(false)
    setJoinedGroups(prev => [...prev, selectedGroup.id])
    setJoinDialogOpen(false)
    toast.success('Join request sent!', {
      description: `Your request to join ${selectedGroup.name} has been sent to the Chairperson.`,
    })
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Browse Groups"
        description="Find and join a Chama group in your area"
      />

      {/* Search and filter */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by group name or location..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          {areas.map(area => (
            <button
              key={area}
              onClick={() => setSelectedArea(area)}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors border
                ${selectedArea === area
                  ? 'bg-primary text-primary-foreground border-primary'
                  : 'bg-background border-border text-muted-foreground hover:text-foreground hover:border-primary/50'
                }`}
            >
              {area}
            </button>
          ))}
        </div>
      </div>

      {/* Results count */}
      <p className="text-sm text-muted-foreground">
        {filtered.length} group{filtered.length !== 1 ? 's' : ''} found
      </p>

      {/* Group cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((group, i) => {
          const isJoined = joinedGroups.includes(group.id)
          const isFull = !group.is_open
          const capacityPct = (group.members / group.max_members) * 100

          return (
            <motion.div
              key={group.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <Card className={`overflow-hidden transition-all ${isFull ? 'opacity-70' : 'hover:shadow-md'}`}>
                <CardContent className="p-5">
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div>
                      <h3 className="font-semibold text-foreground">{group.name}</h3>
                      <div className="flex items-center gap-1 text-xs text-muted-foreground mt-0.5">
                        <MapPin className="h-3 w-3" />
                        {group.location}
                      </div>
                    </div>
                    <div className="shrink-0">
                      {isJoined ? (
                        <Badge variant="success">Requested</Badge>
                      ) : isFull ? (
                        <Badge variant="secondary">
                          <Lock className="h-3 w-3 mr-1" /> Full
                        </Badge>
                      ) : (
                        <Badge variant="info">Open</Badge>
                      )}
                    </div>
                  </div>

                  <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{group.description}</p>

                  {/* Stats */}
                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div className="bg-muted/40 rounded-lg p-2.5">
                      <p className="text-xs text-muted-foreground">Monthly</p>
                      <p className="font-semibold text-sm">{formatCurrency(group.monthly_contribution)}</p>
                    </div>
                    <div className="bg-muted/40 rounded-lg p-2.5">
                      <p className="text-xs text-muted-foreground">Total Savings</p>
                      <p className="font-semibold text-sm">{formatCurrency(group.total_savings)}</p>
                    </div>
                  </div>

                  {/* Members progress */}
                  <div className="mb-4">
                    <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
                      <span className="flex items-center gap-1">
                        <Users className="h-3 w-3" />
                        {group.members} / {group.max_members} members
                      </span>
                      <span>{Math.round(capacityPct)}% full</span>
                    </div>
                    <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all ${capacityPct >= 90 ? 'bg-red-500' : capacityPct >= 70 ? 'bg-yellow-500' : 'bg-emerald-500'}`}
                        style={{ width: `${capacityPct}%` }}
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="text-xs text-muted-foreground">
                      <span>Chairperson: </span>
                      <span className="font-medium text-foreground">{group.chairperson}</span>
                    </div>
                    <Button
                      size="sm"
                      disabled={isFull || isJoined}
                      onClick={() => { setSelectedGroup(group); setJoinDialogOpen(true) }}
                      variant={isJoined ? 'outline' : 'default'}
                    >
                      {isJoined ? (
                        <><CheckCircle className="h-3.5 w-3.5" /> Requested</>
                      ) : isFull ? (
                        <><Lock className="h-3.5 w-3.5" /> Full</>
                      ) : (
                        'Request to Join'
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )
        })}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-16">
          <Search className="h-12 w-12 text-muted-foreground/30 mx-auto mb-4" />
          <p className="text-muted-foreground font-medium">No groups found</p>
          <p className="text-muted-foreground/70 text-sm mt-1">Try a different location or search term</p>
        </div>
      )}

      {/* Join request dialog */}
      <Dialog open={joinDialogOpen} onOpenChange={setJoinDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Request to Join {selectedGroup?.name}</DialogTitle>
          </DialogHeader>
          {selectedGroup && (
            <div className="space-y-4 py-2">
              <div className="rounded-lg bg-muted/50 p-4 space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Location</span>
                  <span className="font-medium">{selectedGroup.location}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Monthly Contribution</span>
                  <span className="font-semibold">{formatCurrency(selectedGroup.monthly_contribution)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Registration Fee</span>
                  <span className="font-semibold">{formatCurrency(selectedGroup.registration_fee)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Chairperson</span>
                  <span>{selectedGroup.chairperson}</span>
                </div>
              </div>
              <p className="text-sm text-muted-foreground">
                Your request will be sent to the Chairperson for approval. Once approved, you will receive a notification.
              </p>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setJoinDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleJoinRequest} loading={loading}>
              Send Join Request
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
