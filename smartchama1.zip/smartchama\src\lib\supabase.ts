// This file is kept for backward compatibility.
// The app now uses Firebase — see src/lib/firebase.ts
export {}
