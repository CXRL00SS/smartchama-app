import React from 'react'
import { FileText, Download, Eye, FolderOpen } from 'lucide-react'
import { PageHeader } from '@/components/shared/PageHeader'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { formatDate, formatFileSize } from '@/lib/utils'
import type { Document } from '@/types'

const documents: Document[] = [
  { id: 'd1', group_id: 'g1', name: 'Group Constitution 2026', description: 'Official constitution and bylaws', file_url: '#', file_size: 512000, file_type: 'application/pdf', category: 'constitution', uploaded_by: 'u1', created_at: '2026-01-15', download_count: 45 },
  { id: 'd2', group_id: 'g1', name: 'July 2026 Meeting Minutes', description: 'Minutes from the July monthly meeting', file_url: '#', file_size: 102400, file_type: 'application/pdf', category: 'minutes', uploaded_by: 'u1', created_at: '2026-07-20', download_count: 28 },
  { id: 'd3', group_id: 'g1', name: 'H1 2026 Financial Report', description: 'Financial statements for Jan–June 2026', file_url: '#', file_size: 1048576, file_type: 'application/pdf', category: 'financial', uploaded_by: 'u1', created_at: '2026-07-10', download_count: 32 },
  { id: 'd4', group_id: 'g1', name: 'Loan Policy 2026', description: 'Updated loan rules and procedures', file_url: '#', file_size: 204800, file_type: 'application/pdf', category: 'policy', uploaded_by: 'u1', created_at: '2026-02-01', download_count: 58 },
]

const categoryColors: Record<string, string> = {
  constitution: 'primary',
  minutes: 'info',
  financial: 'success',
  policy: 'gold',
  rules: 'secondary',
  other: 'secondary',
}

const categoryIcon = <FileText className="h-5 w-5 text-primary" />

export function DocumentsPage() {
  const categories = ['constitution', 'minutes', 'financial', 'policy', 'other'] as const

  return (
    <div className="space-y-6">
      <PageHeader title="Documents" description="Group documents and reports" />

      {categories.map(cat => {
        const docs = documents.filter(d => d.category === cat)
        if (docs.length === 0) return null
        return (
          <Card key={cat}>
            <CardHeader>
              <CardTitle className="text-base capitalize flex items-center gap-2">
                <FolderOpen className="h-4 w-4 text-primary" />
                {cat.replace('_', ' ')}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="divide-y divide-border">
                {docs.map(doc => (
                  <div key={doc.id} className="flex items-center gap-4 py-3 first:pt-0 last:pb-0">
                    <div className="p-2 rounded-lg bg-primary/10 shrink-0">{categoryIcon}</div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm">{doc.name}</p>
                      {doc.description && <p className="text-xs text-muted-foreground">{doc.description}</p>}
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs text-muted-foreground">{formatDate(doc.created_at)}</span>
                        <span className="text-xs text-muted-foreground">·</span>
                        <span className="text-xs text-muted-foreground">{formatFileSize(doc.file_size)}</span>
                        <span className="text-xs text-muted-foreground">·</span>
                        <span className="text-xs text-muted-foreground">{doc.download_count} downloads</span>
                      </div>
                    </div>
                    <div className="flex gap-2 shrink-0">
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm">
                        <Download className="h-3.5 w-3.5" /> Download
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
