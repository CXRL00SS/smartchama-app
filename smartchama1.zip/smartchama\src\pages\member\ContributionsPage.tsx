import React, { useState } from 'react'
import { CheckCircle, Clock, XCircle, CreditCard, Download, Plus } from 'lucide-react'
import { PageHeader } from '@/components/shared/PageHeader'
import { DataTable, Column } from '@/components/shared/DataTable'
import { StatsCard } from '@/components/shared/StatsCard'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { formatCurrency, formatDate } from '@/lib/utils'
import type { Contribution } from '@/types'
import { toast } from 'sonner'

// Mock data
const mockContributions: Contribution[] = [
  { id: '1', group_id: 'g1', member_id: 'm1', amount: 5000, due_date: '2026-07-31', paid_date: '2026-07-30', status: 'paid', payment_method: 'mpesa', transaction_ref: 'QJH7X3', created_at: '2026-07-01' },
  { id: '2', group_id: 'g1', member_id: 'm1', amount: 5000, due_date: '2026-06-30', paid_date: '2026-06-28', status: 'paid', payment_method: 'mpesa', transaction_ref: 'PLK2M9', created_at: '2026-06-01' },
  { id: '3', group_id: 'g1', member_id: 'm1', amount: 5000, due_date: '2026-05-31', paid_date: '2026-06-03', status: 'late', payment_method: 'mpesa', late_penalty: 500, transaction_ref: 'NMP4K1', created_at: '2026-05-01' },
  { id: '4', group_id: 'g1', member_id: 'm1', amount: 5000, due_date: '2026-08-31', status: 'pending', created_at: '2026-08-01' },
]

const statusBadge: Record<string, React.ReactNode> = {
  paid: <Badge variant="success">Paid</Badge>,
  pending: <Badge variant="warning">Pending</Badge>,
  late: <Badge variant="destructive">Late</Badge>,
  waived: <Badge variant="info">Waived</Badge>,
}

export function ContributionsPage() {
  const [payDialogOpen, setPayDialogOpen] = useState(false)
  const [selectedContribution, setSelectedContribution] = useState<Contribution | null>(null)
  const [phone, setPhone] = useState('')
  const [loading, setLoading] = useState(false)

  const columns: Column<Contribution>[] = [
    {
      key: 'due_date',
      header: 'Period',
      sortable: true,
      render: (val) => formatDate(val as string),
    },
    {
      key: 'amount',
      header: 'Amount',
      sortable: true,
      render: (val) => formatCurrency(val as number),
    },
    {
      key: 'status',
      header: 'Status',
      render: (val) => statusBadge[val as string] ?? <Badge>{String(val)}</Badge>,
    },
    {
      key: 'paid_date',
      header: 'Paid Date',
      render: (val) => val ? formatDate(val as string) : '—',
    },
    {
      key: 'payment_method',
      header: 'Method',
      render: (val) => val ? <span className="capitalize">{String(val).replace('_', ' ')}</span> : '—',
    },
    {
      key: 'late_penalty',
      header: 'Fine',
      render: (val) => val ? <span className="text-destructive">{formatCurrency(val as number)}</span> : '—',
    },
    {
      key: 'transaction_ref',
      header: 'Reference',
      render: (val) => val ? <code className="text-xs bg-muted px-1.5 py-0.5 rounded">{String(val)}</code> : '—',
    },
    {
      key: 'id',
      header: 'Action',
      render: (_, row) =>
        row.status === 'pending' ? (
          <Button size="sm" onClick={() => { setSelectedContribution(row); setPayDialogOpen(true) }}>
            <CreditCard className="h-3 w-3" /> Pay Now
          </Button>
        ) : (
          <Button size="sm" variant="outline">
            <Download className="h-3 w-3" /> Receipt
          </Button>
        ),
    },
  ]

  const handlePay = async () => {
    if (!phone.trim()) { toast.error('Enter your M-Pesa phone number'); return }
    setLoading(true)
    // Simulate M-Pesa STK push
    await new Promise(r => setTimeout(r, 2000))
    setLoading(false)
    setPayDialogOpen(false)
    toast.success('M-Pesa prompt sent!', {
      description: `Check your phone (${phone}) to complete payment.`,
    })
  }

  const paid = mockContributions.filter(c => c.status === 'paid').length
  const total = mockContributions.length
  const totalPaid = mockContributions.filter(c => c.status === 'paid').reduce((s, c) => s + c.amount, 0)
  const totalPending = mockContributions.filter(c => c.status === 'pending').reduce((s, c) => s + c.amount, 0)

  return (
    <div className="space-y-6">
      <PageHeader
        title="My Contributions"
        description="Track your contribution history and make payments"
        actions={
          <Button onClick={() => { setSelectedContribution(mockContributions.find(c => c.status === 'pending') || null); setPayDialogOpen(true) }}>
            <Plus className="h-4 w-4" /> Pay Contribution
          </Button>
        }
      />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatsCard title="Total Paid" value={formatCurrency(totalPaid)} icon={CheckCircle} variant="success" description={`${paid} of ${total} contributions`} />
        <StatsCard title="Pending" value={formatCurrency(totalPending)} icon={Clock} variant="warning" />
        <StatsCard title="Compliance Rate" value={`${Math.round((paid / total) * 100)}%`} icon={CheckCircle} variant="primary" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Contribution History</CardTitle>
        </CardHeader>
        <CardContent>
          <DataTable
            data={mockContributions as unknown as Record<string, unknown>[]}
            columns={columns as unknown as Column<Record<string, unknown>>[]}
            searchable={false}
          />
        </CardContent>
      </Card>

      {/* Pay Dialog */}
      <Dialog open={payDialogOpen} onOpenChange={setPayDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Pay Contribution via M-Pesa</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="rounded-lg bg-muted/50 p-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Contribution Amount</span>
                <span className="font-semibold">{formatCurrency(selectedContribution?.amount ?? 5000)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Due Date</span>
                <span>{selectedContribution?.due_date ? formatDate(selectedContribution.due_date) : '—'}</span>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="mpesa-phone">M-Pesa Phone Number</Label>
              <Input
                id="mpesa-phone"
                type="tel"
                placeholder="0712 345 678"
                value={phone}
                onChange={e => setPhone(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">You will receive a push notification to confirm payment</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPayDialogOpen(false)}>Cancel</Button>
            <Button onClick={handlePay} loading={loading} className="bg-[#00A550] hover:bg-[#008C44]">
              <CreditCard className="h-4 w-4" /> Send STK Push
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
