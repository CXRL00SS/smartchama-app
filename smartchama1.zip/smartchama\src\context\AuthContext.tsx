import React, { createContext, useContext, useEffect, useState, useCallback } from 'react'
import {
  User,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut as firebaseSignOut,
  updateProfile,
  signInWithPopup,
  sendPasswordResetEmail,
} from 'firebase/auth'
import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  serverTimestamp,
} from 'firebase/firestore'
import { auth, db, googleProvider } from '@/lib/firebase'
import type { Profile, UserRole } from '@/types'

interface AuthContextType {
  user: User | null
  profile: Profile | null
  role: UserRole | null
  loading: boolean
  signIn: (email: string, password: string) => Promise<{ error: string | null }>
  signUp: (email: string, password: string, fullName: string, phone?: string) => Promise<{ error: string | null }>
  signInWithGoogle: () => Promise<{ error: string | null }>
  signOut: () => Promise<void>
  resetPassword: (email: string) => Promise<{ error: string | null }>
  refreshProfile: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)

  const fetchProfile = useCallback(async (uid: string) => {
    try {
      const snap = await getDoc(doc(db, 'profiles', uid))
      if (snap.exists()) {
        const data = snap.data()
        // Auto-elevate super admin email
        const SUPER_ADMIN_EMAIL = import.meta.env.VITE_SUPER_ADMIN_EMAIL || 'admin@smartchama.co.ke'
        if (data.email?.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase() && data.role !== 'super_admin') {
          await updateDoc(doc(db, 'profiles', uid), { role: 'super_admin' })
          data.role = 'super_admin'
        }
        setProfile({ id: uid, ...data } as Profile)
      }
    } catch (err) {
      console.error('Failed to fetch profile:', err)
    }
  }, [])

  const refreshProfile = useCallback(async () => {
    if (user) await fetchProfile(user.uid)
  }, [user, fetchProfile])

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser)
      if (firebaseUser) {
        await fetchProfile(firebaseUser.uid)
      } else {
        setProfile(null)
      }
      setLoading(false)
    })
    return unsubscribe
  }, [fetchProfile])

  const signIn = async (email: string, password: string) => {
    try {
      await signInWithEmailAndPassword(auth, email, password)
      return { error: null }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Sign in failed'
      return { error: friendlyError(msg) }
    }
  }

  const signUp = async (email: string, password: string, fullName: string, phone?: string) => {
    // Block super_admin email from self-registering
    const SUPER_ADMIN_EMAIL = import.meta.env.VITE_SUPER_ADMIN_EMAIL || 'admin@smartchama.co.ke'
    if (email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase()) {
      return { error: 'This email is reserved. Contact platform support.' }
    }

    try {
      const { user: newUser } = await createUserWithEmailAndPassword(auth, email, password)
      await updateProfile(newUser, { displayName: fullName })

      // Create Firestore profile document
      await setDoc(doc(db, 'profiles', newUser.uid), {
        email,
        full_name: fullName,
        phone: phone || null,
        role: 'member',
        is_verified: false,
        is_active: true,
        credit_score: 500,
        wallet_balance: 0,
        created_at: serverTimestamp(),
        updated_at: serverTimestamp(),
      })

      return { error: null }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Sign up failed'
      return { error: friendlyError(msg) }
    }
  }

  const signInWithGoogle = async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider)
      const newUser = result.user

      // Create profile if first time
      const snap = await getDoc(doc(db, 'profiles', newUser.uid))
      if (!snap.exists()) {
        await setDoc(doc(db, 'profiles', newUser.uid), {
          email: newUser.email,
          full_name: newUser.displayName || 'User',
          phone: newUser.phoneNumber || null,
          avatar_url: newUser.photoURL || null,
          role: 'member',
          is_verified: true,
          is_active: true,
          credit_score: 500,
          wallet_balance: 0,
          created_at: serverTimestamp(),
          updated_at: serverTimestamp(),
        })
      }

      return { error: null }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Google sign in failed'
      return { error: friendlyError(msg) }
    }
  }

  const resetPassword = async (email: string) => {
    try {
      await sendPasswordResetEmail(auth, email)
      return { error: null }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Reset failed'
      return { error: friendlyError(msg) }
    }
  }

  const signOut = async () => {
    await firebaseSignOut(auth)
    setProfile(null)
  }

  const role = profile?.role ?? null

  return (
    <AuthContext.Provider value={{
      user, profile, role, loading,
      signIn, signUp, signInWithGoogle, signOut, resetPassword, refreshProfile,
    }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider')
  return ctx
}

// Convert Firebase error codes to friendly messages
function friendlyError(msg: string): string {
  if (msg.includes('user-not-found') || msg.includes('wrong-password') || msg.includes('invalid-credential'))
    return 'Invalid email or password'
  if (msg.includes('email-already-in-use'))
    return 'An account with this email already exists'
  if (msg.includes('weak-password'))
    return 'Password must be at least 6 characters'
  if (msg.includes('invalid-email'))
    return 'Please enter a valid email address'
  if (msg.includes('too-many-requests'))
    return 'Too many attempts. Please try again later'
  if (msg.includes('network-request-failed'))
    return 'Network error. Check your internet connection'
  return msg
}
