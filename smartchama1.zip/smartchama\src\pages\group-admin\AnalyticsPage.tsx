import React, { useState } from 'react'
import { TrendingUp, Users, Wallet, CreditCard } from 'lucide-react'
import { PageHeader } from '@/components/shared/PageHeader'
import { StatsCard } from '@/components/shared/StatsCard'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { formatCurrency } from '@/lib/utils'
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
  PieChart, Pie, Cell
} from 'recharts'

const monthlyContributions = [
  { month: 'Jan', collected: 125000, expected: 130000 },
  { month: 'Feb', collected: 130000, expected: 130000 },
  { month: 'Mar', collected: 128000, expected: 130000 },
  { month: 'Apr', collected: 135000, expected: 135000 },
  { month: 'May', collected: 140000, expected: 140000 },
  { month: 'Jun', collected: 145000, expected: 145000 },
  { month: 'Jul', collected: 142000, expected: 145000 },
]

const membershipGrowth = [
  { month: 'Jan', members: 35 }, { month: 'Feb', members: 37 },
  { month: 'Mar', members: 38 }, { month: 'Apr', members: 41 },
  { month: 'May', members: 43 }, { month: 'Jun', members: 45 }, { month: 'Jul', members: 47 },
]

const loanPerformance = [
  { month: 'Jan', disbursed: 200000, repaid: 180000, defaulted: 20000 },
  { month: 'Feb', disbursed: 150000, repaid: 200000, defaulted: 0 },
  { month: 'Mar', disbursed: 280000, repaid: 220000, defaulted: 10000 },
  { month: 'Apr', disbursed: 180000, repaid: 260000, defaulted: 0 },
  { month: 'May', disbursed: 220000, repaid: 190000, defaulted: 30000 },
  { month: 'Jun', disbursed: 300000, repaid: 240000, defaulted: 0 },
  { month: 'Jul', disbursed: 250000, repaid: 270000, defaulted: 0 },
]

const cashFlow = [
  { month: 'Jan', inflow: 137000, outflow: 20000, net: 117000 },
  { month: 'Feb', inflow: 144000, outflow: 15000, net: 129000 },
  { month: 'Mar', inflow: 144000, outflow: 25000, net: 119000 },
  { month: 'Apr', inflow: 150000, outflow: 18000, net: 132000 },
  { month: 'May', inflow: 158000, outflow: 22000, net: 136000 },
  { month: 'Jun', inflow: 165000, outflow: 30000, net: 135000 },
  { month: 'Jul', inflow: 164000, outflow: 20000, net: 144000 },
]

const contributionBreakdown = [
  { name: 'Paid on time', value: 72, color: '#059669' },
  { name: 'Paid late', value: 18, color: '#f59e0b' },
  { name: 'Pending', value: 10, color: '#ef4444' },
]

export function AnalyticsPage() {
  const [period, setPeriod] = useState('7m')

  return (
    <div className="space-y-6">
      <PageHeader
        title="Analytics"
        description="Deep insights into group financial performance"
        actions={
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="3m">Last 3 months</SelectItem>
              <SelectItem value="7m">Last 7 months</SelectItem>
              <SelectItem value="12m">Last 12 months</SelectItem>
            </SelectContent>
          </Select>
        }
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard title="Collection Rate" value="97.8%" icon={TrendingUp} variant="success" trend={2.1} />
        <StatsCard title="Membership Growth" value="+34.3%" icon={Users} variant="primary" trend={6} />
        <StatsCard title="Total Disbursed" value={formatCurrency(1580000)} icon={Wallet} variant="gold" />
        <StatsCard title="Default Rate" value="1.9%" icon={CreditCard} variant="warning" trend={-0.4} />
      </div>

      {/* Contribution Trend */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Contribution Trend</CardTitle>
            <CardDescription>Expected vs collected per month</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={monthlyContributions} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} tickFormatter={v => `${v / 1000}k`} />
                <Tooltip formatter={(v: number) => formatCurrency(v)} />
                <Legend iconSize={10} />
                <Bar dataKey="expected" name="Expected" fill="#e5e7eb" radius={[4, 4, 0, 0]} />
                <Bar dataKey="collected" name="Collected" fill="#059669" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Contribution status breakdown */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Contribution Status</CardTitle>
            <CardDescription>Breakdown of member compliance</CardDescription>
          </CardHeader>
          <CardContent className="flex items-center justify-center">
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={contributionBreakdown} cx="50%" cy="50%" outerRadius={80} dataKey="value" label={({ name, value }) => `${name}: ${value}%`}>
                  {contributionBreakdown.map((e, i) => <Cell key={i} fill={e.color} />)}
                </Pie>
                <Tooltip formatter={(v: number) => `${v}%`} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Loan performance */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Loan Performance</CardTitle>
          <CardDescription>Disbursements vs repayments vs defaults</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={loanPerformance} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
              <defs>
                <linearGradient id="gDisbursed" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gRepaid" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#059669" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#059669" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} tickFormatter={v => `${v / 1000}k`} />
              <Tooltip formatter={(v: number) => formatCurrency(v)} />
              <Legend />
              <Area type="monotone" dataKey="disbursed" name="Disbursed" stroke="#3b82f6" fill="url(#gDisbursed)" strokeWidth={2} />
              <Area type="monotone" dataKey="repaid" name="Repaid" stroke="#059669" fill="url(#gRepaid)" strokeWidth={2} />
              <Area type="monotone" dataKey="defaulted" name="Defaulted" stroke="#ef4444" fill="none" strokeWidth={2} strokeDasharray="4 4" />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Cash flow & membership growth */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Cash Flow</CardTitle>
            <CardDescription>Monthly inflow, outflow, and net</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={cashFlow} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} tickFormatter={v => `${v / 1000}k`} />
                <Tooltip formatter={(v: number) => formatCurrency(v)} />
                <Legend iconSize={10} />
                <Line type="monotone" dataKey="inflow" name="Inflow" stroke="#059669" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="outflow" name="Outflow" stroke="#ef4444" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="net" name="Net" stroke="#3b82f6" strokeWidth={2} strokeDasharray="5 5" dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Membership Growth</CardTitle>
            <CardDescription>Monthly member count</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={membershipGrowth} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
                <defs>
                  <linearGradient id="gMembers" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip />
                <Area type="monotone" dataKey="members" name="Members" stroke="#8b5cf6" fill="url(#gMembers)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
