-- =====================================================================
-- Smart Chama - Initial Database Schema
-- PostgreSQL with Row Level Security (RLS)
-- =====================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ─── PROFILES ───────────────────────────────────────────────────────

CREATE TABLE public.profiles (
  id             UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email          TEXT NOT NULL UNIQUE,
  phone          TEXT,
  full_name      TEXT NOT NULL,
  avatar_url     TEXT,
  national_id    TEXT,
  date_of_birth  DATE,
  address        TEXT,
  next_of_kin_name  TEXT,
  next_of_kin_phone TEXT,
  role           TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('super_admin','group_admin','chairperson','treasurer','secretary','loan_committee','member')),
  is_verified    BOOLEAN NOT NULL DEFAULT FALSE,
  is_active      BOOLEAN NOT NULL DEFAULT TRUE,
  credit_score   INTEGER NOT NULL DEFAULT 500 CHECK (credit_score BETWEEN 300 AND 900),
  wallet_balance NUMERIC(15,2) NOT NULL DEFAULT 0,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── GROUPS ─────────────────────────────────────────────────────────

CREATE TABLE public.groups (
  id                   UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name                 TEXT NOT NULL,
  description          TEXT,
  registration_number  TEXT,
  status               TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('active','suspended','pending','inactive')),
  logo_url             TEXT,
  created_by           UUID NOT NULL REFERENCES public.profiles(id),
  subscription_plan    TEXT NOT NULL DEFAULT 'free' CHECK (subscription_plan IN ('free','basic','premium','enterprise')),
  subscription_expires_at TIMESTAMPTZ,
  total_members        INTEGER NOT NULL DEFAULT 0,
  total_savings        NUMERIC(15,2) NOT NULL DEFAULT 0,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── GROUP SETTINGS ──────────────────────────────────────────────────

CREATE TABLE public.group_settings (
  id                         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_id                   UUID NOT NULL UNIQUE REFERENCES public.groups(id) ON DELETE CASCADE,
  contribution_frequency     TEXT NOT NULL DEFAULT 'monthly',
  contribution_amount        NUMERIC(12,2) NOT NULL DEFAULT 0,
  contribution_day           INTEGER,
  custom_contribution_dates  JSONB,
  late_penalty_type          TEXT NOT NULL DEFAULT 'fixed',
  late_penalty_value         NUMERIC(10,2) NOT NULL DEFAULT 0,
  late_penalty_grace_days    INTEGER NOT NULL DEFAULT 3,
  loan_interest_rate         NUMERIC(5,2) NOT NULL DEFAULT 12,
  loan_interest_type         TEXT NOT NULL DEFAULT 'reducing',
  max_loan_multiplier        NUMERIC(5,2) NOT NULL DEFAULT 3,
  loan_repayment_months      INTEGER NOT NULL DEFAULT 12,
  min_guarantors             INTEGER NOT NULL DEFAULT 2,
  max_guarantors             INTEGER NOT NULL DEFAULT 3,
  meeting_frequency          TEXT NOT NULL DEFAULT 'monthly',
  meeting_day                INTEGER,
  meeting_time               TIME,
  meeting_venue              TEXT,
  currency                   TEXT NOT NULL DEFAULT 'KES',
  timezone                   TEXT NOT NULL DEFAULT 'Africa/Nairobi',
  created_at                 TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at                 TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── GROUP MEMBERS ───────────────────────────────────────────────────

CREATE TABLE public.group_members (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_id            UUID NOT NULL REFERENCES public.groups(id) ON DELETE CASCADE,
  user_id             UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  role                TEXT NOT NULL DEFAULT 'member',
  member_number       TEXT NOT NULL,
  joined_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  is_active           BOOLEAN NOT NULL DEFAULT TRUE,
  total_contributions NUMERIC(15,2) NOT NULL DEFAULT 0,
  total_loans         NUMERIC(15,2) NOT NULL DEFAULT 0,
  outstanding_loan    NUMERIC(15,2) NOT NULL DEFAULT 0,
  total_fines         NUMERIC(15,2) NOT NULL DEFAULT 0,
  credit_score        INTEGER NOT NULL DEFAULT 500,
  UNIQUE(group_id, user_id)
);

-- ─── CONTRIBUTIONS ───────────────────────────────────────────────────

CREATE TABLE public.contributions (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_id         UUID NOT NULL REFERENCES public.groups(id) ON DELETE CASCADE,
  member_id        UUID NOT NULL REFERENCES public.group_members(id),
  amount           NUMERIC(12,2) NOT NULL,
  due_date         DATE NOT NULL,
  paid_date        DATE,
  status           TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','paid','late','waived')),
  payment_method   TEXT CHECK (payment_method IN ('mpesa','bank','cash','wallet')),
  transaction_ref  TEXT,
  late_penalty     NUMERIC(10,2),
  receipt_url      TEXT,
  notes            TEXT,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── LOANS ───────────────────────────────────────────────────────────

CREATE TABLE public.loans (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_id            UUID NOT NULL REFERENCES public.groups(id) ON DELETE CASCADE,
  member_id           UUID NOT NULL REFERENCES public.group_members(id),
  amount              NUMERIC(12,2) NOT NULL,
  interest_rate       NUMERIC(5,2) NOT NULL,
  interest_type       TEXT NOT NULL DEFAULT 'reducing',
  total_interest      NUMERIC(12,2) NOT NULL DEFAULT 0,
  total_payable       NUMERIC(12,2) NOT NULL DEFAULT 0,
  monthly_installment NUMERIC(12,2) NOT NULL DEFAULT 0,
  repayment_months    INTEGER NOT NULL,
  status              TEXT NOT NULL DEFAULT 'pending',
  purpose             TEXT NOT NULL,
  applied_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  approved_at         TIMESTAMPTZ,
  approved_by         UUID REFERENCES public.profiles(id),
  disbursed_at        TIMESTAMPTZ,
  due_date            DATE,
  amount_paid         NUMERIC(12,2) NOT NULL DEFAULT 0,
  balance             NUMERIC(12,2) NOT NULL DEFAULT 0,
  notes               TEXT,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── LOAN GUARANTORS ─────────────────────────────────────────────────

CREATE TABLE public.loan_guarantors (
  id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  loan_id               UUID NOT NULL REFERENCES public.loans(id) ON DELETE CASCADE,
  guarantor_member_id   UUID NOT NULL REFERENCES public.group_members(id),
  amount_guaranteed     NUMERIC(12,2) NOT NULL,
  status                TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  responded_at          TIMESTAMPTZ,
  notes                 TEXT,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── LOAN REPAYMENTS ─────────────────────────────────────────────────

CREATE TABLE public.loan_repayments (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  loan_id           UUID NOT NULL REFERENCES public.loans(id) ON DELETE CASCADE,
  member_id         UUID NOT NULL REFERENCES public.group_members(id),
  amount            NUMERIC(12,2) NOT NULL,
  principal_portion NUMERIC(12,2) NOT NULL DEFAULT 0,
  interest_portion  NUMERIC(12,2) NOT NULL DEFAULT 0,
  payment_date      DATE NOT NULL DEFAULT CURRENT_DATE,
  payment_method    TEXT NOT NULL DEFAULT 'mpesa',
  transaction_ref   TEXT,
  balance_after     NUMERIC(12,2) NOT NULL DEFAULT 0,
  receipt_url       TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── FINES ───────────────────────────────────────────────────────────

CREATE TABLE public.fines (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_id         UUID NOT NULL REFERENCES public.groups(id) ON DELETE CASCADE,
  member_id        UUID NOT NULL REFERENCES public.group_members(id),
  type             TEXT NOT NULL,
  amount           NUMERIC(10,2) NOT NULL,
  reason           TEXT NOT NULL,
  reference_id     UUID,
  status           TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','paid','waived')),
  issued_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  paid_at          TIMESTAMPTZ,
  payment_method   TEXT,
  transaction_ref  TEXT,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── MEETINGS ────────────────────────────────────────────────────────

CREATE TABLE public.meetings (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_id       UUID NOT NULL REFERENCES public.groups(id) ON DELETE CASCADE,
  title          TEXT NOT NULL,
  description    TEXT,
  scheduled_at   TIMESTAMPTZ NOT NULL,
  venue          TEXT,
  meeting_link   TEXT,
  status         TEXT NOT NULL DEFAULT 'scheduled',
  minutes        TEXT,
  agenda         JSONB,
  created_by     UUID NOT NULL REFERENCES public.profiles(id),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── MEETING ATTENDANCE ──────────────────────────────────────────────

CREATE TABLE public.meeting_attendance (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  meeting_id    UUID NOT NULL REFERENCES public.meetings(id) ON DELETE CASCADE,
  member_id     UUID NOT NULL REFERENCES public.group_members(id),
  status        TEXT NOT NULL DEFAULT 'absent' CHECK (status IN ('present','absent','excused')),
  checked_in_at TIMESTAMPTZ,
  fine_issued   BOOLEAN NOT NULL DEFAULT FALSE,
  UNIQUE(meeting_id, member_id)
);

-- ─── PAYMENTS ────────────────────────────────────────────────────────

CREATE TABLE public.payments (
  id                          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_id                    UUID REFERENCES public.groups(id),
  member_id                   UUID REFERENCES public.group_members(id),
  amount                      NUMERIC(12,2) NOT NULL,
  currency                    TEXT NOT NULL DEFAULT 'KES',
  payment_method              TEXT NOT NULL DEFAULT 'mpesa',
  reference_type              TEXT NOT NULL,
  reference_id                UUID,
  status                      TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','completed','failed','cancelled')),
  mpesa_checkout_request_id   TEXT,
  mpesa_receipt_number        TEXT,
  phone_number                TEXT,
  created_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at                TIMESTAMPTZ
);

-- ─── ANNOUNCEMENTS ───────────────────────────────────────────────────

CREATE TABLE public.announcements (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_id    UUID NOT NULL REFERENCES public.groups(id) ON DELETE CASCADE,
  title       TEXT NOT NULL,
  content     TEXT NOT NULL,
  is_pinned   BOOLEAN NOT NULL DEFAULT FALSE,
  created_by  UUID NOT NULL REFERENCES public.profiles(id),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  read_count  INTEGER NOT NULL DEFAULT 0
);

-- ─── DOCUMENTS ───────────────────────────────────────────────────────

CREATE TABLE public.documents (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_id       UUID NOT NULL REFERENCES public.groups(id) ON DELETE CASCADE,
  name           TEXT NOT NULL,
  description    TEXT,
  file_url       TEXT NOT NULL,
  file_size      BIGINT NOT NULL DEFAULT 0,
  file_type      TEXT NOT NULL,
  category       TEXT NOT NULL DEFAULT 'other',
  uploaded_by    UUID NOT NULL REFERENCES public.profiles(id),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  download_count INTEGER NOT NULL DEFAULT 0
);

-- ─── NOTIFICATIONS ───────────────────────────────────────────────────

CREATE TABLE public.notifications (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  group_id    UUID REFERENCES public.groups(id),
  title       TEXT NOT NULL,
  message     TEXT NOT NULL,
  type        TEXT NOT NULL DEFAULT 'info' CHECK (type IN ('info','success','warning','error')),
  channel     TEXT NOT NULL DEFAULT 'in_app',
  is_read     BOOLEAN NOT NULL DEFAULT FALSE,
  action_url  TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── EXPENSES ────────────────────────────────────────────────────────

CREATE TABLE public.expenses (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_id     UUID NOT NULL REFERENCES public.groups(id) ON DELETE CASCADE,
  description  TEXT NOT NULL,
  amount       NUMERIC(12,2) NOT NULL,
  category     TEXT NOT NULL,
  date         DATE NOT NULL DEFAULT CURRENT_DATE,
  approved_by  UUID REFERENCES public.profiles(id),
  receipt_url  TEXT,
  created_by   UUID NOT NULL REFERENCES public.profiles(id),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── INCOME ──────────────────────────────────────────────────────────

CREATE TABLE public.income (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_id     UUID NOT NULL REFERENCES public.groups(id) ON DELETE CASCADE,
  description  TEXT NOT NULL,
  amount       NUMERIC(12,2) NOT NULL,
  source       TEXT NOT NULL,
  date         DATE NOT NULL DEFAULT CURRENT_DATE,
  created_by   UUID NOT NULL REFERENCES public.profiles(id),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── AUDIT LOGS ──────────────────────────────────────────────────────

CREATE TABLE public.audit_logs (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id        UUID NOT NULL REFERENCES public.profiles(id),
  group_id       UUID REFERENCES public.groups(id),
  action         TEXT NOT NULL,
  resource_type  TEXT NOT NULL,
  resource_id    UUID,
  old_values     JSONB,
  new_values     JSONB,
  ip_address     INET,
  user_agent     TEXT,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── SUBSCRIPTIONS ───────────────────────────────────────────────────

CREATE TABLE public.subscriptions (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_id      UUID NOT NULL REFERENCES public.groups(id) ON DELETE CASCADE,
  plan          TEXT NOT NULL DEFAULT 'free',
  status        TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','expired','cancelled')),
  amount        NUMERIC(10,2) NOT NULL DEFAULT 0,
  billing_cycle TEXT NOT NULL DEFAULT 'monthly',
  started_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at    TIMESTAMPTZ NOT NULL,
  features      JSONB,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =====================================================================
-- INDEXES for Performance
-- =====================================================================

CREATE INDEX idx_group_members_group ON public.group_members(group_id);
CREATE INDEX idx_group_members_user ON public.group_members(user_id);
CREATE INDEX idx_contributions_group ON public.contributions(group_id);
CREATE INDEX idx_contributions_member ON public.contributions(member_id);
CREATE INDEX idx_contributions_due_date ON public.contributions(due_date);
CREATE INDEX idx_loans_group ON public.loans(group_id);
CREATE INDEX idx_loans_member ON public.loans(member_id);
CREATE INDEX idx_loans_status ON public.loans(status);
CREATE INDEX idx_fines_group ON public.fines(group_id);
CREATE INDEX idx_fines_member ON public.fines(member_id);
CREATE INDEX idx_meetings_group ON public.meetings(group_id);
CREATE INDEX idx_payments_mpesa_checkout ON public.payments(mpesa_checkout_request_id);
CREATE INDEX idx_notifications_user ON public.notifications(user_id);
CREATE INDEX idx_audit_logs_user ON public.audit_logs(user_id);
CREATE INDEX idx_audit_logs_group ON public.audit_logs(group_id);

-- =====================================================================
-- ROW LEVEL SECURITY (RLS)
-- =====================================================================

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.group_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.group_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contributions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.loans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.loan_guarantors ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.loan_repayments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fines ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.meetings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.meeting_attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.expenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.income ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;

-- Profiles: users can read their own, super_admin reads all
CREATE POLICY "profiles_select_own" ON public.profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "profiles_select_super_admin" ON public.profiles
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role = 'super_admin')
  );

CREATE POLICY "profiles_update_own" ON public.profiles
  FOR UPDATE USING (auth.uid() = id);

-- Groups: members can see groups they belong to
CREATE POLICY "groups_select_member" ON public.groups
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.group_members gm
      WHERE gm.group_id = groups.id AND gm.user_id = auth.uid() AND gm.is_active = TRUE
    )
    OR EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role = 'super_admin')
  );

-- Group members: members can see peers in same group
CREATE POLICY "group_members_select" ON public.group_members
  FOR SELECT USING (
    group_id IN (
      SELECT group_id FROM public.group_members WHERE user_id = auth.uid() AND is_active = TRUE
    )
    OR EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role = 'super_admin')
  );

-- Contributions: members see their own; admins see all in their group
CREATE POLICY "contributions_select" ON public.contributions
  FOR SELECT USING (
    member_id IN (
      SELECT id FROM public.group_members WHERE user_id = auth.uid()
    )
    OR group_id IN (
      SELECT group_id FROM public.group_members
      WHERE user_id = auth.uid()
        AND role IN ('group_admin','chairperson','treasurer','secretary')
    )
  );

-- Loans: same pattern
CREATE POLICY "loans_select" ON public.loans
  FOR SELECT USING (
    member_id IN (SELECT id FROM public.group_members WHERE user_id = auth.uid())
    OR group_id IN (
      SELECT group_id FROM public.group_members
      WHERE user_id = auth.uid()
        AND role IN ('group_admin','chairperson','treasurer','loan_committee')
    )
  );

-- Notifications: own only
CREATE POLICY "notifications_select_own" ON public.notifications
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "notifications_update_own" ON public.notifications
  FOR UPDATE USING (user_id = auth.uid());

-- Announcements, Documents, Meetings: accessible to group members
CREATE POLICY "announcements_select" ON public.announcements
  FOR SELECT USING (
    group_id IN (SELECT group_id FROM public.group_members WHERE user_id = auth.uid() AND is_active = TRUE)
  );

CREATE POLICY "documents_select" ON public.documents
  FOR SELECT USING (
    group_id IN (SELECT group_id FROM public.group_members WHERE user_id = auth.uid() AND is_active = TRUE)
  );

CREATE POLICY "meetings_select" ON public.meetings
  FOR SELECT USING (
    group_id IN (SELECT group_id FROM public.group_members WHERE user_id = auth.uid() AND is_active = TRUE)
  );

-- Fines: own or admin
CREATE POLICY "fines_select" ON public.fines
  FOR SELECT USING (
    member_id IN (SELECT id FROM public.group_members WHERE user_id = auth.uid())
    OR group_id IN (
      SELECT group_id FROM public.group_members
      WHERE user_id = auth.uid() AND role IN ('group_admin','chairperson','treasurer')
    )
  );

-- Payments: own only
CREATE POLICY "payments_select_own" ON public.payments
  FOR SELECT USING (
    member_id IN (SELECT id FROM public.group_members WHERE user_id = auth.uid())
  );

-- Audit logs: super admin only
CREATE POLICY "audit_logs_select" ON public.audit_logs
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role = 'super_admin')
  );

-- =====================================================================
-- AUTO-UPDATE updated_at TRIGGER
-- =====================================================================

CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_profiles_updated_at BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER trg_groups_updated_at BEFORE UPDATE ON public.groups
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER trg_group_settings_updated_at BEFORE UPDATE ON public.group_settings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER trg_loans_updated_at BEFORE UPDATE ON public.loans
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

-- =====================================================================
-- AUTO-CREATE PROFILE ON SIGNUP
-- =====================================================================

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'New User'),
    'member'
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
