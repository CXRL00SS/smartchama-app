/**
 * RoleSwitcher — Development tool to quickly switch between dashboard roles.
 * Only visible in development mode (import.meta.env.DEV).
 * Remove or hide this in production.
 */

import React, { useState } from 'react'
import { doc, updateDoc } from 'firebase/firestore'
import { db } from '@/lib/firebase'
import { useAuth } from '@/context/AuthContext'
import { useNavigate } from 'react-router-dom'
import { toast } from 'sonner'
import type { UserRole } from '@/types'

const roles: { role: UserRole; label: string; emoji: string; path: string }[] = [
  { role: 'super_admin',    label: 'Super Admin',    emoji: '🛡️', path: '/super-admin' },
  { role: 'group_admin',   label: 'Group Admin',    emoji: '👑', path: '/admin' },
  { role: 'chairperson',   label: 'Chairperson',    emoji: '🪑', path: '/admin' },
  { role: 'treasurer',     label: 'Treasurer',      emoji: '💰', path: '/admin' },
  { role: 'secretary',     label: 'Secretary',      emoji: '📋', path: '/admin' },
  { role: 'loan_committee',label: 'Loan Committee', emoji: '🏦', path: '/member' },
  { role: 'member',        label: 'Member',         emoji: '👤', path: '/member' },
]

export function RoleSwitcher() {
  const { user, role: currentRole, refreshProfile } = useAuth()
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState<UserRole | null>(null)

  // Only show in development
  if (!import.meta.env.DEV) return null
  if (!user) return null

  const switchRole = async (newRole: UserRole, path: string) => {
    setLoading(newRole)
    try {
      await updateDoc(doc(db, 'profiles', user.uid), { role: newRole })
      await refreshProfile()
      toast.success(`Switched to ${newRole.replace('_', ' ')}`)
      navigate(path, { replace: true })
      setOpen(false)
    } catch (err) {
      toast.error('Failed to switch role')
    } finally {
      setLoading(null)
    }
  }

  return (
    <>
      {/* Floating trigger button */}
      <button
        onClick={() => setOpen(!open)}
        className="fixed bottom-4 right-4 z-50 flex items-center gap-2 bg-gray-900 text-white text-xs font-medium px-3 py-2 rounded-full shadow-xl border border-gray-700 hover:bg-gray-800 transition-colors"
        title="Dev: Switch Role"
      >
        <span>🔧</span>
        <span className="hidden sm:inline">Dev Tools</span>
      </button>

      {/* Panel */}
      {open && (
        <>
          {/* Backdrop */}
          <div
            className="fixed inset-0 z-40 bg-black/40"
            onClick={() => setOpen(false)}
          />

          {/* Role panel */}
          <div className="fixed bottom-14 right-4 z-50 bg-gray-900 border border-gray-700 rounded-2xl shadow-2xl w-64 overflow-hidden">
            <div className="px-4 py-3 border-b border-gray-700">
              <p className="text-white text-sm font-semibold">🔧 Dev Role Switcher</p>
              <p className="text-gray-400 text-xs mt-0.5">
                Current: <span className="text-emerald-400 font-medium capitalize">{currentRole?.replace('_', ' ')}</span>
              </p>
            </div>

            <div className="p-2 space-y-1">
              {roles.map(({ role, label, emoji, path }) => (
                <button
                  key={role}
                  onClick={() => switchRole(role, path)}
                  disabled={loading === role || currentRole === role}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-colors text-left
                    ${currentRole === role
                      ? 'bg-emerald-600/20 text-emerald-400 cursor-default'
                      : 'text-gray-300 hover:bg-gray-800 hover:text-white'
                    }`}
                >
                  <span className="text-base">{emoji}</span>
                  <span className="flex-1">{label}</span>
                  {currentRole === role && (
                    <span className="text-[10px] bg-emerald-600/30 text-emerald-400 px-1.5 py-0.5 rounded-full">Active</span>
                  )}
                  {loading === role && (
                    <svg className="animate-spin h-3.5 w-3.5 text-emerald-400" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                    </svg>
                  )}
                </button>
              ))}
            </div>

            <div className="px-4 py-2 border-t border-gray-700">
              <p className="text-gray-500 text-[10px]">Only visible in dev mode</p>
            </div>
          </div>
        </>
      )}
    </>
  )
}
