import React, { useState } from 'react'
import { Plus, UserCheck, UserX, Edit, Mail, Phone } from 'lucide-react'
import { PageHeader } from '@/components/shared/PageHeader'
import { DataTable, Column } from '@/components/shared/DataTable'
import { StatsCard } from '@/components/shared/StatsCard'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { formatCurrency, formatDate, getInitials } from '@/lib/utils'
import type { GroupMember } from '@/types'
import { toast } from 'sonner'
import { Users } from 'lucide-react'

const mockMembers = [
  { id: 'm1', full_name: 'Alice Wanjiku', email: 'alice@example.com', phone: '0712345678', role: 'member', member_number: 'PAM-0001', joined_at: '2022-01-15', is_active: true, total_contributions: 120000, credit_score: 780 },
  { id: 'm2', full_name: 'Bob Kipchoge', email: 'bob@example.com', phone: '0722345678', role: 'treasurer', member_number: 'PAM-0002', joined_at: '2022-01-15', is_active: true, total_contributions: 115000, credit_score: 800 },
  { id: 'm3', full_name: 'Carol Achieng', email: 'carol@example.com', phone: '0732345678', role: 'secretary', member_number: 'PAM-0003', joined_at: '2022-03-01', is_active: true, total_contributions: 100000, credit_score: 760 },
  { id: 'm4', full_name: 'David Mwenda', email: 'david@example.com', phone: '0742345678', role: 'member', member_number: 'PAM-0004', joined_at: '2023-06-01', is_active: true, total_contributions: 75000, credit_score: 720 },
  { id: 'm5', full_name: 'Eva Njoki', email: 'eva@example.com', phone: '0752345678', role: 'member', member_number: 'PAM-0005', joined_at: '2023-09-15', is_active: false, total_contributions: 45000, credit_score: 650 },
]

const roleBadgeVariant: Record<string, string> = {
  chairperson: 'gold',
  treasurer: 'success',
  secretary: 'info',
  member: 'secondary',
  loan_committee: 'warning',
}

export function MembersPage() {
  const [inviteOpen, setInviteOpen] = useState(false)
  const [inviteEmail, setInviteEmail] = useState('')
  const [inviteRole, setInviteRole] = useState('member')
  const [loading, setLoading] = useState(false)

  const activeCount = mockMembers.filter(m => m.is_active).length
  const totalSavings = mockMembers.reduce((s, m) => s + m.total_contributions, 0)

  const handleInvite = async () => {
    if (!inviteEmail) { toast.error('Enter an email address'); return }
    setLoading(true)
    await new Promise(r => setTimeout(r, 1500))
    setLoading(false)
    setInviteOpen(false)
    toast.success('Invitation sent!', { description: `An invite was sent to ${inviteEmail}` })
    setInviteEmail('')
  }

  const columns: Column<typeof mockMembers[0]>[] = [
    {
      key: 'full_name',
      header: 'Member',
      render: (_, row) => (
        <div className="flex items-center gap-3">
          <Avatar className="h-8 w-8">
            <AvatarFallback className="text-xs">{getInitials(row.full_name)}</AvatarFallback>
          </Avatar>
          <div>
            <p className="font-medium text-sm">{row.full_name}</p>
            <p className="text-xs text-muted-foreground">{row.member_number}</p>
          </div>
        </div>
      ),
    },
    { key: 'email', header: 'Contact', render: (v) => <span className="text-xs">{String(v)}</span> },
    {
      key: 'role',
      header: 'Role',
      render: (v) => (
        <Badge variant={roleBadgeVariant[v as string] as 'success' || 'secondary'} className="capitalize">
          {String(v).replace('_', ' ')}
        </Badge>
      ),
    },
    { key: 'joined_at', header: 'Joined', render: (v) => formatDate(v as string) },
    { key: 'total_contributions', header: 'Contributions', render: (v) => formatCurrency(v as number) },
    { key: 'credit_score', header: 'Credit Score', render: (v) => <span className="font-semibold">{String(v)}</span> },
    {
      key: 'is_active',
      header: 'Status',
      render: (v) => <Badge variant={v ? 'success' : 'secondary'}>{v ? 'Active' : 'Inactive'}</Badge>,
    },
    {
      key: 'id',
      header: 'Actions',
      render: () => (
        <div className="flex gap-1">
          <Button variant="ghost" size="icon" className="h-7 w-7"><Edit className="h-3.5 w-3.5" /></Button>
          <Button variant="ghost" size="icon" className="h-7 w-7"><Mail className="h-3.5 w-3.5" /></Button>
        </div>
      ),
    },
  ]

  return (
    <div className="space-y-6">
      <PageHeader
        title="Members"
        description="Manage group membership and roles"
        actions={
          <Button onClick={() => setInviteOpen(true)}>
            <Plus className="h-4 w-4" /> Invite Member
          </Button>
        }
      />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatsCard title="Total Members" value={mockMembers.length} icon={Users} variant="primary" />
        <StatsCard title="Active Members" value={activeCount} icon={UserCheck} variant="success" />
        <StatsCard title="Total Savings" value={formatCurrency(totalSavings)} icon={UserX} variant="gold" />
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">All Members</CardTitle></CardHeader>
        <CardContent>
          <DataTable
            data={mockMembers as unknown as Record<string, unknown>[]}
            columns={columns as unknown as Column<Record<string, unknown>>[]}
            searchKeys={['full_name', 'email', 'member_number'] as unknown as (keyof Record<string, unknown>)[]}
            searchPlaceholder="Search members..."
          />
        </CardContent>
      </Card>

      <Dialog open={inviteOpen} onOpenChange={setInviteOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Invite New Member</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label>Email Address</Label>
              <Input type="email" placeholder="member@example.com" value={inviteEmail} onChange={e => setInviteEmail(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Role</Label>
              <Select value={inviteRole} onValueChange={setInviteRole}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {['member', 'secretary', 'treasurer', 'loan_committee'].map(r => (
                    <SelectItem key={r} value={r} className="capitalize">{r.replace('_', ' ')}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setInviteOpen(false)}>Cancel</Button>
            <Button onClick={handleInvite} loading={loading}>Send Invitation</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
