import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Format a number as Kenyan Shillings currency
 */
export function formatCurrency(amount: number, currency = 'KES'): string {
  return new Intl.NumberFormat('en-KE', {
    style: 'currency',
    currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(amount)
}

/**
 * Format a date string to a readable format
 */
export function formatDate(date: string | Date, options?: Intl.DateTimeFormatOptions): string {
  const d = typeof date === 'string' ? new Date(date) : date
  return new Intl.DateTimeFormat('en-KE', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    ...options,
  }).format(d)
}

/**
 * Format a date to relative time (e.g., "2 hours ago")
 */
export function formatRelativeTime(date: string | Date): string {
  const d = typeof date === 'string' ? new Date(date) : date
  const now = new Date()
  const diffMs = now.getTime() - d.getTime()
  const diffSecs = Math.floor(diffMs / 1000)
  const diffMins = Math.floor(diffSecs / 60)
  const diffHours = Math.floor(diffMins / 60)
  const diffDays = Math.floor(diffHours / 24)

  if (diffSecs < 60) return 'just now'
  if (diffMins < 60) return `${diffMins}m ago`
  if (diffHours < 24) return `${diffHours}h ago`
  if (diffDays < 7) return `${diffDays}d ago`
  return formatDate(d)
}

/**
 * Calculate loan repayment schedule
 */
export function calculateLoanSchedule(
  principal: number,
  annualRate: number,
  months: number,
  type: 'flat' | 'reducing' = 'reducing'
) {
  if (type === 'flat') {
    const totalInterest = (principal * (annualRate / 100) * months) / 12
    const totalPayable = principal + totalInterest
    const monthlyInstallment = totalPayable / months
    return { totalInterest, totalPayable, monthlyInstallment }
  }

  // Reducing balance
  const monthlyRate = annualRate / 100 / 12
  if (monthlyRate === 0) {
    return { totalInterest: 0, totalPayable: principal, monthlyInstallment: principal / months }
  }
  const monthlyInstallment =
    (principal * monthlyRate * Math.pow(1 + monthlyRate, months)) /
    (Math.pow(1 + monthlyRate, months) - 1)
  const totalPayable = monthlyInstallment * months
  const totalInterest = totalPayable - principal
  return { totalInterest, totalPayable, monthlyInstallment }
}

/**
 * Calculate credit score based on member activity
 */
export function calculateCreditScore(
  totalContributions: number,
  latePayments: number,
  defaultedLoans: number,
  totalLoans: number
): number {
  let score = 500
  score += Math.min(totalContributions / 1000, 200)
  score -= latePayments * 20
  score -= defaultedLoans * 100
  score += totalLoans > 0 && defaultedLoans === 0 ? 50 : 0
  return Math.max(300, Math.min(900, Math.round(score)))
}

/**
 * Get initials from a full name
 */
export function getInitials(name: string): string {
  return name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2)
}

/**
 * Truncate text to a max length
 */
export function truncate(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text
  return `${text.slice(0, maxLength)}...`
}

/**
 * Generate a member number
 */
export function generateMemberNumber(groupPrefix: string, count: number): string {
  return `${groupPrefix.toUpperCase().slice(0, 3)}-${String(count).padStart(4, '0')}`
}

/**
 * Validate a Kenyan phone number and normalize to 254 format
 */
export function normalizeKenyanPhone(phone: string): string {
  const cleaned = phone.replace(/\D/g, '')
  if (cleaned.startsWith('254')) return cleaned
  if (cleaned.startsWith('0')) return `254${cleaned.slice(1)}`
  if (cleaned.startsWith('7') || cleaned.startsWith('1')) return `254${cleaned}`
  return cleaned
}

/**
 * Check if a phone number is a valid Kenyan number
 */
export function isValidKenyanPhone(phone: string): boolean {
  const normalized = normalizeKenyanPhone(phone)
  return /^254[71]\d{8}$/.test(normalized)
}

/**
 * Format file size in human-readable form
 */
export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}

/**
 * Get color class for credit score
 */
export function getCreditScoreColor(score: number): string {
  if (score >= 750) return 'text-emerald-600'
  if (score >= 650) return 'text-blue-600'
  if (score >= 550) return 'text-yellow-600'
  return 'text-red-600'
}

/**
 * Get label for credit score
 */
export function getCreditScoreLabel(score: number): string {
  if (score >= 750) return 'Excellent'
  if (score >= 650) return 'Good'
  if (score >= 550) return 'Fair'
  return 'Poor'
}

/**
 * Debounce utility
 */
export function debounce<T extends (...args: unknown[]) => unknown>(fn: T, delay: number) {
  let timer: ReturnType<typeof setTimeout>
  return (...args: Parameters<T>) => {
    clearTimeout(timer)
    timer = setTimeout(() => fn(...args), delay)
  }
}
