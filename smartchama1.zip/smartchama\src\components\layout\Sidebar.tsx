import React, { useState } from 'react'
import { NavLink, useLocation } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  LayoutDashboard, Users, CreditCard, Landmark, Calendar, Bell,
  FileText, BarChart3, Settings, Shield, Building2, ChevronLeft,
  ChevronRight, Wallet, AlertTriangle, Megaphone, FolderOpen,
  TrendingUp, LogOut, HelpCircle, ChevronDown, MessageSquare
} from 'lucide-react'
import { cn, getInitials } from '@/lib/utils'
import { useAuth } from '@/context/AuthContext'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import type { UserRole } from '@/types'

interface NavItem {
  label: string
  href: string
  icon: React.ElementType
  badge?: number
  children?: NavItem[]
}

const superAdminNav: NavItem[] = [
  { label: 'Dashboard', href: '/super-admin', icon: LayoutDashboard },
  { label: 'Groups', href: '/super-admin/groups', icon: Building2 },
  { label: 'Users', href: '/super-admin/users', icon: Users },
  { label: 'Fines & Revenue', href: '/super-admin/fines', icon: AlertTriangle },
  { label: 'Revenue Dashboard', href: '/super-admin/revenue', icon: TrendingUp },
  { label: 'Fee Settings', href: '/super-admin/fee-settings', icon: CreditCard },
  { label: 'Subscriptions', href: '/super-admin/subscriptions', icon: CreditCard },
  { label: 'Analytics', href: '/super-admin/analytics', icon: BarChart3 },
  { label: 'Audit Logs', href: '/super-admin/audit', icon: Shield },
  { label: 'Support', href: '/super-admin/support', icon: HelpCircle },
  { label: 'Settings', href: '/super-admin/settings', icon: Settings },
]

const groupAdminNav: NavItem[] = [
  { label: 'Dashboard', href: '/admin', icon: LayoutDashboard },
  { label: 'Members', href: '/admin/members', icon: Users },
  { label: 'Contributions', href: '/admin/contributions', icon: Wallet },
  { label: 'Loans', href: '/admin/loans', icon: Landmark },
  { label: 'Fines', href: '/admin/fines', icon: AlertTriangle },
  { label: 'Meetings', href: '/admin/meetings', icon: Calendar },
  { label: 'Announcements', href: '/admin/announcements', icon: Megaphone },
  { label: 'Documents', href: '/admin/documents', icon: FolderOpen },
  { label: 'Reports', href: '/admin/reports', icon: FileText },
  { label: 'Analytics', href: '/admin/analytics', icon: BarChart3 },
  { label: 'Settings', href: '/admin/settings', icon: Settings },
]

const memberNav: NavItem[] = [
  { label: 'Dashboard', href: '/member', icon: LayoutDashboard },
  { label: 'Browse Groups', href: '/member/join-group', icon: Building2 },
  { label: 'Contributions', href: '/member/contributions', icon: Wallet },
  { label: 'Loans', href: '/member/loans', icon: Landmark },
  { label: 'Fines', href: '/member/fines', icon: AlertTriangle },
  { label: 'Meetings', href: '/member/meetings', icon: Calendar },
  { label: 'Announcements', href: '/member/announcements', icon: Megaphone },
  { label: 'Documents', href: '/member/documents', icon: FolderOpen },
  { label: 'Statements', href: '/member/statements', icon: FileText },
  { label: 'Notifications', href: '/member/notifications', icon: Bell },
  { label: 'Profile', href: '/member/profile', icon: Users },
]

const chairpersonNav: NavItem[] = [
  { label: 'Dashboard', href: '/admin', icon: LayoutDashboard },
  { label: 'Members', href: '/admin/members', icon: Users },
  { label: 'Appoint Roles', href: '/admin/appoint-roles', icon: Shield },
  { label: 'Contributions', href: '/admin/contributions', icon: Wallet },
  { label: 'Loans', href: '/admin/loans', icon: Landmark },
  { label: 'Fines', href: '/admin/fines', icon: AlertTriangle },
  { label: 'Fine Disputes', href: '/admin/disputes', icon: MessageSquare },
  { label: 'Attendance', href: '/admin/attendance', icon: Calendar },
  { label: 'Meetings', href: '/admin/meetings', icon: Calendar },
  { label: 'Announcements', href: '/admin/announcements', icon: Megaphone },
  { label: 'Documents', href: '/admin/documents', icon: FolderOpen },
  { label: 'Reports', href: '/admin/reports', icon: FileText },
  { label: 'Analytics', href: '/admin/analytics', icon: BarChart3 },
  { label: 'Settings', href: '/admin/settings', icon: Settings },
]

const navByRole: Record<UserRole, NavItem[]> = {
  super_admin: superAdminNav,
  group_admin: groupAdminNav,
  chairperson: chairpersonNav,
  treasurer: groupAdminNav,
  secretary: groupAdminNav,
  loan_committee: memberNav,
  member: memberNav,
}

interface SidebarProps {
  collapsed: boolean
  onToggle: () => void
}

export function Sidebar({ collapsed, onToggle }: SidebarProps) {
  const { profile, role, signOut } = useAuth()
  const location = useLocation()
  const [expandedItems, setExpandedItems] = useState<string[]>([])

  const navItems = role ? navByRole[role] : memberNav

  const toggleExpand = (label: string) => {
    setExpandedItems(prev =>
      prev.includes(label) ? prev.filter(i => i !== label) : [...prev, label]
    )
  }

  const isActive = (href: string) => {
    if (href === '/member' || href === '/admin' || href === '/super-admin') {
      return location.pathname === href
    }
    return location.pathname.startsWith(href)
  }

  return (
    <motion.aside
      initial={false}
      animate={{ width: collapsed ? 70 : 260 }}
      transition={{ duration: 0.2, ease: 'easeInOut' }}
      className="relative flex flex-col h-full bg-card border-r border-border z-30 overflow-hidden"
    >
      {/* Logo */}
      <div className="flex items-center h-16 px-4 border-b border-border shrink-0">
        <div className="flex items-center gap-3 min-w-0">
          {/* Collapsed: show icon only. Expanded: show full logo */}
          <div className="shrink-0 flex items-center justify-center">
            {collapsed ? (
              <img
                src="/logo.png"
                alt="Smart Chama"
                className="h-9 w-9 object-contain rounded-lg"
              />
            ) : (
              <img
                src="/logo.png"
                alt="Smart Chama"
                className="h-10 object-contain"
                style={{ maxWidth: 160 }}
              />
            )}
          </div>
        </div>
        <button
          onClick={onToggle}
          className="ml-auto p-1.5 rounded-md hover:bg-muted transition-colors text-muted-foreground hover:text-foreground shrink-0"
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto scrollbar-thin py-4 px-2">
        <ul className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon
            const active = isActive(item.href)

            if (item.children) {
              const expanded = expandedItems.includes(item.label)
              return (
                <li key={item.label}>
                  <button
                    onClick={() => toggleExpand(item.label)}
                    className={cn(
                      'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all',
                      active
                        ? 'bg-primary text-primary-foreground'
                        : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                    )}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    {!collapsed && (
                      <>
                        <span className="flex-1 text-left">{item.label}</span>
                        <ChevronDown className={cn('h-3 w-3 transition-transform', expanded && 'rotate-180')} />
                      </>
                    )}
                  </button>
                  {!collapsed && expanded && (
                    <ul className="ml-4 mt-1 space-y-1">
                      {item.children.map(child => (
                        <li key={child.label}>
                          <NavLink
                            to={child.href}
                            className={({ isActive }) =>
                              cn(
                                'flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all',
                                isActive
                                  ? 'bg-primary/10 text-primary font-medium'
                                  : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                              )
                            }
                          >
                            <child.icon className="h-3.5 w-3.5 shrink-0" />
                            {child.label}
                          </NavLink>
                        </li>
                      ))}
                    </ul>
                  )}
                </li>
              )
            }

            return (
              <li key={item.label}>
                <NavLink
                  to={item.href}
                  title={collapsed ? item.label : undefined}
                  className={cn(
                    'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all group',
                    active
                      ? 'bg-primary text-primary-foreground shadow-sm'
                      : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                  )}
                >
                  <Icon className="h-4 w-4 shrink-0" />
                  {!collapsed && (
                    <>
                      <span className="flex-1">{item.label}</span>
                      {item.badge !== undefined && item.badge > 0 && (
                        <Badge variant="destructive" className="text-xs px-1.5 py-0 h-5">
                          {item.badge > 99 ? '99+' : item.badge}
                        </Badge>
                      )}
                    </>
                  )}
                </NavLink>
              </li>
            )
          })}
        </ul>
      </nav>

      {/* User section */}
      <div className="border-t border-border p-3 shrink-0">
        <div className={cn('flex items-center gap-3', collapsed && 'justify-center')}>
          <Avatar className="h-9 w-9 shrink-0">
            <AvatarImage src={profile?.avatar_url} />
            <AvatarFallback className="text-xs">
              {getInitials(profile?.full_name || 'User')}
            </AvatarFallback>
          </Avatar>
          {!collapsed && (
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{profile?.full_name || 'User'}</p>
              <p className="text-xs text-muted-foreground truncate capitalize">
                {role?.replace('_', ' ')}
              </p>
            </div>
          )}
          {!collapsed && (
            <button
              onClick={signOut}
              className="p-1.5 rounded-md text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
              title="Sign out"
            >
              <LogOut className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>
    </motion.aside>
  )
}
