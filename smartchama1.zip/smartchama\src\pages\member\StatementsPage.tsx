import React, { useState } from 'react'
import { Download, FileText, Filter } from 'lucide-react'
import { PageHeader } from '@/components/shared/PageHeader'
import { StatsCard } from '@/components/shared/StatsCard'
import { DataTable, Column } from '@/components/shared/DataTable'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { formatCurrency, formatDate } from '@/lib/utils'
import { Wallet, CreditCard, AlertTriangle } from 'lucide-react'
import { toast } from 'sonner'

const transactions = [
  { id: 't1', date: '2026-07-30', description: 'Monthly Contribution - July 2026', type: 'contribution', amount: 5000, balance: 85000, reference: 'QJH7X3', status: 'completed' },
  { id: 't2', date: '2026-07-25', description: 'Loan Repayment - July', type: 'loan_repayment', amount: -3500, balance: 80000, reference: 'MPE001', status: 'completed' },
  { id: 't3', date: '2026-07-20', description: 'Fine - Late contribution', type: 'fine', amount: -500, balance: 83500, reference: 'FN003', status: 'completed' },
  { id: 't4', date: '2026-06-30', description: 'Monthly Contribution - June 2026', type: 'contribution', amount: 5000, balance: 84000, reference: 'PLK2M9', status: 'completed' },
  { id: 't5', date: '2026-06-25', description: 'Loan Repayment - June', type: 'loan_repayment', amount: -3500, balance: 79000, reference: 'MPE002', status: 'completed' },
  { id: 't6', date: '2026-01-15', description: 'Loan Disbursement', type: 'loan_disbursement', amount: 50000, balance: 74500, reference: 'LN001', status: 'completed' },
]

const typeColor: Record<string, string> = {
  contribution: 'success',
  loan_repayment: 'info',
  fine: 'destructive',
  loan_disbursement: 'gold',
}

export function StatementsPage() {
  const [period, setPeriod] = useState('all')

  const columns: Column<typeof transactions[0]>[] = [
    { key: 'date', header: 'Date', sortable: true, render: (v) => formatDate(v as string) },
    { key: 'description', header: 'Description', className: 'max-w-xs' },
    {
      key: 'type',
      header: 'Type',
      render: (v) => (
        <Badge variant={typeColor[v as string] as 'success'} className="capitalize">
          {String(v).replace('_', ' ')}
        </Badge>
      ),
    },
    {
      key: 'amount',
      header: 'Amount',
      render: (v) => (
        <span className={(v as number) >= 0 ? 'text-emerald-600 font-semibold' : 'text-red-500 font-semibold'}>
          {(v as number) >= 0 ? '+' : ''}{formatCurrency(v as number)}
        </span>
      ),
    },
    { key: 'balance', header: 'Balance', render: (v) => formatCurrency(v as number) },
    { key: 'reference', header: 'Reference', render: (v) => <code className="text-xs bg-muted px-1.5 py-0.5 rounded">{String(v)}</code> },
  ]

  const totalContributions = transactions.filter(t => t.type === 'contribution').reduce((s, t) => s + t.amount, 0)
  const totalRepayments = transactions.filter(t => t.type === 'loan_repayment').reduce((s, t) => s + Math.abs(t.amount), 0)
  const totalFines = transactions.filter(t => t.type === 'fine').reduce((s, t) => s + Math.abs(t.amount), 0)

  return (
    <div className="space-y-6">
      <PageHeader
        title="My Statement"
        description="Complete transaction history"
        actions={
          <Button variant="outline" onClick={() => toast.info('Downloading PDF...')}>
            <Download className="h-4 w-4" /> Export PDF
          </Button>
        }
      />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatsCard title="Total Contributions" value={formatCurrency(totalContributions)} icon={Wallet} variant="success" />
        <StatsCard title="Total Repayments" value={formatCurrency(totalRepayments)} icon={CreditCard} variant="primary" />
        <StatsCard title="Total Fines Paid" value={formatCurrency(totalFines)} icon={AlertTriangle} variant="danger" />
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between flex-wrap gap-3">
          <CardTitle className="text-base">Transaction History</CardTitle>
          <div className="flex items-center gap-2">
            <Select value={period} onValueChange={setPeriod}>
              <SelectTrigger className="w-36">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Time</SelectItem>
                <SelectItem value="2026">Year 2026</SelectItem>
                <SelectItem value="q3">Q3 2026</SelectItem>
                <SelectItem value="q2">Q2 2026</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <DataTable
            data={transactions as unknown as Record<string, unknown>[]}
            columns={columns as unknown as Column<Record<string, unknown>>[]}
            searchable={false}
          />
        </CardContent>
      </Card>
    </div>
  )
}
