import React from 'react'
import { motion } from 'framer-motion'
import {
  Wallet, TrendingUp, CreditCard, AlertTriangle, Star,
  Clock, ArrowUpRight, ArrowDownLeft, CheckCircle, XCircle
} from 'lucide-react'
import { StatsCard } from '@/components/shared/StatsCard'
import { PageHeader } from '@/components/shared/PageHeader'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { useAuth } from '@/context/AuthContext'
import { formatCurrency, formatDate, getCreditScoreColor, getCreditScoreLabel, getInitials } from '@/lib/utils'
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Legend
} from 'recharts'
import { useNavigate } from 'react-router-dom'

// Mock data – replaced with real Supabase calls in production
const contributionTrend = [
  { month: 'Jan', amount: 5000 }, { month: 'Feb', amount: 5000 },
  { month: 'Mar', amount: 5000 }, { month: 'Apr', amount: 5000 },
  { month: 'May', amount: 5000 }, { month: 'Jun', amount: 5000 },
]

const recentTransactions = [
  { id: '1', type: 'contribution', description: 'Monthly Contribution', amount: 5000, date: '2026-07-31', status: 'completed' },
  { id: '2', type: 'loan_repayment', description: 'Loan Repayment', amount: 3500, date: '2026-07-25', status: 'completed' },
  { id: '3', type: 'fine', description: 'Late Payment Fine', amount: 500, date: '2026-07-20', status: 'completed' },
  { id: '4', type: 'contribution', description: 'Monthly Contribution', amount: 5000, date: '2026-06-30', status: 'completed' },
]

const loanSchedule = [
  { month: 'Aug', principal: 2500, interest: 1000 },
  { month: 'Sep', principal: 2500, interest: 900 },
  { month: 'Oct', principal: 2500, interest: 800 },
  { month: 'Nov', principal: 2500, interest: 700 },
]

const upcomingItems = [
  { type: 'contribution', label: 'Monthly Contribution', date: '2026-08-31', amount: 5000 },
  { type: 'loan', label: 'Loan Repayment', date: '2026-08-25', amount: 3500 },
  { type: 'meeting', label: 'Monthly Meeting', date: '2026-08-15', amount: 0 },
]

export function MemberDashboard() {
  const { profile } = useAuth()
  const navigate = useNavigate()

  const creditScore = profile?.credit_score ?? 720
  const creditScoreColor = getCreditScoreColor(creditScore)
  const creditLabel = getCreditScoreLabel(creditScore)

  const stats = [
    {
      title: 'Total Contributions',
      value: formatCurrency(85000),
      description: 'Since joining',
      icon: Wallet,
      variant: 'success' as const,
      trend: 8,
    },
    {
      title: 'Current Savings',
      value: formatCurrency(42500),
      description: 'Available balance',
      icon: TrendingUp,
      variant: 'primary' as const,
      trend: 5,
    },
    {
      title: 'Loan Balance',
      value: formatCurrency(28000),
      description: '8 months remaining',
      icon: CreditCard,
      variant: 'warning' as const,
    },
    {
      title: 'Available Loan Limit',
      value: formatCurrency(127500),
      description: '3× your contributions',
      icon: ArrowUpRight,
      variant: 'gold' as const,
    },
    {
      title: 'Credit Score',
      value: creditScore,
      description: creditLabel,
      icon: Star,
      variant: 'default' as const,
    },
    {
      title: 'Outstanding Fines',
      value: formatCurrency(500),
      description: '1 unpaid fine',
      icon: AlertTriangle,
      variant: 'danger' as const,
    },
  ]

  return (
    <div className="space-y-6">
      {/* Welcome banner */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-2xl bg-gradient-to-r from-emerald-600 to-emerald-800 p-6 text-white overflow-hidden relative"
      >
        <div className="absolute right-0 top-0 w-64 h-full opacity-10">
          <div className="w-64 h-64 rounded-full bg-white translate-x-20 -translate-y-10" />
        </div>
        <div className="relative">
          <div className="flex items-center gap-4">
            <Avatar className="h-12 w-12 border-2 border-white/30">
              <AvatarFallback className="bg-white/20 text-white font-bold">
                {getInitials(profile?.full_name || 'User')}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="text-emerald-200 text-sm">Good morning,</p>
              <h2 className="text-xl font-bold">{profile?.full_name || 'Member'} 👋</h2>
            </div>
          </div>
          <div className="mt-4 flex flex-wrap gap-4">
            <div className="bg-white/10 rounded-lg px-4 py-2">
              <p className="text-emerald-200 text-xs">Wallet Balance</p>
              <p className="font-bold text-lg">{formatCurrency(profile?.wallet_balance ?? 0)}</p>
            </div>
            <div className="bg-white/10 rounded-lg px-4 py-2">
              <p className="text-emerald-200 text-xs">Next Contribution</p>
              <p className="font-bold text-lg">{formatDate('2026-08-31')}</p>
            </div>
          </div>
        </div>
      </motion.div>

      <PageHeader title="My Dashboard" description="Overview of your Chama financial activity" />

      {/* Stats grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
          >
            <StatsCard {...stat} />
          </motion.div>
        ))}
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Contribution trend */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Contribution History</CardTitle>
            <CardDescription>Your monthly contribution trend</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={contributionTrend} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
                <defs>
                  <linearGradient id="contribGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#059669" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#059669" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} tickFormatter={v => `${v / 1000}k`} />
                <Tooltip formatter={(v: number) => [formatCurrency(v), 'Amount']} />
                <Area type="monotone" dataKey="amount" stroke="#059669" fill="url(#contribGrad)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Loan repayment schedule */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Loan Repayment Schedule</CardTitle>
            <CardDescription>Principal vs Interest breakdown</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={loanSchedule} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} tickFormatter={v => `${v / 1000}k`} />
                <Tooltip formatter={(v: number) => formatCurrency(v)} />
                <Legend />
                <Bar dataKey="principal" fill="#059669" radius={[4, 4, 0, 0]} name="Principal" />
                <Bar dataKey="interest" fill="#f59e0b" radius={[4, 4, 0, 0]} name="Interest" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Bottom row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent transactions */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-base">Recent Transactions</CardTitle>
                <CardDescription>Your latest financial activity</CardDescription>
              </div>
              <Button variant="outline" size="sm" onClick={() => navigate('/member/statements')}>
                View All
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentTransactions.map(tx => (
                  <div key={tx.id} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-full ${
                        tx.type === 'contribution' ? 'bg-emerald-100 dark:bg-emerald-900/30' :
                        tx.type === 'loan_repayment' ? 'bg-blue-100 dark:bg-blue-900/30' :
                        'bg-red-100 dark:bg-red-900/30'
                      }`}>
                        {tx.type === 'contribution' ? (
                          <ArrowDownLeft className="h-4 w-4 text-emerald-600" />
                        ) : tx.type === 'loan_repayment' ? (
                          <ArrowUpRight className="h-4 w-4 text-blue-600" />
                        ) : (
                          <AlertTriangle className="h-4 w-4 text-red-500" />
                        )}
                      </div>
                      <div>
                        <p className="text-sm font-medium">{tx.description}</p>
                        <p className="text-xs text-muted-foreground">{formatDate(tx.date)}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-semibold">{formatCurrency(tx.amount)}</p>
                      <Badge variant="success" className="text-xs">
                        {tx.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right column */}
        <div className="space-y-6">
          {/* Credit score card */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Credit Score</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center mb-4">
                <p className={`text-4xl font-bold ${creditScoreColor}`}>{creditScore}</p>
                <p className={`text-sm font-medium ${creditScoreColor}`}>{creditLabel}</p>
              </div>
              <Progress value={((creditScore - 300) / 600) * 100} className="h-3" />
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>300</span><span>900</span>
              </div>
            </CardContent>
          </Card>

          {/* Upcoming items */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Upcoming</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {upcomingItems.map((item, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <Clock className="h-4 w-4 text-muted-foreground shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{item.label}</p>
                      <p className="text-xs text-muted-foreground">{formatDate(item.date)}</p>
                    </div>
                    {item.amount > 0 && (
                      <span className="text-sm font-semibold shrink-0">{formatCurrency(item.amount)}</span>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick actions */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button className="w-full" size="sm" onClick={() => navigate('/member/contributions')}>
                <Wallet className="h-4 w-4" /> Pay Contribution
              </Button>
              <Button variant="outline" className="w-full" size="sm" onClick={() => navigate('/member/loans')}>
                <CreditCard className="h-4 w-4" /> Apply for Loan
              </Button>
              <Button variant="outline" className="w-full" size="sm" onClick={() => navigate('/member/statements')}>
                <TrendingUp className="h-4 w-4" /> View Statement
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
