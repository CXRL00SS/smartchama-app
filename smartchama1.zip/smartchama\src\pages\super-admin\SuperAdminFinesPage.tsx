/**
 * Super Admin — Fine Management Control Panel
 * Shows platform-wide fine stats, revenue, transaction history.
 * Only accessible to super_admin role.
 */

import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  AlertTriangle, CheckCircle, Clock, XCircle, TrendingUp, Wallet,
  Download, Filter, RefreshCw, DollarSign, Users, Building2
} from 'lucide-react'
import { PageHeader } from '@/components/shared/PageHeader'
import { StatsCard } from '@/components/shared/StatsCard'
import { DataTable, Column } from '@/components/shared/DataTable'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { formatCurrency, formatDate, formatRelativeTime } from '@/lib/utils'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, LineChart, Line
} from 'recharts'
import { toast } from 'sonner'
import type { Fine, PlatformRevenueLedger } from '@/types'

// Mock data — replace with Firestore queries once deployed
const mockFines: Fine[] = [
  { id: 'f1', group_id: 'g1', member_id: 'm1', type: 'missed_meeting', amount: 300, reason: 'Missed July meeting', status: 'paid', issued_at: '2026-07-18', paid_at: '2026-07-20', created_by: 'admin1', platform_fee: 5, platform_fee_collected: true },
  { id: 'f2', group_id: 'g2', member_id: 'm3', type: 'lateness', amount: 50, reason: 'Arrived 25 minutes late', status: 'paid', issued_at: '2026-07-18', paid_at: '2026-07-19', created_by: 'admin2', platform_fee: 5, platform_fee_collected: true },
  { id: 'f3', group_id: 'g1', member_id: 'm2', type: 'late_contribution', amount: 500, reason: 'Late July contribution', status: 'pending', issued_at: '2026-08-01', created_by: 'admin1', platform_fee: 0, platform_fee_collected: false },
  { id: 'f4', group_id: 'g3', member_id: 'm5', type: 'absence', amount: 300, reason: 'Absent without notice', status: 'disputed', issued_at: '2026-07-15', created_by: 'admin3', platform_fee: 0, platform_fee_collected: false },
  { id: 'f5', group_id: 'g2', member_id: 'm4', type: 'custom', amount: 1000, reason: 'Property damage at venue', status: 'approved', issued_at: '2026-07-22', created_by: 'admin2', platform_fee: 5, platform_fee_collected: false },
]

const mockRevenue: (PlatformRevenueLedger & { group_name: string; member_name: string })[] = [
  { id: 'r1', fine_id: 'f1', payment_id: 'p1', provider_reference: 'MPE001', group_id: 'g1', member_id: 'm1', gross_fine_amount: 300, platform_fee_amount: 5, provider_charge: 0, net_platform_revenue: 5, chama_net_amount: 295, currency: 'KES', status: 'collected', collected_at: '2026-07-20T10:30:00Z', idempotency_key: 'fine_f1_m1', created_at: '2026-07-20T10:30:00Z', group_name: 'Pamoja Savings', member_name: 'Alice Wanjiku' },
  { id: 'r2', fine_id: 'f2', payment_id: 'p2', provider_reference: 'MPE002', group_id: 'g2', member_id: 'm3', gross_fine_amount: 50, platform_fee_amount: 5, provider_charge: 0, net_platform_revenue: 5, chama_net_amount: 45, currency: 'KES', status: 'collected', collected_at: '2026-07-19T14:22:00Z', idempotency_key: 'fine_f2_m3', created_at: '2026-07-19T14:22:00Z', group_name: 'Amani Chama', member_name: 'Carol Achieng' },
]

const monthlyRevenue = [
  { month: 'Feb', fines_collected: 18, revenue: 90 },
  { month: 'Mar', fines_collected: 22, revenue: 110 },
  { month: 'Apr', fines_collected: 15, revenue: 75 },
  { month: 'May', fines_collected: 28, revenue: 140 },
  { month: 'Jun', fines_collected: 31, revenue: 155 },
  { month: 'Jul', fines_collected: 24, revenue: 120 },
]

const statusBadge: Record<string, React.ReactNode> = {
  paid: <Badge variant="success">Paid</Badge>,
  pending: <Badge variant="warning">Pending</Badge>,
  approved: <Badge variant="info">Approved</Badge>,
  pending_approval: <Badge variant="warning">Pending Approval</Badge>,
  disputed: <Badge variant="destructive">Disputed</Badge>,
  waived: <Badge variant="secondary">Waived</Badge>,
  cancelled: <Badge variant="secondary">Cancelled</Badge>,
  draft: <Badge variant="secondary">Draft</Badge>,
}

export function SuperAdminFinesPage() {
  const [dateFilter, setDateFilter] = useState('all')
  const [statusFilter, setStatusFilter] = useState('all')
  const [loading, setLoading] = useState(false)

  const totalFinesIssued = mockFines.length
  const totalFinesPaid = mockFines.filter(f => f.status === 'paid').length
  const totalPending = mockFines.filter(f => ['pending', 'approved'].includes(f.status)).length
  const totalRevenue = mockRevenue.reduce((s, r) => s + r.platform_fee_amount, 0)
  const totalRefunds = 0
  const netRevenue = totalRevenue - totalRefunds
  const groupsUsingFines = new Set(mockFines.map(f => f.group_id)).size

  const fineColumns: Column<typeof mockFines[0]>[] = [
    { key: 'group_id', header: 'Group', render: () => <span className="text-xs">Pamoja Savings</span> },
    { key: 'type', header: 'Type', render: (v) => <span className="capitalize text-xs">{String(v).replace(/_/g, ' ')}</span> },
    { key: 'reason', header: 'Reason', className: 'max-w-48' },
    { key: 'amount', header: 'Amount', render: (v) => <span className="font-semibold">KSh {v as number}</span> },
    {
      key: 'platform_fee',
      header: 'Platform Fee',
      render: (v, row) => (
        <span className={row.platform_fee_collected ? 'text-emerald-600 font-medium' : 'text-muted-foreground'}>
          {v ? `KSh ${v}` : '—'}
        </span>
      ),
    },
    { key: 'issued_at', header: 'Issued', render: (v) => formatDate(v as string) },
    { key: 'status', header: 'Status', render: (v) => statusBadge[v as string] ?? <Badge>{String(v)}</Badge> },
  ]

  const revenueColumns: Column<typeof mockRevenue[0]>[] = [
    { key: 'collected_at', header: 'Date', render: (v) => formatDate(v as string) },
    { key: 'group_name', header: 'Group' },
    { key: 'member_name', header: 'Member' },
    { key: 'gross_fine_amount', header: 'Fine Amount', render: (v) => <span>KSh {v as number}</span> },
    { key: 'platform_fee_amount', header: 'Platform Fee', render: (v) => <span className="font-semibold text-emerald-600">KSh {v as number}</span> },
    { key: 'chama_net_amount', header: 'Chama Receives', render: (v) => <span>KSh {v as number}</span> },
    { key: 'provider_reference', header: 'M-Pesa Ref', render: (v) => <code className="text-xs bg-muted px-1.5 py-0.5 rounded">{String(v)}</code> },
    { key: 'status', header: 'Status', render: (v) => <Badge variant={v === 'collected' ? 'success' : v === 'refunded' ? 'warning' : 'secondary'} className="capitalize">{String(v)}</Badge> },
  ]

  const exportCSV = () => {
    const rows = [
      ['Date', 'Group', 'Member', 'Fine Amount (KSh)', 'Platform Fee (KSh)', 'Chama Receives (KSh)', 'M-Pesa Ref', 'Status'],
      ...mockRevenue.map(r => [
        r.collected_at.slice(0, 10),
        r.group_name,
        r.member_name,
        r.gross_fine_amount,
        r.platform_fee_amount,
        r.chama_net_amount,
        r.provider_reference,
        r.status,
      ]),
    ]
    const csv = rows.map(r => r.join(',')).join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `smartchama-revenue-${new Date().toISOString().slice(0, 10)}.csv`
    a.click()
    URL.revokeObjectURL(url)
    toast.success('Revenue report exported')
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Fine Management & Revenue"
        description="Platform-wide fine analytics and KSh 5 service fee revenue"
        actions={
          <Button variant="outline" onClick={exportCSV}>
            <Download className="h-4 w-4" /> Export CSV
          </Button>
        }
      />

      {/* Key stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { title: 'Fines Issued', value: totalFinesIssued, icon: AlertTriangle, variant: 'default' as const },
          { title: 'Fines Paid', value: totalFinesPaid, icon: CheckCircle, variant: 'success' as const },
          { title: 'Pending / Approved', value: totalPending, icon: Clock, variant: 'warning' as const },
          { title: 'Groups Using Fines', value: groupsUsingFines, icon: Building2, variant: 'primary' as const },
        ].map((s, i) => (
          <motion.div key={s.title} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
            <StatsCard {...s} />
          </motion.div>
        ))}
      </div>

      {/* Revenue stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { title: 'Gross Revenue (KSh 5 × payments)', value: `KSh ${totalRevenue}`, icon: TrendingUp, variant: 'gold' as const },
          { title: 'Total Refunds', value: `KSh ${totalRefunds}`, icon: XCircle, variant: 'danger' as const },
          { title: 'Net Platform Revenue', value: `KSh ${netRevenue}`, icon: DollarSign, variant: 'success' as const },
          { title: 'Successful Fee Collections', value: mockRevenue.length, icon: Wallet, variant: 'primary' as const },
        ].map((s, i) => (
          <motion.div key={s.title} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 + 0.2 }}>
            <StatsCard {...s} />
          </motion.div>
        ))}
      </div>

      {/* Revenue chart */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Monthly Revenue Trend</CardTitle>
            <CardDescription>KSh 5 platform fee per successful fine payment</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={monthlyRevenue} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis yAxisId="left" tick={{ fontSize: 12 }} />
                <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 12 }} />
                <Tooltip />
                <Legend />
                <Bar yAxisId="left" dataKey="fines_collected" name="Fines Paid" fill="#059669" radius={[4,4,0,0]} />
                <Bar yAxisId="right" dataKey="revenue" name="Revenue (KSh)" fill="#f59e0b" radius={[4,4,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Revenue Accumulation</CardTitle>
            <CardDescription>Cumulative platform fee revenue</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={monthlyRevenue.map((d, i) => ({
                ...d,
                cumulative: monthlyRevenue.slice(0, i + 1).reduce((s, r) => s + r.revenue, 0)
              }))} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip formatter={(v: number) => [`KSh ${v}`, 'Cumulative Revenue']} />
                <Line type="monotone" dataKey="cumulative" stroke="#059669" strokeWidth={2} dot={{ fill: '#059669' }} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Tabs: All Fines / Revenue Entries */}
      <Tabs defaultValue="fines">
        <div className="flex items-center justify-between flex-wrap gap-3 mb-4">
          <TabsList>
            <TabsTrigger value="fines">All Fines ({mockFines.length})</TabsTrigger>
            <TabsTrigger value="revenue">Revenue Ledger ({mockRevenue.length})</TabsTrigger>
          </TabsList>
          <div className="flex gap-2">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-36 h-8 text-xs"><SelectValue placeholder="Status" /></SelectTrigger>
              <SelectContent>
                {['all', 'paid', 'pending', 'approved', 'disputed', 'waived', 'cancelled'].map(s => (
                  <SelectItem key={s} value={s} className="capitalize">{s === 'all' ? 'All Statuses' : s}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={dateFilter} onValueChange={setDateFilter}>
              <SelectTrigger className="w-36 h-8 text-xs"><SelectValue placeholder="Period" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Time</SelectItem>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="week">This Week</SelectItem>
                <SelectItem value="month">This Month</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <TabsContent value="fines">
          <Card>
            <CardContent className="pt-4">
              <DataTable
                data={mockFines as unknown as Record<string, unknown>[]}
                columns={fineColumns as unknown as Column<Record<string, unknown>>[]}
                searchable={false}
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="revenue">
          <Card>
            <CardContent className="pt-4">
              <DataTable
                data={mockRevenue as unknown as Record<string, unknown>[]}
                columns={revenueColumns as unknown as Column<Record<string, unknown>>[]}
                searchable={false}
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
