import React from 'react'
import { Download, FileText, BarChart3, Users, CreditCard, Wallet } from 'lucide-react'
import { PageHeader } from '@/components/shared/PageHeader'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { toast } from 'sonner'

const reports = [
  {
    category: 'Contribution Reports',
    icon: Wallet,
    color: 'text-emerald-600',
    bg: 'bg-emerald-50 dark:bg-emerald-950/20',
    items: [
      { name: 'Monthly Contribution Report', description: 'All contributions for the selected month', formats: ['PDF', 'Excel', 'CSV'] },
      { name: 'Annual Contribution Summary', description: 'Year-to-date contributions per member', formats: ['PDF', 'Excel'] },
      { name: 'Defaulters Report', description: 'Members with outstanding contributions', formats: ['PDF', 'CSV'] },
    ],
  },
  {
    category: 'Loan Reports',
    icon: CreditCard,
    color: 'text-blue-600',
    bg: 'bg-blue-50 dark:bg-blue-950/20',
    items: [
      { name: 'Active Loans Summary', description: 'All active loans with balances', formats: ['PDF', 'Excel'] },
      { name: 'Loan Repayment Schedule', description: 'Monthly repayment schedule per member', formats: ['PDF'] },
      { name: 'Loan Performance Report', description: 'Disbursements, repayments, defaults', formats: ['PDF', 'Excel', 'CSV'] },
    ],
  },
  {
    category: 'Member Reports',
    icon: Users,
    color: 'text-purple-600',
    bg: 'bg-purple-50 dark:bg-purple-950/20',
    items: [
      { name: 'Member Statement', description: 'Individual financial statement for any member', formats: ['PDF'] },
      { name: 'Member Register', description: 'Full list of all group members', formats: ['PDF', 'Excel', 'CSV'] },
      { name: 'Credit Score Report', description: 'Credit scores for all members', formats: ['PDF', 'Excel'] },
    ],
  },
  {
    category: 'Financial Statements',
    icon: BarChart3,
    color: 'text-gold-600',
    bg: 'bg-gold-50 dark:bg-gold-950/20',
    items: [
      { name: 'Income Statement', description: 'Revenue, expenses, and net income', formats: ['PDF', 'Excel'] },
      { name: 'Balance Sheet', description: 'Assets, liabilities, and equity', formats: ['PDF'] },
      { name: 'Cash Flow Statement', description: 'Cash inflows and outflows', formats: ['PDF', 'Excel', 'CSV'] },
    ],
  },
]

const formatColors: Record<string, string> = {
  PDF: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',
  Excel: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400',
  CSV: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
}

export function ReportsPage() {
  const handleDownload = (reportName: string, format: string) => {
    toast.success(`Generating ${format} report...`, { description: reportName })
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Reports" description="Generate and export group financial reports" />

      <div className="grid gap-6">
        {reports.map((category) => {
          const Icon = category.icon
          return (
            <Card key={category.category}>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <div className={`p-2 rounded-lg ${category.bg}`}>
                    <Icon className={`h-4 w-4 ${category.color}`} />
                  </div>
                  {category.category}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="divide-y divide-border">
                  {category.items.map((item) => (
                    <div key={item.name} className="flex items-center justify-between py-3 first:pt-0 last:pb-0 flex-wrap gap-3">
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm">{item.name}</p>
                        <p className="text-xs text-muted-foreground">{item.description}</p>
                      </div>
                      <div className="flex items-center gap-2 flex-wrap">
                        {item.formats.map(fmt => (
                          <button
                            key={fmt}
                            onClick={() => handleDownload(item.name, fmt)}
                            className={`flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full transition-opacity hover:opacity-80 ${formatColors[fmt]}`}
                          >
                            <Download className="h-3 w-3" />
                            {fmt}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
