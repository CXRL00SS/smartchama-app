import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Eye, EyeOff, Lock, Mail, User, Phone, ArrowRight, Users, Crown } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { useAuth } from '@/context/AuthContext'
import { doc, updateDoc } from 'firebase/firestore'
import { db, auth as firebaseAuth } from '@/lib/firebase'
import { toast } from 'sonner'

const registerSchema = z.object({
  fullName: z.string().min(2, 'Full name is required'),
  email: z.string().email('Enter a valid email'),
  phone: z.string().optional(),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  confirmPassword: z.string(),
}).refine(d => d.password === d.confirmPassword, {
  message: 'Passwords do not match',
  path: ['confirmPassword'],
})

type RegisterForm = z.infer<typeof registerSchema>

const accountTypes = [
  {
    role: 'chairperson' as const,
    label: 'Chairperson',
    emoji: '👑',
    description: 'Start and manage your own Chama group',
    features: [
      'Create your own Chama group',
      'Appoint Secretary, Treasurer & more',
      'Manage members and contributions',
      'Full group administration',
    ],
    color: 'border-gold-400 bg-gold-50 dark:bg-gold-950/20',
    activeColor: 'border-gold-500 bg-gold-100 dark:bg-gold-900/30 ring-2 ring-gold-400',
    badgeColor: 'bg-gold-500',
  },
  {
    role: 'member' as const,
    label: 'Member',
    emoji: '👤',
    description: 'Join existing Chama groups in your area',
    features: [
      'Browse and join Chama groups',
      'Make contributions online',
      'Apply for loans',
      'Track your savings',
    ],
    color: 'border-emerald-400 bg-emerald-50 dark:bg-emerald-950/20',
    activeColor: 'border-emerald-500 bg-emerald-100 dark:bg-emerald-900/30 ring-2 ring-emerald-400',
    badgeColor: 'bg-emerald-600',
  },
]

export function RegisterPage() {
  const { signUp } = useAuth()
  const navigate = useNavigate()
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirm, setShowConfirm] = useState(false)
  const [selectedRole, setSelectedRole] = useState<'chairperson' | 'member' | null>(null)

  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<RegisterForm>({
    resolver: zodResolver(registerSchema),
  })

  const onSubmit = async (data: RegisterForm) => {
    if (!selectedRole) {
      toast.error('Please select an account type')
      return
    }

    const { error } = await signUp(data.email, data.password, data.fullName, data.phone)
    if (error) { toast.error('Registration failed', { description: error }); return }

    // Update role if chairperson (default is member)
    if (selectedRole === 'chairperson') {
      try {
        await new Promise(r => setTimeout(r, 800))
        const currentUser = firebaseAuth.currentUser
        if (currentUser) {
          await updateDoc(doc(db, 'profiles', currentUser.uid), { role: 'chairperson' })
        }
      } catch (e) {
        console.error('Role update failed:', e)
      }
    }

    toast.success('Account created!', {
      description: selectedRole === 'chairperson'
        ? 'You can now create your Chama group.'
        : 'You can now browse and join Chama groups.',
    })

    navigate(selectedRole === 'chairperson' ? '/admin' : '/member', { replace: true })
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-emerald-950 via-emerald-900 to-emerald-800 p-4 py-8">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/3 -left-20 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/3 -right-20 w-96 h-96 bg-gold-500/10 rounded-full blur-3xl" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}
        className="w-full max-w-lg relative"
      >
        {/* Logo */}
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-3">
            <img src="/logo.png" alt="Smart Chama" className="h-24 object-contain drop-shadow-lg" />
          </div>
          <p className="text-emerald-300 mt-1 text-sm">Save Together • Grow Together • Succeed Together</p>
        </div>

        <Card className="shadow-2xl border-emerald-800/30 bg-card/95 backdrop-blur-sm">
          <CardHeader className="space-y-1 pb-4">
            <CardTitle className="text-2xl">Create your account</CardTitle>
            <CardDescription>Choose how you want to use Smart Chama</CardDescription>
          </CardHeader>
          <CardContent>
            {/* Step 1 — Account type selector */}
            <div className="space-y-3 mb-6">
              <Label className="text-sm font-semibold">I want to...</Label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {accountTypes.map(type => (
                  <button
                    key={type.role}
                    type="button"
                    onClick={() => setSelectedRole(type.role)}
                    className={`relative flex flex-col items-start p-4 rounded-xl border-2 text-left transition-all
                      ${selectedRole === type.role ? type.activeColor : type.color + ' hover:brightness-95'}`}
                  >
                    {selectedRole === type.role && (
                      <span className={`absolute top-2 right-2 w-5 h-5 rounded-full ${type.badgeColor} flex items-center justify-center`}>
                        <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                        </svg>
                      </span>
                    )}
                    <span className="text-2xl mb-2">{type.emoji}</span>
                    <span className="font-semibold text-foreground">{type.label}</span>
                    <span className="text-xs text-muted-foreground mt-1">{type.description}</span>
                    <ul className="mt-3 space-y-1">
                      {type.features.map(f => (
                        <li key={f} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                          <span className="w-1 h-1 rounded-full bg-muted-foreground/50 shrink-0" />
                          {f}
                        </li>
                      ))}
                    </ul>
                  </button>
                ))}
              </div>
            </div>

            {/* Step 2 — Form (only show after role selected) */}
            <AnimatePresence>
              {selectedRole && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="border-t border-border pt-4 mb-4">
                    <p className="text-sm text-muted-foreground">
                      Registering as <span className="font-semibold text-foreground capitalize">{selectedRole}</span>
                    </p>
                  </div>

                  <form onSubmit={handleSubmit(onSubmit)} className="space-y-4" noValidate>
                    <div className="space-y-2">
                      <Label htmlFor="fullName">Full Name</Label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input id="fullName" placeholder="John Kamau" className="pl-9" autoComplete="name" {...register('fullName')} />
                      </div>
                      {errors.fullName && <p className="text-xs text-destructive">{errors.fullName.message}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input id="email" type="email" placeholder="you@example.com" className="pl-9" autoComplete="email" {...register('email')} />
                      </div>
                      {errors.email && <p className="text-xs text-destructive">{errors.email.message}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number <span className="text-muted-foreground">(optional)</span></Label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input id="phone" type="tel" placeholder="0712 345 678" className="pl-9" {...register('phone')} />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="password">Password</Label>
                        <div className="relative">
                          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                          <Input id="password" type={showPassword ? 'text' : 'password'} placeholder="Min. 8 chars" className="pl-9 pr-9" {...register('password')} />
                          <button type="button" onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground" tabIndex={-1}>
                            {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </button>
                        </div>
                        {errors.password && <p className="text-xs text-destructive">{errors.password.message}</p>}
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="confirmPassword">Confirm Password</Label>
                        <div className="relative">
                          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                          <Input id="confirmPassword" type={showConfirm ? 'text' : 'password'} placeholder="Repeat" className="pl-9 pr-9" {...register('confirmPassword')} />
                          <button type="button" onClick={() => setShowConfirm(!showConfirm)}
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground" tabIndex={-1}>
                            {showConfirm ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </button>
                        </div>
                        {errors.confirmPassword && <p className="text-xs text-destructive">{errors.confirmPassword.message}</p>}
                      </div>
                    </div>

                    <Button type="submit" className="w-full" size="lg" loading={isSubmitting}>
                      Create {selectedRole === 'chairperson' ? 'Chairperson' : 'Member'} Account
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </form>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="mt-6 text-center text-sm text-muted-foreground">
              Already have an account?{' '}
              <Link to="/auth/login" className="text-primary font-medium hover:underline">Sign in</Link>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
