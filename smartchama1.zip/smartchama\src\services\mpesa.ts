/**
 * M-Pesa Daraja API Service
 * Calls a Firebase Cloud Function which securely handles Daraja API credentials.
 */

import { httpsCallable } from 'firebase/functions'
import { functions } from '@/lib/firebase'
import { normalizeKenyanPhone, isValidKenyanPhone } from '@/lib/utils'

export interface StkPushParams {
  phoneNumber: string
  amount: number
  accountReference: string
  transactionDesc: string
  groupId: string
  memberId: string
  referenceType: 'contribution' | 'loan_repayment' | 'fine' | 'registration'
  referenceId: string
}

export interface StkPushResult {
  success: boolean
  checkoutRequestId?: string
  merchantRequestId?: string
  error?: string
}

/**
 * Initiate M-Pesa STK Push via Firebase Cloud Function
 */
export async function initiateStkPush(params: StkPushParams): Promise<StkPushResult> {
  if (!isValidKenyanPhone(params.phoneNumber)) {
    return { success: false, error: 'Invalid Kenyan phone number' }
  }

  const phone = normalizeKenyanPhone(params.phoneNumber)

  try {
    const stkPush = httpsCallable(functions, 'mpesaStkPush')
    const result = await stkPush({
      phone_number: phone,
      amount: Math.round(params.amount),
      account_reference: params.accountReference,
      transaction_desc: params.transactionDesc,
      group_id: params.groupId,
      member_id: params.memberId,
      reference_type: params.referenceType,
      reference_id: params.referenceId,
    })

    const data = result.data as Record<string, string>
    return {
      success: true,
      checkoutRequestId: data.CheckoutRequestID,
      merchantRequestId: data.MerchantRequestID,
    }
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Failed to initiate payment'
    return { success: false, error: message }
  }
}
