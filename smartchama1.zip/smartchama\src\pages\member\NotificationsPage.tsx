import React, { useState } from 'react'
import { Bell, CheckCheck, Trash2, Info, AlertTriangle, CheckCircle, XCircle } from 'lucide-react'
import { PageHeader } from '@/components/shared/PageHeader'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { formatRelativeTime } from '@/lib/utils'
import { cn } from '@/lib/utils'
import type { Notification } from '@/types'

const mockNotifications: Notification[] = [
  { id: '1', user_id: 'u1', title: 'Contribution Due Soon', message: 'Your August contribution of KES 5,000 is due on August 31, 2026.', type: 'warning', channel: 'in_app', is_read: false, created_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString() },
  { id: '2', user_id: 'u1', title: 'Loan Approved!', message: 'Your loan application of KES 50,000 has been approved and disbursed.', type: 'success', channel: 'in_app', is_read: false, created_at: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString() },
  { id: '3', user_id: 'u1', title: 'Meeting Reminder', message: 'Monthly meeting scheduled for August 15 at 10:00 AM at Community Hall.', type: 'info', channel: 'in_app', is_read: true, created_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString() },
  { id: '4', user_id: 'u1', title: 'Fine Issued', message: 'A fine of KES 500 has been issued for late July contribution.', type: 'error', channel: 'in_app', is_read: true, created_at: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString() },
  { id: '5', user_id: 'u1', title: 'Payment Confirmed', message: 'Your contribution payment of KES 5,000 (Ref: QJH7X3) has been confirmed.', type: 'success', channel: 'in_app', is_read: true, created_at: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString() },
]

const typeIcon: Record<string, React.ReactNode> = {
  info: <Info className="h-5 w-5 text-blue-500" />,
  success: <CheckCircle className="h-5 w-5 text-emerald-500" />,
  warning: <AlertTriangle className="h-5 w-5 text-yellow-500" />,
  error: <XCircle className="h-5 w-5 text-red-500" />,
}

const typeBg: Record<string, string> = {
  info: 'bg-blue-50 dark:bg-blue-950/20',
  success: 'bg-emerald-50 dark:bg-emerald-950/20',
  warning: 'bg-yellow-50 dark:bg-yellow-950/20',
  error: 'bg-red-50 dark:bg-red-950/20',
}

export function NotificationsPage() {
  const [notifications, setNotifications] = useState(mockNotifications)

  const unreadCount = notifications.filter(n => !n.is_read).length

  const markAllRead = () => {
    setNotifications(ns => ns.map(n => ({ ...n, is_read: true })))
  }

  const markRead = (id: string) => {
    setNotifications(ns => ns.map(n => n.id === id ? { ...n, is_read: true } : n))
  }

  const deleteNotification = (id: string) => {
    setNotifications(ns => ns.filter(n => n.id !== id))
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Notifications"
        description={`${unreadCount} unread notification${unreadCount !== 1 ? 's' : ''}`}
        actions={
          unreadCount > 0 ? (
            <Button variant="outline" size="sm" onClick={markAllRead}>
              <CheckCheck className="h-4 w-4" /> Mark all read
            </Button>
          ) : undefined
        }
      />

      <div className="space-y-3">
        {notifications.length === 0 ? (
          <Card>
            <CardContent className="py-16 text-center">
              <Bell className="h-12 w-12 text-muted-foreground/30 mx-auto mb-4" />
              <p className="text-muted-foreground">No notifications</p>
            </CardContent>
          </Card>
        ) : (
          notifications.map(notification => (
            <Card
              key={notification.id}
              className={cn(
                'transition-all cursor-pointer',
                !notification.is_read && 'ring-1 ring-primary/20',
                typeBg[notification.type]
              )}
              onClick={() => markRead(notification.id)}
            >
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className="shrink-0 mt-0.5">{typeIcon[notification.type]}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <p className={cn('text-sm font-medium', !notification.is_read && 'font-semibold')}>
                        {notification.title}
                        {!notification.is_read && (
                          <span className="ml-2 inline-block w-2 h-2 rounded-full bg-primary" />
                        )}
                      </p>
                      <span className="text-xs text-muted-foreground shrink-0">
                        {formatRelativeTime(notification.created_at)}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground mt-0.5">{notification.message}</p>
                  </div>
                  <button
                    onClick={e => { e.stopPropagation(); deleteNotification(notification.id) }}
                    className="p-1 rounded text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors shrink-0"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}
