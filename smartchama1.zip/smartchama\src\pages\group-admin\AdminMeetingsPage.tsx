import React, { useState } from 'react'
import { Plus, Calendar, Users, CheckCircle } from 'lucide-react'
import { PageHeader } from '@/components/shared/PageHeader'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { formatDate, getInitials } from '@/lib/utils'
import { toast } from 'sonner'

const meetings = [
  {
    id: 'm1', title: 'August Monthly Meeting', scheduled_at: '2026-08-15T10:00:00',
    venue: 'Community Hall, Nairobi', status: 'scheduled', attendees: 0, total_members: 47,
  },
  {
    id: 'm2', title: 'July Monthly Meeting', scheduled_at: '2026-07-18T10:00:00',
    venue: 'Community Hall, Nairobi', status: 'completed', attendees: 42, total_members: 47,
    minutes: 'The July meeting reviewed H1 financials...',
  },
]

const attendance = [
  { name: 'Alice Wanjiku', status: 'present' },
  { name: 'Bob Kipchoge', status: 'present' },
  { name: 'Carol Achieng', status: 'excused' },
  { name: 'David Mwenda', status: 'absent' },
  { name: 'Eva Njoki', status: 'present' },
]

export function AdminMeetingsPage() {
  const [newMeetingOpen, setNewMeetingOpen] = useState(false)
  const [attendanceOpen, setAttendanceOpen] = useState(false)
  const [selectedMeeting, setSelectedMeeting] = useState<typeof meetings[0] | null>(null)
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({ title: '', date: '', time: '10:00', venue: '' })

  const handleCreate = async () => {
    if (!form.title || !form.date) { toast.error('Fill required fields'); return }
    setLoading(true)
    await new Promise(r => setTimeout(r, 1200))
    setLoading(false)
    setNewMeetingOpen(false)
    toast.success('Meeting scheduled!')
    setForm({ title: '', date: '', time: '10:00', venue: '' })
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Meetings"
        description="Schedule and manage group meetings"
        actions={
          <Button onClick={() => setNewMeetingOpen(true)}>
            <Plus className="h-4 w-4" /> Schedule Meeting
          </Button>
        }
      />

      <div className="space-y-4">
        {meetings.map(meeting => (
          <Card key={meeting.id}>
            <CardContent className="p-4">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div className="flex items-start gap-4">
                  <div className="bg-primary/10 rounded-xl p-3 shrink-0">
                    <Calendar className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-semibold">{meeting.title}</h3>
                      <Badge variant={meeting.status === 'completed' ? 'success' : 'info'} className="capitalize">{meeting.status}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">
                      {formatDate(meeting.scheduled_at, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                      {' · '}
                      {new Date(meeting.scheduled_at).toLocaleTimeString('en', { hour: '2-digit', minute: '2-digit' })}
                    </p>
                    <p className="text-sm text-muted-foreground">{meeting.venue}</p>
                    {meeting.status === 'completed' && (
                      <div className="flex items-center gap-1 mt-1 text-sm text-emerald-600">
                        <Users className="h-3.5 w-3.5" />
                        <span>{meeting.attendees}/{meeting.total_members} attended</span>
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex gap-2 sm:flex-col sm:items-end">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => { setSelectedMeeting(meeting); setAttendanceOpen(true) }}
                  >
                    <Users className="h-3.5 w-3.5" />
                    {meeting.status === 'completed' ? 'View Attendance' : 'Take Attendance'}
                  </Button>
                  {meeting.status === 'scheduled' && (
                    <Button size="sm" onClick={() => toast.success('Meeting started')}>
                      Start Meeting
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* New meeting dialog */}
      <Dialog open={newMeetingOpen} onOpenChange={setNewMeetingOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Schedule New Meeting</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label>Title</Label>
              <Input placeholder="e.g. August Monthly Meeting" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>Date</Label>
                <Input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))} />
              </div>
              <div className="space-y-2">
                <Label>Time</Label>
                <Input type="time" value={form.time} onChange={e => setForm(f => ({ ...f, time: e.target.value }))} />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Venue</Label>
              <Input placeholder="e.g. Community Hall, Nairobi" value={form.venue} onChange={e => setForm(f => ({ ...f, venue: e.target.value }))} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setNewMeetingOpen(false)}>Cancel</Button>
            <Button onClick={handleCreate} loading={loading}>Schedule</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Attendance dialog */}
      <Dialog open={attendanceOpen} onOpenChange={setAttendanceOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{selectedMeeting?.title} — Attendance</DialogTitle>
          </DialogHeader>
          <div className="space-y-2 py-2">
            {attendance.map((a, i) => (
              <div key={i} className="flex items-center justify-between p-2 rounded-lg hover:bg-muted/40">
                <div className="flex items-center gap-3">
                  <Avatar className="h-8 w-8"><AvatarFallback className="text-xs">{getInitials(a.name)}</AvatarFallback></Avatar>
                  <span className="text-sm font-medium">{a.name}</span>
                </div>
                <Badge variant={a.status === 'present' ? 'success' : a.status === 'excused' ? 'warning' : 'destructive'} className="capitalize">
                  {a.status}
                </Badge>
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button onClick={() => setAttendanceOpen(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
