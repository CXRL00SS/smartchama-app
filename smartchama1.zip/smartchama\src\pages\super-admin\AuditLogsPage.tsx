/**
 * Super Admin — Audit Logs Page
 * Shows immutable record of all privileged actions.
 */

import React, { useState, useEffect } from 'react'
import { Shield, Search } from 'lucide-react'
import { PageHeader } from '@/components/shared/PageHeader'
import { DataTable, Column } from '@/components/shared/DataTable'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { formatDate, formatRelativeTime } from '@/lib/utils'
import type { AuditLog } from '@/types'

const mockLogs: AuditLog[] = [
  { id: 'al1', user_id: 'u1', action: 'platform_fee_config_changed', resource_type: 'platform_fee_config', old_values: { fee_amount: 0, is_enabled: false }, new_values: { fee_amount: 5, is_enabled: false, reason: 'Initial setup' }, created_at: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString() },
  { id: 'al2', user_id: 'u2', group_id: 'g1', action: 'fine_issued', resource_type: 'fine', resource_id: 'f3', new_values: { member_id: 'm2', amount: 500, reason: 'Late contribution' }, created_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString() },
  { id: 'al3', user_id: 'u3', group_id: 'g1', action: 'fine_payment_initiated', resource_type: 'payment', resource_id: 'p1', new_values: { fine_id: 'f1', amount: 300, platform_fee: 5 }, created_at: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString() },
  { id: 'al4', user_id: 'u1', group_id: 'g2', action: 'fine_waived', resource_type: 'fine', resource_id: 'f4', new_values: { reason: 'Member provided valid evidence for absence' }, created_at: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString() },
  { id: 'al5', user_id: 'u2', group_id: 'g1', action: 'dispute_resolved_cancelled', resource_type: 'fine_dispute', resource_id: 'd1', new_values: { resolution: 'Fine cancelled — incorrect check-in record' }, created_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString() },
  { id: 'al6', user_id: 'u1', action: 'group_suspended', resource_type: 'group', resource_id: 'g5', new_values: { reason: 'Non-payment of subscription' }, created_at: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString() },
]

const actionColors: Record<string, string> = {
  platform_fee_config_changed: 'warning',
  fine_issued: 'info',
  fine_payment_initiated: 'info',
  fine_waived: 'secondary',
  fine_approved: 'success',
  fine_cancelled: 'secondary',
  dispute_resolved_cancelled: 'success',
  dispute_resolved_upheld: 'warning',
  group_suspended: 'destructive',
  group_approved: 'success',
}

export function AuditLogsPage() {
  const [filter, setFilter] = useState('all')

  const filtered = filter === 'all' ? mockLogs : mockLogs.filter(l => l.resource_type === filter)

  const columns: Column<AuditLog>[] = [
    {
      key: 'created_at',
      header: 'Time',
      render: (v) => (
        <div>
          <p className="text-xs font-medium">{formatRelativeTime(v as string)}</p>
          <p className="text-xs text-muted-foreground">{formatDate(v as string)}</p>
        </div>
      ),
    },
    {
      key: 'action',
      header: 'Action',
      render: (v) => (
        <Badge variant={(actionColors[v as string] as 'warning') ?? 'secondary'} className="text-xs capitalize">
          {String(v).replace(/_/g, ' ')}
        </Badge>
      ),
    },
    { key: 'resource_type', header: 'Resource', render: (v) => <span className="text-xs capitalize">{String(v).replace(/_/g, ' ')}</span> },
    { key: 'resource_id', header: 'ID', render: (v) => v ? <code className="text-xs bg-muted px-1 rounded">{String(v).slice(0, 8)}</code> : '—' },
    {
      key: 'new_values',
      header: 'Details',
      render: (v) => v ? (
        <span className="text-xs text-muted-foreground truncate max-w-xs block">
          {Object.entries(v as Record<string, unknown>).slice(0, 2).map(([k, val]) => `${k}: ${val}`).join(' · ')}
        </span>
      ) : '—',
    },
  ]

  return (
    <div className="space-y-6">
      <PageHeader
        title="Audit Logs"
        description="Immutable record of all privileged actions — cannot be edited or deleted"
      />

      <Card className="border-blue-200 bg-blue-50 dark:bg-blue-950/20">
        <CardContent className="p-4 flex gap-3">
          <Shield className="h-5 w-5 text-blue-600 shrink-0 mt-0.5" />
          <p className="text-sm text-blue-700 dark:text-blue-400">
            Audit logs are append-only. No entry can be updated or deleted, even by a Super Admin.
            This ensures a tamper-proof record for compliance and dispute resolution.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between flex-wrap gap-3">
          <CardTitle className="text-base">All Audit Events</CardTitle>
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-44 h-8 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Resources</SelectItem>
              <SelectItem value="platform_fee_config">Fee Config</SelectItem>
              <SelectItem value="fine">Fines</SelectItem>
              <SelectItem value="payment">Payments</SelectItem>
              <SelectItem value="fine_dispute">Disputes</SelectItem>
              <SelectItem value="group">Groups</SelectItem>
            </SelectContent>
          </Select>
        </CardHeader>
        <CardContent>
          <DataTable
            data={filtered as unknown as Record<string, unknown>[]}
            columns={columns as unknown as Column<Record<string, unknown>>[]}
            searchable={false}
            pageSize={20}
          />
        </CardContent>
      </Card>
    </div>
  )
}
