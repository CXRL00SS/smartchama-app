import React, { useState } from 'react'
import { Plus, AlertTriangle, CheckCircle } from 'lucide-react'
import { PageHeader } from '@/components/shared/PageHeader'
import { DataTable, Column } from '@/components/shared/DataTable'
import { StatsCard } from '@/components/shared/StatsCard'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { formatCurrency, formatDate, getInitials } from '@/lib/utils'
import { toast } from 'sonner'
import { Wallet } from 'lucide-react'

const fines = [
  { id: 'f1', member: 'Alice Wanjiku', type: 'late_contribution', amount: 500, reason: 'Late July contribution', status: 'pending', issued_at: '2026-07-20' },
  { id: 'f2', member: 'Bob Kipchoge', type: 'late_contribution', amount: 500, reason: 'Late July contribution', status: 'paid', issued_at: '2026-07-20', paid_at: '2026-07-22' },
  { id: 'f3', member: 'Carol Achieng', type: 'missed_meeting', amount: 300, reason: 'Missed June meeting', status: 'paid', issued_at: '2026-06-21', paid_at: '2026-06-25' },
  { id: 'f4', member: 'David Mwenda', type: 'missed_meeting', amount: 300, reason: 'Missed June meeting, no apology', status: 'waived', issued_at: '2026-06-21' },
]

export function AdminFinesPage() {
  const [issueOpen, setIssueOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({ member: '', type: 'late_contribution', amount: '', reason: '' })

  const totalPending = fines.filter(f => f.status === 'pending').reduce((s, f) => s + f.amount, 0)
  const totalCollected = fines.filter(f => f.status === 'paid').reduce((s, f) => s + f.amount, 0)

  const handleIssue = async () => {
    if (!form.member || !form.amount || !form.reason) { toast.error('Fill all fields'); return }
    setLoading(true)
    await new Promise(r => setTimeout(r, 1000))
    setLoading(false)
    setIssueOpen(false)
    toast.success('Fine issued successfully')
  }

  const columns: Column<typeof fines[0]>[] = [
    {
      key: 'member',
      header: 'Member',
      render: (v) => (
        <div className="flex items-center gap-2">
          <Avatar className="h-7 w-7"><AvatarFallback className="text-xs">{getInitials(v as string)}</AvatarFallback></Avatar>
          <span className="text-sm font-medium">{v as string}</span>
        </div>
      ),
    },
    { key: 'type', header: 'Type', render: (v) => <span className="capitalize text-sm">{String(v).replace(/_/g, ' ')}</span> },
    { key: 'reason', header: 'Reason' },
    { key: 'amount', header: 'Amount', render: (v) => <span className="font-semibold">{formatCurrency(v as number)}</span> },
    { key: 'issued_at', header: 'Issued', render: (v) => formatDate(v as string) },
    {
      key: 'status',
      header: 'Status',
      render: (v) => (
        <Badge variant={v === 'paid' ? 'success' : v === 'waived' ? 'info' : 'destructive'} className="capitalize">{v as string}</Badge>
      ),
    },
    {
      key: 'id',
      header: 'Actions',
      render: (_, row) =>
        row.status === 'pending' ? (
          <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => toast.success(`Fine waived for ${row.member}`)}>
            Waive
          </Button>
        ) : null,
    },
  ]

  return (
    <div className="space-y-6">
      <PageHeader
        title="Fines Management"
        description="Issue and track member fines"
        actions={
          <Button onClick={() => setIssueOpen(true)}>
            <Plus className="h-4 w-4" /> Issue Fine
          </Button>
        }
      />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatsCard title="Total Pending" value={formatCurrency(totalPending)} icon={AlertTriangle} variant="danger" description={`${fines.filter(f => f.status === 'pending').length} fines`} />
        <StatsCard title="Total Collected" value={formatCurrency(totalCollected)} icon={CheckCircle} variant="success" />
        <StatsCard title="Total Fines" value={fines.length} icon={Wallet} variant="default" />
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">All Fines</CardTitle></CardHeader>
        <CardContent>
          <DataTable data={fines as unknown as Record<string, unknown>[]} columns={columns as unknown as Column<Record<string, unknown>>[]} searchable={false} />
        </CardContent>
      </Card>

      <Dialog open={issueOpen} onOpenChange={setIssueOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Issue a Fine</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label>Member</Label>
              <Select value={form.member} onValueChange={v => setForm(f => ({ ...f, member: v }))}>
                <SelectTrigger><SelectValue placeholder="Select member" /></SelectTrigger>
                <SelectContent>
                  {['Alice Wanjiku', 'Bob Kipchoge', 'Carol Achieng', 'David Mwenda'].map(m => (
                    <SelectItem key={m} value={m}>{m}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Fine Type</Label>
              <Select value={form.type} onValueChange={v => setForm(f => ({ ...f, type: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="late_contribution">Late Contribution</SelectItem>
                  <SelectItem value="missed_meeting">Missed Meeting</SelectItem>
                  <SelectItem value="late_loan_payment">Late Loan Payment</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Amount (KES)</Label>
              <Input type="number" placeholder="500" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label>Reason</Label>
              <Input placeholder="Brief description" value={form.reason} onChange={e => setForm(f => ({ ...f, reason: e.target.value }))} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIssueOpen(false)}>Cancel</Button>
            <Button onClick={handleIssue} loading={loading} variant="destructive">Issue Fine</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
