/**
 * Super Admin — Platform Fee Settings Page
 * Configure the KSh 5 platform service fee per successful fine payment.
 * Only accessible to super_admin role.
 *
 * IMPORTANT: Changing the fee does NOT retroactively modify completed payments.
 * Only payments initiated AFTER the change use the new fee.
 * Pending payments at the time of change use the fee that was active when they were created.
 */

import React, { useState, useEffect } from 'react'
import { Shield, AlertTriangle, CheckCircle, Clock, History, Settings } from 'lucide-react'
import { PageHeader } from '@/components/shared/PageHeader'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Separator } from '@/components/ui/separator'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { formatDate, formatRelativeTime } from '@/lib/utils'
import { useAuth } from '@/context/AuthContext'
import { getPlatformFeeConfig, setPlatformFeeConfig, getPlatformFeeHistory, createAuditLog } from '@/services/firestore'
import type { PlatformFeeConfig } from '@/types'
import { toast } from 'sonner'

// Fallback mock history for display before Firestore is populated
const mockHistory: PlatformFeeConfig[] = [
  {
    id: 'h1',
    fee_amount: 5,
    fee_type: 'fixed',
    currency: 'KES',
    is_enabled: false,
    effective_from: '2026-08-04T00:00:00Z',
    changed_by: 'Super Admin',
    change_reason: 'Initial configuration — disabled until payment integration verified',
    created_at: '2026-08-04T00:00:00Z',
  },
]

export function PlatformFeeSettingsPage() {
  const { user, profile } = useAuth()
  const [currentConfig, setCurrentConfig] = useState<PlatformFeeConfig | null>(null)
  const [history, setHistory] = useState<PlatformFeeConfig[]>(mockHistory)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [confirmOpen, setConfirmOpen] = useState(false)

  // Form state
  const [feeAmount, setFeeAmount] = useState('5')
  const [isEnabled, setIsEnabled] = useState(false)
  const [changeReason, setChangeReason] = useState('')

  useEffect(() => {
    loadConfig()
  }, [])

  const loadConfig = async () => {
    setLoading(true)
    try {
      const config = await getPlatformFeeConfig()
      if (config) {
        setCurrentConfig(config)
        setFeeAmount(String(config.fee_amount))
        setIsEnabled(config.is_enabled)
      }
      const hist = await getPlatformFeeHistory()
      if (hist.length > 0) setHistory(hist)
    } catch (err) {
      // Firestore may not have data yet — use defaults
    } finally {
      setLoading(false)
    }
  }

  const handleSave = async () => {
    if (!changeReason.trim()) {
      toast.error('Please enter a reason for the change')
      return
    }
    const amount = parseFloat(feeAmount)
    if (isNaN(amount) || amount < 0 || amount > 1000) {
      toast.error('Fee amount must be between KSh 0 and KSh 1,000')
      return
    }
    setConfirmOpen(true)
  }

  const confirmSave = async () => {
    setSaving(true)
    setConfirmOpen(false)
    try {
      const amount = parseFloat(feeAmount)
      await setPlatformFeeConfig(
        {
          fee_amount: amount,
          fee_type: 'fixed',
          currency: 'KES',
          is_enabled: isEnabled,
          effective_from: new Date().toISOString(),
          changed_by: profile?.full_name ?? user?.uid ?? 'Super Admin',
          change_reason: changeReason,
          previous_amount: currentConfig?.fee_amount,
        },
        user?.uid ?? 'system'
      )
      await createAuditLog({
        user_id: user?.uid ?? 'system',
        action: 'platform_fee_config_changed',
        resource_type: 'platform_fee_config',
        old_values: { fee_amount: currentConfig?.fee_amount, is_enabled: currentConfig?.is_enabled },
        new_values: { fee_amount: amount, is_enabled: isEnabled, reason: changeReason },
      })
      toast.success('Platform fee configuration saved', {
        description: `Fee ${isEnabled ? 'enabled' : 'disabled'} at KSh ${amount}. Existing payments are unaffected.`,
      })
      setChangeReason('')
      await loadConfig()
    } catch (err) {
      toast.error('Failed to save configuration. Check your connection.')
    } finally {
      setSaving(false)
    }
  }

  const hasChanges = currentConfig
    ? parseFloat(feeAmount) !== currentConfig.fee_amount || isEnabled !== currentConfig.is_enabled
    : true

  return (
    <div className="space-y-6 max-w-3xl">
      <PageHeader
        title="Platform Fee Settings"
        description="Configure the SmartChama KSh 5 service fee per verified fine payment"
      />

      {/* Security notice */}
      <Card className="border-yellow-300 bg-yellow-50 dark:bg-yellow-950/20">
        <CardContent className="p-4 flex gap-3">
          <Shield className="h-5 w-5 text-yellow-600 shrink-0 mt-0.5" />
          <div className="text-sm space-y-1">
            <p className="font-semibold text-yellow-800 dark:text-yellow-300">Super Admin Only — Secure Configuration</p>
            <p className="text-yellow-700 dark:text-yellow-400">
              Changes here affect all future fine payments across all groups. Existing completed payments are never retroactively modified.
              All changes are logged to the immutable audit trail.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Current config */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <CardTitle className="text-base">Current Configuration</CardTitle>
              <CardDescription>
                {currentConfig
                  ? `Last updated ${formatRelativeTime(currentConfig.created_at)}`
                  : 'No configuration saved yet — using defaults'}
              </CardDescription>
            </div>
            <Badge variant={isEnabled ? 'success' : 'secondary'} className="text-sm px-3 py-1">
              {isEnabled ? '● Active' : '○ Disabled'}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {loading ? (
            <div className="animate-pulse space-y-4">
              <div className="h-8 bg-muted rounded w-1/2" />
              <div className="h-8 bg-muted rounded w-2/3" />
            </div>
          ) : (
            <>
              {/* Fee enable/disable toggle */}
              <div className="flex items-center justify-between p-4 rounded-xl border border-border bg-muted/30">
                <div>
                  <p className="font-medium">Enable Platform Fee</p>
                  <p className="text-sm text-muted-foreground mt-0.5">
                    {isEnabled
                      ? 'KSh 5 is deducted from the chama\'s receipt on every confirmed fine payment'
                      : 'No platform fee is currently charged — all fine payments go entirely to the chama'}
                  </p>
                </div>
                <Switch
                  checked={isEnabled}
                  onCheckedChange={setIsEnabled}
                  aria-label="Enable platform fee"
                />
              </div>

              {/* Fee amount */}
              <div className="space-y-2">
                <Label htmlFor="fee-amount">Fee Amount (KSh)</Label>
                <div className="flex items-center gap-3">
                  <div className="relative w-48">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm font-medium">KSh</span>
                    <Input
                      id="fee-amount"
                      type="number"
                      min="0"
                      max="1000"
                      step="0.50"
                      value={feeAmount}
                      onChange={e => setFeeAmount(e.target.value)}
                      className="pl-12"
                    />
                  </div>
                  <div className="text-sm text-muted-foreground">
                    per verified successful fine payment
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  Fee type: Fixed amount. Initial configured value: KSh 5.
                </p>
              </div>

              {/* Fee disclosure preview */}
              {isEnabled && (
                <div className="rounded-lg border border-emerald-200 bg-emerald-50 dark:bg-emerald-950/20 p-4 text-sm space-y-2">
                  <p className="font-semibold text-emerald-800 dark:text-emerald-300">Member Disclosure Preview</p>
                  <p className="text-emerald-700 dark:text-emerald-400">
                    When a member pays a fine of <strong>KSh X</strong>, they will see:
                  </p>
                  <div className="rounded bg-white dark:bg-card border border-emerald-200 p-3 space-y-1 text-xs font-mono">
                    <div className="flex justify-between"><span>Fine amount</span><span>KSh X</span></div>
                    <div className="flex justify-between text-orange-600"><span>SmartChama platform fee (deducted from chama receipt)</span><span>KSh {feeAmount}</span></div>
                    <div className="flex justify-between font-bold border-t pt-1"><span>You pay</span><span>KSh X</span></div>
                    <div className="flex justify-between text-muted-foreground"><span>Chama receives</span><span>KSh X − {feeAmount}</span></div>
                  </div>
                  <p className="text-xs text-emerald-600 dark:text-emerald-500">
                    ✓ The member is informed of the fee before confirming payment.
                  </p>
                </div>
              )}

              {/* Change reason */}
              {hasChanges && (
                <div className="space-y-2">
                  <Label htmlFor="change-reason">Reason for Change <span className="text-destructive">*</span></Label>
                  <Input
                    id="change-reason"
                    placeholder="e.g. Payment integration verified and approved by board"
                    value={changeReason}
                    onChange={e => setChangeReason(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">Required — recorded in the immutable audit log</p>
                </div>
              )}

              <Button
                onClick={handleSave}
                disabled={!hasChanges || loading}
                loading={saving}
                className="w-full sm:w-auto"
              >
                <Settings className="h-4 w-4" /> Save Configuration
              </Button>
            </>
          )}
        </CardContent>
      </Card>

      {/* Configuration history */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <History className="h-4 w-4" /> Configuration History
          </CardTitle>
          <CardDescription>Immutable record of all fee configuration changes</CardDescription>
        </CardHeader>
        <CardContent>
          {history.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-6">No configuration changes recorded yet</p>
          ) : (
            <div className="divide-y divide-border">
              {history.map((entry, i) => (
                <div key={entry.id} className="py-4 first:pt-0 last:pb-0">
                  <div className="flex items-start justify-between gap-3 flex-wrap">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant={entry.is_enabled ? 'success' : 'secondary'}>
                          {entry.is_enabled ? 'Enabled' : 'Disabled'}
                        </Badge>
                        <span className="font-semibold text-sm">KSh {entry.fee_amount} per fine payment</span>
                        {i === 0 && <Badge variant="info" className="text-xs">Current</Badge>}
                      </div>
                      {entry.change_reason && (
                        <p className="text-sm text-muted-foreground">"{entry.change_reason}"</p>
                      )}
                      <p className="text-xs text-muted-foreground">
                        Changed by {entry.changed_by}
                        {entry.previous_amount !== undefined && ` · Previous: KSh ${entry.previous_amount}`}
                      </p>
                    </div>
                    <span className="text-xs text-muted-foreground shrink-0">
                      {formatDate(entry.created_at)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Confirm dialog */}
      <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-yellow-500" />
              Confirm Fee Configuration Change
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2 text-sm">
            <div className="rounded-lg bg-muted/50 p-4 space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Fee Status</span>
                <span className="font-semibold">{isEnabled ? 'ENABLED' : 'DISABLED'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Fee Amount</span>
                <span className="font-semibold">KSh {feeAmount}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Effective From</span>
                <span>Immediately after save</span>
              </div>
            </div>
            <div className="rounded-lg border border-yellow-200 bg-yellow-50 dark:bg-yellow-950/20 p-3">
              <p className="text-yellow-800 dark:text-yellow-300 font-medium text-xs">
                This change will apply to all fine payments initiated AFTER you save.
                Existing completed payments will NOT be changed.
                This action will be recorded in the audit log.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirmOpen(false)}>Cancel</Button>
            <Button onClick={confirmSave} loading={saving}>Confirm & Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
