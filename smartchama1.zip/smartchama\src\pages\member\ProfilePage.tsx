import React, { useState } from 'react'
import { Save, Camera } from 'lucide-react'
import { PageHeader } from '@/components/shared/PageHeader'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import { useAuth } from '@/context/AuthContext'
import { getInitials, getCreditScoreColor, getCreditScoreLabel } from '@/lib/utils'
import { Progress } from '@/components/ui/progress'
import { toast } from 'sonner'

export function ProfilePage() {
  const { profile } = useAuth()
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({
    full_name: profile?.full_name || '',
    phone: profile?.phone || '',
    national_id: profile?.national_id || '',
    date_of_birth: profile?.date_of_birth || '',
    address: profile?.address || '',
    next_of_kin_name: profile?.next_of_kin_name || '',
    next_of_kin_phone: profile?.next_of_kin_phone || '',
  })

  const creditScore = profile?.credit_score ?? 500

  const handleSave = async () => {
    setSaving(true)
    await new Promise(r => setTimeout(r, 1200))
    setSaving(false)
    toast.success('Profile updated successfully')
  }

  return (
    <div className="space-y-6 max-w-2xl">
      <PageHeader title="My Profile" description="Manage your personal information" />

      {/* Avatar */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center gap-6">
            <div className="relative">
              <Avatar className="h-20 w-20">
                <AvatarImage src={profile?.avatar_url} />
                <AvatarFallback className="text-xl font-bold">
                  {getInitials(profile?.full_name || 'U')}
                </AvatarFallback>
              </Avatar>
              <button className="absolute bottom-0 right-0 h-7 w-7 rounded-full bg-primary flex items-center justify-center text-white hover:bg-primary/90 transition-colors">
                <Camera className="h-3.5 w-3.5" />
              </button>
            </div>
            <div>
              <p className="font-semibold text-lg">{profile?.full_name}</p>
              <p className="text-sm text-muted-foreground">{profile?.email}</p>
              <div className="flex items-center gap-2 mt-2">
                <span className={`text-sm font-medium ${getCreditScoreColor(creditScore)}`}>
                  Credit Score: {creditScore} ({getCreditScoreLabel(creditScore)})
                </span>
              </div>
              <Progress value={((creditScore - 300) / 600) * 100} className="h-1.5 w-40 mt-1" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Personal info */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Personal Information</CardTitle>
          <CardDescription>Update your contact details</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              { id: 'full_name', label: 'Full Name', type: 'text', placeholder: 'John Kamau' },
              { id: 'phone', label: 'Phone Number', type: 'tel', placeholder: '0712 345 678' },
              { id: 'national_id', label: 'National ID', type: 'text', placeholder: '12345678' },
              { id: 'date_of_birth', label: 'Date of Birth', type: 'date', placeholder: '' },
            ].map(field => (
              <div key={field.id} className="space-y-2">
                <Label htmlFor={field.id}>{field.label}</Label>
                <Input
                  id={field.id}
                  type={field.type}
                  placeholder={field.placeholder}
                  value={form[field.id as keyof typeof form]}
                  onChange={e => setForm(f => ({ ...f, [field.id]: e.target.value }))}
                />
              </div>
            ))}
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="address">Address</Label>
              <Input
                id="address"
                placeholder="e.g. Nairobi, Kenya"
                value={form.address}
                onChange={e => setForm(f => ({ ...f, address: e.target.value }))}
              />
            </div>
          </div>

          <Separator />

          <p className="text-sm font-medium">Next of Kin</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="kin_name">Full Name</Label>
              <Input id="kin_name" placeholder="Jane Kamau" value={form.next_of_kin_name} onChange={e => setForm(f => ({ ...f, next_of_kin_name: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="kin_phone">Phone Number</Label>
              <Input id="kin_phone" type="tel" placeholder="0722 345 678" value={form.next_of_kin_phone} onChange={e => setForm(f => ({ ...f, next_of_kin_phone: e.target.value }))} />
            </div>
          </div>

          <Button onClick={handleSave} loading={saving}>
            <Save className="h-4 w-4" /> Save Changes
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
