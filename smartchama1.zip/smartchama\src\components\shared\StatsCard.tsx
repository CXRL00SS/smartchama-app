import React from 'react'
import { motion } from 'framer-motion'
import { TrendingUp, TrendingDown, Minus } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { cn } from '@/lib/utils'

interface StatsCardProps {
  title: string
  value: string | number
  description?: string
  icon: React.ElementType
  trend?: number // percentage change
  trendLabel?: string
  variant?: 'default' | 'primary' | 'success' | 'warning' | 'danger' | 'gold'
  loading?: boolean
  className?: string
}

const variantStyles = {
  default: 'bg-card border-border',
  primary: 'bg-primary/5 border-primary/20',
  success: 'bg-emerald-50 border-emerald-200 dark:bg-emerald-950/20 dark:border-emerald-800/30',
  warning: 'bg-yellow-50 border-yellow-200 dark:bg-yellow-950/20 dark:border-yellow-800/30',
  danger: 'bg-red-50 border-red-200 dark:bg-red-950/20 dark:border-red-800/30',
  gold: 'bg-gold-50 border-gold-200 dark:bg-gold-950/20 dark:border-gold-800/30',
}

const iconVariantStyles = {
  default: 'bg-muted text-muted-foreground',
  primary: 'bg-primary/10 text-primary',
  success: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400',
  warning: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400',
  danger: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',
  gold: 'bg-gold-100 text-gold-700 dark:bg-gold-900/30 dark:text-gold-400',
}

export function StatsCard({
  title,
  value,
  description,
  icon: Icon,
  trend,
  trendLabel,
  variant = 'default',
  loading = false,
  className,
}: StatsCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className={cn('overflow-hidden', variantStyles[variant], className)}>
        <CardContent className="p-5">
          {loading ? (
            <div className="animate-pulse space-y-3">
              <div className="h-4 bg-muted rounded w-2/3" />
              <div className="h-8 bg-muted rounded w-1/2" />
              <div className="h-3 bg-muted rounded w-full" />
            </div>
          ) : (
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-muted-foreground truncate">{title}</p>
                <p className="mt-1 text-2xl font-bold text-foreground truncate">{value}</p>
                <div className="mt-2 flex items-center gap-2">
                  {trend !== undefined && (
                    <span
                      className={cn(
                        'flex items-center gap-0.5 text-xs font-medium',
                        trend > 0 ? 'text-emerald-600' : trend < 0 ? 'text-red-500' : 'text-muted-foreground'
                      )}
                    >
                      {trend > 0 ? (
                        <TrendingUp className="h-3 w-3" />
                      ) : trend < 0 ? (
                        <TrendingDown className="h-3 w-3" />
                      ) : (
                        <Minus className="h-3 w-3" />
                      )}
                      {Math.abs(trend)}%
                    </span>
                  )}
                  {description && (
                    <p className="text-xs text-muted-foreground truncate">{description}</p>
                  )}
                  {trendLabel && !description && (
                    <p className="text-xs text-muted-foreground">{trendLabel}</p>
                  )}
                </div>
              </div>
              <div className={cn('p-3 rounded-xl shrink-0', iconVariantStyles[variant])}>
                <Icon className="h-5 w-5" />
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  )
}
