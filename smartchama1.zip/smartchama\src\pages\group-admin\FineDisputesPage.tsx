/**
 * Group Admin — Fine Disputes Page
 * Review, uphold or cancel disputed fines.
 */

import React, { useState } from 'react'
import { MessageSquare, CheckCircle, XCircle, Clock } from 'lucide-react'
import { PageHeader } from '@/components/shared/PageHeader'
import { StatsCard } from '@/components/shared/StatsCard'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog'
import { formatDate, getInitials } from '@/lib/utils'
import { resolveDispute } from '@/services/firestore'
import { useAuth } from '@/context/AuthContext'
import type { FineDispute } from '@/types'
import { toast } from 'sonner'

const mockDisputes: (FineDispute & { member_name: string; fine_amount: number; fine_reason: string })[] = [
  {
    id: 'd1', fine_id: 'f4', group_id: 'g1', member_id: 'm1',
    reason: 'I was at the meeting but arrived just as the meeting started. My check-in was not recorded.',
    status: 'open',
    created_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    member_name: 'Alice Wanjiku',
    fine_amount: 300,
    fine_reason: 'Missed April monthly meeting',
  },
  {
    id: 'd2', fine_id: 'f5', group_id: 'g1', member_id: 'm3',
    reason: 'I submitted an apology message on the group WhatsApp before the meeting.',
    status: 'under_review',
    created_at: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    member_name: 'Carol Achieng',
    fine_amount: 300,
    fine_reason: 'Missed May monthly meeting',
  },
  {
    id: 'd3', fine_id: 'f6', group_id: 'g1', member_id: 'm2',
    reason: 'The fine amount does not match the agreed constitution rules.',
    status: 'resolved_upheld',
    reviewed_by: 'Jane Mwangi',
    reviewed_at: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    resolution_notes: 'Constitution confirmed — fine amount KSh 300 is correct for absence without notice.',
    created_at: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    member_name: 'Bob Kipchoge',
    fine_amount: 300,
    fine_reason: 'Missed March meeting',
  },
]

const statusConfig: Record<string, { label: string; variant: 'warning' | 'info' | 'success' | 'secondary' | 'destructive' }> = {
  open: { label: 'Open', variant: 'destructive' },
  under_review: { label: 'Under Review', variant: 'warning' },
  resolved_cancelled: { label: 'Resolved — Fine Cancelled', variant: 'success' },
  resolved_upheld: { label: 'Resolved — Fine Upheld', variant: 'secondary' },
}

export function FineDisputesPage() {
  const { user, profile } = useAuth()
  const [disputes, setDisputes] = useState(mockDisputes)
  const [resolveOpen, setResolveOpen] = useState(false)
  const [selected, setSelected] = useState<typeof mockDisputes[0] | null>(null)
  const [resolution, setResolution] = useState<'resolved_cancelled' | 'resolved_upheld'>('resolved_upheld')
  const [notes, setNotes] = useState('')
  const [loading, setLoading] = useState(false)

  const openCount = disputes.filter(d => d.status === 'open').length
  const underReviewCount = disputes.filter(d => d.status === 'under_review').length
  const resolvedCount = disputes.filter(d => d.status.startsWith('resolved')).length

  const openResolve = (dispute: typeof mockDisputes[0]) => {
    setSelected(dispute)
    setResolution('resolved_upheld')
    setNotes('')
    setResolveOpen(true)
  }

  const handleResolve = async () => {
    if (!notes.trim()) { toast.error('Resolution notes are required'); return }
    if (!selected || !user) return

    setLoading(true)
    try {
      await resolveDispute(
        selected.id,
        selected.fine_id,
        resolution,
        user.uid,
        notes
      )
      setDisputes(prev => prev.map(d =>
        d.id === selected.id ? {
          ...d,
          status: resolution,
          reviewed_by: profile?.full_name ?? user.uid,
          reviewed_at: new Date().toISOString(),
          resolution_notes: notes,
        } : d
      ))
      setResolveOpen(false)
      toast.success(
        resolution === 'resolved_cancelled' ? 'Fine cancelled — member notified' : 'Dispute resolved — fine upheld',
        { description: notes }
      )
    } catch {
      toast.error('Failed to resolve dispute. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Fine Disputes"
        description="Review and resolve member fine disputes"
      />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatsCard title="Open Disputes" value={openCount} icon={MessageSquare} variant="danger" />
        <StatsCard title="Under Review" value={underReviewCount} icon={Clock} variant="warning" />
        <StatsCard title="Resolved" value={resolvedCount} icon={CheckCircle} variant="success" />
      </div>

      <div className="space-y-4">
        {disputes.map(dispute => {
          const config = statusConfig[dispute.status]
          const isOpen = ['open', 'under_review'].includes(dispute.status)

          return (
            <Card key={dispute.id} className={isOpen ? 'border-orange-200 dark:border-orange-800' : ''}>
              <CardContent className="p-4">
                <div className="flex flex-col sm:flex-row sm:items-start gap-4">
                  <Avatar className="h-10 w-10 shrink-0">
                    <AvatarFallback>{getInitials(dispute.member_name)}</AvatarFallback>
                  </Avatar>

                  <div className="flex-1 min-w-0 space-y-2">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div>
                        <p className="font-semibold text-sm">{dispute.member_name}</p>
                        <p className="text-xs text-muted-foreground">
                          Fine: <strong>KSh {dispute.fine_amount}</strong> — {dispute.fine_reason}
                        </p>
                      </div>
                      <Badge variant={config.variant}>{config.label}</Badge>
                    </div>

                    <div className="bg-muted/40 rounded-lg p-3">
                      <p className="text-xs font-semibold text-muted-foreground mb-1">MEMBER'S REASON</p>
                      <p className="text-sm">{dispute.reason}</p>
                    </div>

                    {dispute.resolution_notes && (
                      <div className="bg-emerald-50 dark:bg-emerald-950/20 rounded-lg p-3">
                        <p className="text-xs font-semibold text-muted-foreground mb-1">RESOLUTION</p>
                        <p className="text-sm">{dispute.resolution_notes}</p>
                        {dispute.reviewed_by && (
                          <p className="text-xs text-muted-foreground mt-1">
                            By {dispute.reviewed_by} · {dispute.reviewed_at ? formatDate(dispute.reviewed_at) : ''}
                          </p>
                        )}
                      </div>
                    )}

                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <p className="text-xs text-muted-foreground">
                        Raised {formatDate(dispute.created_at)}
                      </p>
                      {isOpen && (
                        <Button size="sm" onClick={() => openResolve(dispute)}>
                          Review & Resolve
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Resolve Dialog */}
      <Dialog open={resolveOpen} onOpenChange={setResolveOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Resolve Dispute</DialogTitle>
            <DialogDescription>
              Your decision will be recorded permanently and the member will be notified.
            </DialogDescription>
          </DialogHeader>
          {selected && (
            <div className="space-y-4 py-2">
              <div className="rounded-lg bg-muted/50 p-3 text-sm space-y-1">
                <div className="flex justify-between"><span className="text-muted-foreground">Member</span><span>{selected.member_name}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Fine Amount</span><span className="font-bold">KSh {selected.fine_amount}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Member's Reason</span><span className="text-right max-w-48">{selected.reason}</span></div>
              </div>

              <div className="space-y-2">
                <Label>Your Decision</Label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setResolution('resolved_upheld')}
                    className={`flex flex-col items-center p-3 rounded-xl border-2 transition-all text-sm ${
                      resolution === 'resolved_upheld'
                        ? 'border-primary bg-primary/10 text-primary'
                        : 'border-border hover:border-primary/50'
                    }`}
                  >
                    <CheckCircle className="h-6 w-6 mb-1" />
                    <span className="font-medium">Uphold Fine</span>
                    <span className="text-xs text-muted-foreground">Fine stands, member must pay</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setResolution('resolved_cancelled')}
                    className={`flex flex-col items-center p-3 rounded-xl border-2 transition-all text-sm ${
                      resolution === 'resolved_cancelled'
                        ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-700'
                        : 'border-border hover:border-emerald-400'
                    }`}
                  >
                    <XCircle className="h-6 w-6 mb-1" />
                    <span className="font-medium">Cancel Fine</span>
                    <span className="text-xs text-muted-foreground">Fine removed, not payable</span>
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Resolution Notes <span className="text-destructive">*</span></Label>
                <textarea
                  className="w-full min-h-20 rounded-md border border-input bg-background px-3 py-2 text-sm resize-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  placeholder="Explain your decision — e.g. Member's attendance confirmed via sign-in sheet..."
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setResolveOpen(false)}>Cancel</Button>
            <Button onClick={handleResolve} loading={loading}>
              {resolution === 'resolved_cancelled' ? 'Cancel the Fine' : 'Uphold the Fine'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
