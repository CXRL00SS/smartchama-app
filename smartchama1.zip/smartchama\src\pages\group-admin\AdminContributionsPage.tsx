import React, { useState } from 'react'
import { Plus, Download, CheckCircle, XCircle, Clock, AlertTriangle } from 'lucide-react'
import { PageHeader } from '@/components/shared/PageHeader'
import { DataTable, Column } from '@/components/shared/DataTable'
import { StatsCard } from '@/components/shared/StatsCard'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { formatCurrency, formatDate, getInitials } from '@/lib/utils'
import { toast } from 'sonner'
import { Wallet } from 'lucide-react'

const contributions = [
  { id: 'c1', member: 'Alice Wanjiku', member_id: 'm1', amount: 5000, due_date: '2026-07-31', paid_date: '2026-07-30', status: 'paid', method: 'mpesa', ref: 'QJH7X3' },
  { id: 'c2', member: 'Bob Kipchoge', member_id: 'm2', amount: 5000, due_date: '2026-07-31', paid_date: '2026-08-02', status: 'late', method: 'mpesa', ref: 'PLK2M9' },
  { id: 'c3', member: 'Carol Achieng', member_id: 'm3', amount: 5000, due_date: '2026-07-31', status: 'pending', method: null, ref: null },
  { id: 'c4', member: 'David Mwenda', member_id: 'm4', amount: 5000, due_date: '2026-07-31', paid_date: '2026-07-28', status: 'paid', method: 'mpesa', ref: 'NMP4K1' },
  { id: 'c5', member: 'Eva Njoki', member_id: 'm5', amount: 5000, due_date: '2026-07-31', status: 'pending', method: null, ref: null },
]

const statusColors: Record<string, string> = {
  paid: 'success', late: 'destructive', pending: 'warning', waived: 'info',
}

export function AdminContributionsPage() {
  const paid = contributions.filter(c => c.status === 'paid').length
  const pending = contributions.filter(c => c.status === 'pending').length
  const late = contributions.filter(c => c.status === 'late').length
  const totalCollected = contributions.filter(c => ['paid', 'late'].includes(c.status)).reduce((s, c) => s + c.amount, 0)

  const columns: Column<typeof contributions[0]>[] = [
    {
      key: 'member',
      header: 'Member',
      render: (v) => (
        <div className="flex items-center gap-2">
          <Avatar className="h-7 w-7"><AvatarFallback className="text-xs">{getInitials(v as string)}</AvatarFallback></Avatar>
          <span className="text-sm font-medium">{v as string}</span>
        </div>
      ),
    },
    { key: 'amount', header: 'Amount', render: (v) => formatCurrency(v as number) },
    { key: 'due_date', header: 'Due Date', render: (v) => formatDate(v as string) },
    { key: 'paid_date', header: 'Paid Date', render: (v) => v ? formatDate(v as string) : '—' },
    {
      key: 'status',
      header: 'Status',
      render: (v) => <Badge variant={statusColors[v as string] as 'success'} className="capitalize">{v as string}</Badge>,
    },
    { key: 'method', header: 'Method', render: (v) => v ? <span className="capitalize">{String(v)}</span> : '—' },
    { key: 'ref', header: 'Reference', render: (v) => v ? <code className="text-xs bg-muted px-1.5 py-0.5 rounded">{String(v)}</code> : '—' },
    {
      key: 'id',
      header: 'Actions',
      render: (_, row) => (
        <div className="flex gap-1">
          {row.status === 'pending' && (
            <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => toast.success(`Reminder sent to ${row.member}`)}>
              Remind
            </Button>
          )}
          <Button variant="ghost" size="icon" className="h-7 w-7">
            <Download className="h-3.5 w-3.5" />
          </Button>
        </div>
      ),
    },
  ]

  return (
    <div className="space-y-6">
      <PageHeader
        title="Contributions"
        description="Manage and track all member contributions"
        actions={
          <Button onClick={() => toast.info('Export feature coming soon')}>
            <Download className="h-4 w-4" /> Export Report
          </Button>
        }
      />

      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <StatsCard title="Total Collected" value={formatCurrency(totalCollected)} icon={Wallet} variant="success" />
        <StatsCard title="Paid" value={paid} icon={CheckCircle} variant="success" />
        <StatsCard title="Pending" value={pending} icon={Clock} variant="warning" />
        <StatsCard title="Late" value={late} icon={AlertTriangle} variant="danger" />
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">July 2026 Contributions</CardTitle></CardHeader>
        <CardContent>
          <Tabs defaultValue="all">
            <TabsList className="mb-4">
              <TabsTrigger value="all">All ({contributions.length})</TabsTrigger>
              <TabsTrigger value="paid">Paid ({paid})</TabsTrigger>
              <TabsTrigger value="pending">Pending ({pending})</TabsTrigger>
              <TabsTrigger value="late">Late ({late})</TabsTrigger>
            </TabsList>
            {['all', 'paid', 'pending', 'late'].map(tab => (
              <TabsContent key={tab} value={tab}>
                <DataTable
                  data={(tab === 'all' ? contributions : contributions.filter(c => c.status === tab)) as unknown as Record<string, unknown>[]}
                  columns={columns as unknown as Column<Record<string, unknown>>[]}
                  searchable={false}
                />
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
