// ─── Core Domain Types ─────────────────────────────────────────────────────

export type UserRole =
  | 'super_admin'
  | 'group_admin'
  | 'chairperson'
  | 'treasurer'
  | 'secretary'
  | 'loan_committee'
  | 'member'

export type GroupStatus = 'active' | 'suspended' | 'pending' | 'inactive'
export type LoanStatus = 'pending' | 'approved' | 'rejected' | 'disbursed' | 'repaid' | 'defaulted'
export type ContributionStatus = 'pending' | 'paid' | 'late' | 'waived'
export type PaymentMethod = 'mpesa' | 'bank' | 'cash' | 'wallet'
export type MeetingStatus = 'scheduled' | 'ongoing' | 'completed' | 'cancelled'
export type NotificationChannel = 'email' | 'sms' | 'push' | 'in_app'
export type ContributionFrequency = 'daily' | 'weekly' | 'monthly' | 'custom'

// ─── User & Profile ─────────────────────────────────────────────────────────

export interface User {
  id: string
  email: string
  phone?: string
  full_name: string
  avatar_url?: string
  role: UserRole
  is_verified: boolean
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface Profile extends User {
  national_id?: string
  date_of_birth?: string
  address?: string
  next_of_kin_name?: string
  next_of_kin_phone?: string
  credit_score: number
  wallet_balance: number
}

// ─── Chama Group ─────────────────────────────────────────────────────────────

export interface ChamaGroup {
  id: string
  name: string
  description?: string
  registration_number?: string
  status: GroupStatus
  logo_url?: string
  created_by: string
  subscription_plan: 'free' | 'basic' | 'premium' | 'enterprise'
  subscription_expires_at?: string
  total_members: number
  total_savings: number
  created_at: string
  updated_at: string
}

export interface GroupSettings {
  id: string
  group_id: string
  contribution_frequency: ContributionFrequency
  contribution_amount: number
  contribution_day?: number // day of week/month
  custom_contribution_dates?: string[]
  late_penalty_type: 'fixed' | 'percentage'
  late_penalty_value: number
  late_penalty_grace_days: number
  loan_interest_rate: number
  loan_interest_type: 'flat' | 'reducing'
  max_loan_multiplier: number // e.g. 3x contributions
  loan_repayment_months: number
  min_guarantors: number
  max_guarantors: number
  meeting_frequency: 'weekly' | 'biweekly' | 'monthly'
  meeting_day?: number
  meeting_time?: string
  meeting_venue?: string
  currency: string
  timezone: string
}

// ─── Member ──────────────────────────────────────────────────────────────────

export interface GroupMember {
  id: string
  group_id: string
  user_id: string
  role: UserRole
  member_number: string
  joined_at: string
  is_active: boolean
  total_contributions: number
  total_loans: number
  outstanding_loan: number
  total_fines: number
  credit_score: number
  user?: Profile
}

// ─── Contributions ───────────────────────────────────────────────────────────

export interface Contribution {
  id: string
  group_id: string
  member_id: string
  amount: number
  due_date: string
  paid_date?: string
  status: ContributionStatus
  payment_method?: PaymentMethod
  transaction_ref?: string
  late_penalty?: number
  receipt_url?: string
  notes?: string
  created_at: string
  member?: GroupMember
}

export interface ContributionSchedule {
  id: string
  group_id: string
  period_label: string
  due_date: string
  amount: number
  total_expected: number
  total_collected: number
  members_paid: number
  members_pending: number
  created_at: string
}

// ─── Loans ───────────────────────────────────────────────────────────────────

export interface Loan {
  id: string
  group_id: string
  member_id: string
  amount: number
  interest_rate: number
  interest_type: 'flat' | 'reducing'
  total_interest: number
  total_payable: number
  monthly_installment: number
  repayment_months: number
  status: LoanStatus
  purpose: string
  applied_at: string
  approved_at?: string
  approved_by?: string
  disbursed_at?: string
  due_date?: string
  amount_paid: number
  balance: number
  notes?: string
  member?: GroupMember
  guarantors?: LoanGuarantor[]
  repayments?: LoanRepayment[]
}

export interface LoanGuarantor {
  id: string
  loan_id: string
  guarantor_member_id: string
  amount_guaranteed: number
  status: 'pending' | 'approved' | 'rejected'
  responded_at?: string
  notes?: string
  guarantor?: GroupMember
}

export interface LoanRepayment {
  id: string
  loan_id: string
  member_id: string
  amount: number
  principal_portion: number
  interest_portion: number
  payment_date: string
  payment_method: PaymentMethod
  transaction_ref?: string
  balance_after: number
  receipt_url?: string
}

// ─── Fines ───────────────────────────────────────────────────────────────────

export type FineType = 'late_contribution' | 'missed_meeting' | 'late_loan_payment' | 'lateness' | 'absence' | 'custom'
export type FineStatus = 'draft' | 'pending_approval' | 'approved' | 'pending' | 'paid' | 'waived' | 'cancelled' | 'disputed'

export interface Fine {
  id: string
  group_id: string
  member_id: string
  meeting_id?: string          // linked meeting if attendance fine
  type: FineType
  amount: number               // gross fine amount
  reason: string
  reference_id?: string        // contribution_id or meeting_id
  status: FineStatus
  issued_at: string
  approved_at?: string
  approved_by?: string
  due_date?: string
  paid_at?: string
  payment_method?: PaymentMethod
  transaction_ref?: string
  payment_id?: string          // linked Payment document id
  platform_fee?: number        // KSh 5 platform fee (set after payment confirmed)
  platform_fee_collected?: boolean
  dispute_id?: string
  created_by: string           // who issued this fine
  notes?: string
  member?: GroupMember
}

export interface FineRule {
  id: string
  group_id: string
  type: FineType
  name: string
  amount: number
  currency: string
  grace_period_minutes?: number  // for lateness: minutes before fine kicks in
  is_active: boolean
  requires_approval: boolean
  created_by: string
  created_at: string
  updated_at: string
}

export interface FineDispute {
  id: string
  fine_id: string
  group_id: string
  member_id: string
  reason: string
  evidence_urls?: string[]
  status: 'open' | 'under_review' | 'resolved_cancelled' | 'resolved_upheld'
  reviewed_by?: string
  reviewed_at?: string
  resolution_notes?: string
  created_at: string
  updated_at: string
  member?: GroupMember
  fine?: Fine
}

// ─── Platform Fee & Revenue ────────────────────────────────────────────────

export interface PlatformFeeConfig {
  id: string
  fee_amount: number          // KSh 5
  fee_type: 'fixed'           // fixed per successful fine payment
  currency: string            // KES
  is_enabled: boolean         // disabled until live payment integration verified
  effective_from: string
  changed_by: string
  change_reason?: string
  previous_amount?: number
  created_at: string
}

export interface PlatformRevenueLedger {
  id: string
  fine_id: string
  payment_id: string
  provider_reference: string   // M-Pesa receipt number
  group_id: string
  member_id: string
  gross_fine_amount: number    // total member paid
  platform_fee_amount: number  // KSh 5
  provider_charge: number      // M-Pesa charge if known
  net_platform_revenue: number // platform_fee_amount - provider_charge
  chama_net_amount: number     // gross_fine_amount - platform_fee_amount
  currency: string
  status: 'collected' | 'refunded' | 'reversed'
  collected_at: string
  refund_id?: string
  idempotency_key: string      // prevent duplicate entries
  created_at: string
}

export interface Refund {
  id: string
  payment_id: string
  fine_id: string
  group_id: string
  member_id: string
  amount: number
  platform_fee_refunded: number
  reason: string
  status: 'pending' | 'completed' | 'failed'
  requested_by: string
  approved_by?: string
  provider_reference?: string
  created_at: string
  completed_at?: string
}

// ─── Meeting Attendance (extended) ────────────────────────────────────────

export interface MeetingAttendanceRecord {
  id: string
  meeting_id: string
  group_id: string
  member_id: string
  status: 'present' | 'absent' | 'excused' | 'late'
  checked_in_at?: string       // actual arrival time
  grace_period_end?: string    // scheduled_at + grace_period_minutes
  lateness_minutes?: number    // computed lateness
  fine_id?: string             // linked fine if issued
  fine_status?: FineStatus
  manually_corrected?: boolean // flagged if admin corrected the record
  corrected_by?: string
  correction_reason?: string
  created_at: string
  updated_at: string
  member?: GroupMember
}

// ─── Meetings ────────────────────────────────────────────────────────────────

export interface Meeting {
  id: string
  group_id: string
  title: string
  description?: string
  scheduled_at: string
  venue?: string
  meeting_link?: string
  status: MeetingStatus
  minutes?: string
  agenda?: string[]
  created_by: string
  created_at: string
  attendance?: MeetingAttendance[]
}

export interface MeetingAttendance {
  id: string
  meeting_id: string
  member_id: string
  status: 'present' | 'absent' | 'excused'
  checked_in_at?: string
  fine_issued: boolean
  member?: GroupMember
}

// ─── Payments ────────────────────────────────────────────────────────────────

export interface Payment {
  id: string
  group_id: string
  member_id: string
  amount: number
  currency: string
  payment_method: PaymentMethod
  reference_type: 'contribution' | 'loan_repayment' | 'fine' | 'registration'
  reference_id: string
  status: 'pending' | 'completed' | 'failed' | 'cancelled' | 'reversed'
  mpesa_checkout_request_id?: string
  mpesa_receipt_number?: string
  phone_number?: string
  platform_fee?: number           // KSh 5 applied on fine payments
  platform_fee_collected?: boolean
  idempotency_key?: string        // prevent duplicate processing
  created_at: string
  completed_at?: string
  member?: GroupMember
}

// ─── Announcements ────────────────────────────────────────────────────────────

export interface Announcement {
  id: string
  group_id: string
  title: string
  content: string
  is_pinned: boolean
  created_by: string
  created_at: string
  read_count: number
  author?: Profile
}

// ─── Documents ───────────────────────────────────────────────────────────────

export interface Document {
  id: string
  group_id: string
  name: string
  description?: string
  file_url: string
  file_size: number
  file_type: string
  category: 'constitution' | 'rules' | 'minutes' | 'financial' | 'policy' | 'other'
  uploaded_by: string
  created_at: string
  download_count: number
}

// ─── Notifications ────────────────────────────────────────────────────────────

export interface Notification {
  id: string
  user_id: string
  group_id?: string
  title: string
  message: string
  type: 'info' | 'success' | 'warning' | 'error'
  channel: NotificationChannel
  is_read: boolean
  action_url?: string
  created_at: string
}

// ─── Expenses & Income ───────────────────────────────────────────────────────

export interface Expense {
  id: string
  group_id: string
  description: string
  amount: number
  category: string
  date: string
  approved_by?: string
  receipt_url?: string
  created_by: string
  created_at: string
}

export interface Income {
  id: string
  group_id: string
  description: string
  amount: number
  source: string
  date: string
  created_by: string
  created_at: string
}

// ─── Audit Log ───────────────────────────────────────────────────────────────

export interface AuditLog {
  id: string
  user_id: string
  group_id?: string
  action: string
  resource_type: string
  resource_id?: string
  old_values?: Record<string, unknown>
  new_values?: Record<string, unknown>
  ip_address?: string
  user_agent?: string
  created_at: string
  user?: Profile
}

// ─── Analytics ───────────────────────────────────────────────────────────────

export interface GroupAnalytics {
  total_contributions: number
  total_loans_disbursed: number
  total_repayments: number
  total_fines_collected: number
  total_expenses: number
  net_savings: number
  active_loans: number
  defaulted_loans: number
  total_members: number
  active_members: number
  monthly_contribution_trend: MonthlyData[]
  loan_performance: LoanPerformanceData[]
  membership_growth: MonthlyData[]
}

export interface MonthlyData {
  month: string
  value: number
}

export interface LoanPerformanceData {
  month: string
  disbursed: number
  repaid: number
  defaulted: number
}

// ─── Subscription ────────────────────────────────────────────────────────────

export interface Subscription {
  id: string
  group_id: string
  plan: 'free' | 'basic' | 'premium' | 'enterprise'
  status: 'active' | 'expired' | 'cancelled'
  amount: number
  billing_cycle: 'monthly' | 'yearly'
  started_at: string
  expires_at: string
  features: string[]
}

// ─── Super Admin ─────────────────────────────────────────────────────────────

export interface PlatformStats {
  total_groups: number
  active_groups: number
  total_members: number
  total_savings: number
  total_loans_disbursed: number
  monthly_revenue: number
  total_revenue: number
  pending_tickets: number
}

// ─── API Response ─────────────────────────────────────────────────────────────

export interface ApiResponse<T> {
  data: T | null
  error: string | null
  loading: boolean
}

export interface PaginatedResponse<T> {
  data: T[]
  count: number
  page: number
  pageSize: number
  totalPages: number
}
