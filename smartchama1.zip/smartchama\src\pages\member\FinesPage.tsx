/**
 * Member — My Fines Page
 * View fines, pay via M-Pesa with full fee disclosure, and raise disputes.
 */

import React, { useState, useEffect } from 'react'
import { AlertTriangle, CreditCard, MessageSquare, Info, CheckCircle, Clock, XCircle } from 'lucide-react'
import { motion } from 'framer-motion'
import { PageHeader } from '@/components/shared/PageHeader'
import { StatsCard } from '@/components/shared/StatsCard'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { formatCurrency, formatDate } from '@/lib/utils'
import { getFinePaymentBreakdown, startFinePayment, type FinePaymentBreakdown } from '@/services/finePayment'
import { raiseDispute } from '@/services/firestore'
import { useAuth } from '@/context/AuthContext'
import type { Fine } from '@/types'
import { toast } from 'sonner'

const mockFines: Fine[] = [
  {
    id: 'f1', group_id: 'g1', member_id: 'm1',
    type: 'missed_meeting', amount: 300, reason: 'Missed July monthly meeting',
    status: 'approved', issued_at: '2026-07-20', due_date: '2026-08-10',
    created_by: 'admin1',
  },
  {
    id: 'f2', group_id: 'g1', member_id: 'm1',
    type: 'lateness', amount: 50, reason: 'Arrived 25 minutes late to June meeting',
    status: 'paid', issued_at: '2026-06-21', paid_at: '2026-06-25',
    payment_method: 'mpesa', transaction_ref: 'MPE002', platform_fee: 5, platform_fee_collected: true,
    created_by: 'admin1',
  },
  {
    id: 'f3', group_id: 'g1', member_id: 'm1',
    type: 'late_contribution', amount: 500, reason: 'Late May contribution (5 days)',
    status: 'paid', issued_at: '2026-05-08', paid_at: '2026-05-10',
    payment_method: 'mpesa', transaction_ref: 'MPE001', platform_fee: 5, platform_fee_collected: true,
    created_by: 'admin1',
  },
  {
    id: 'f4', group_id: 'g1', member_id: 'm1',
    type: 'missed_meeting', amount: 300, reason: 'Missed April meeting',
    status: 'disputed', issued_at: '2026-04-20', created_by: 'admin1',
    dispute_id: 'd1',
  },
]

const statusConfig: Record<string, { label: string; variant: 'success' | 'warning' | 'destructive' | 'info' | 'secondary'; icon: React.ReactNode }> = {
  paid: { label: 'Paid', variant: 'success', icon: <CheckCircle className="h-3.5 w-3.5" /> },
  approved: { label: 'Approved — Pay Now', variant: 'warning', icon: <AlertTriangle className="h-3.5 w-3.5" /> },
  pending: { label: 'Pending Review', variant: 'info', icon: <Clock className="h-3.5 w-3.5" /> },
  pending_approval: { label: 'Pending Approval', variant: 'info', icon: <Clock className="h-3.5 w-3.5" /> },
  disputed: { label: 'Disputed', variant: 'secondary', icon: <MessageSquare className="h-3.5 w-3.5" /> },
  waived: { label: 'Waived', variant: 'secondary', icon: <XCircle className="h-3.5 w-3.5" /> },
  cancelled: { label: 'Cancelled', variant: 'secondary', icon: <XCircle className="h-3.5 w-3.5" /> },
}

export function FinesPage() {
  const { user } = useAuth()
  const [payOpen, setPayOpen] = useState(false)
  const [disputeOpen, setDisputeOpen] = useState(false)
  const [selected, setSelected] = useState<Fine | null>(null)
  const [phone, setPhone] = useState('')
  const [disputeReason, setDisputeReason] = useState('')
  const [loading, setLoading] = useState(false)
  const [breakdown, setBreakdown] = useState<FinePaymentBreakdown | null>(null)

  const payableFines = mockFines.filter(f => ['approved', 'pending'].includes(f.status))
  const totalPending = payableFines.reduce((s, f) => s + f.amount, 0)
  const totalPaid = mockFines.filter(f => f.status === 'paid').reduce((s, f) => s + f.amount, 0)
  const totalPlatformFees = mockFines.filter(f => f.platform_fee_collected).reduce((s, f) => s + (f.platform_fee ?? 0), 0)

  const openPayDialog = async (fine: Fine) => {
    setSelected(fine)
    setBreakdown(null)
    setPayOpen(true)
    // Load fee breakdown
    try {
      const b = await getFinePaymentBreakdown(fine.amount)
      setBreakdown(b)
    } catch {
      setBreakdown({
        fine_amount: fine.amount,
        platform_fee: 0,
        total_member_pays: fine.amount,
        chama_receives: fine.amount,
        fee_enabled: false,
        fee_disclosure: 'No platform service fee currently applies.',
      })
    }
  }

  const openDisputeDialog = (fine: Fine) => {
    setSelected(fine)
    setDisputeReason('')
    setDisputeOpen(true)
  }

  const handlePay = async () => {
    if (!phone.trim()) { toast.error('Enter your M-Pesa phone number'); return }
    if (!selected || !user) return

    setLoading(true)
    try {
      const result = await startFinePayment(selected, phone, user.uid)
      if (!result.success) {
        toast.error('Payment failed', { description: result.error })
        return
      }
      setPayOpen(false)
      toast.success('M-Pesa prompt sent!', {
        description: `Check your phone (${phone}) to complete the KSh ${selected.amount} payment.`,
      })
    } catch {
      toast.error('Payment initiation failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const handleDispute = async () => {
    if (!disputeReason.trim()) { toast.error('Please provide a reason for your dispute'); return }
    if (!selected || !user) return

    setLoading(true)
    try {
      await raiseDispute({
        fine_id: selected.id,
        group_id: selected.group_id,
        member_id: selected.member_id,
        reason: disputeReason,
        status: 'open',
      })
      setDisputeOpen(false)
      toast.success('Dispute raised', {
        description: 'Your dispute has been submitted for review by the group admin.',
      })
    } catch {
      toast.error('Failed to raise dispute. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader title="My Fines" description="View, pay, and dispute your fines" />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatsCard title="Payable Fines" value={formatCurrency(totalPending)} icon={AlertTriangle} variant="danger" description={`${payableFines.length} fine(s) to pay`} />
        <StatsCard title="Total Paid" value={formatCurrency(totalPaid)} icon={CheckCircle} variant="success" />
        <StatsCard title="Platform Fees Paid" value={formatCurrency(totalPlatformFees)} icon={Info} variant="default" description="KSh 5 per payment" />
      </div>

      <Tabs defaultValue="pending">
        <TabsList>
          <TabsTrigger value="pending">Payable ({payableFines.length})</TabsTrigger>
          <TabsTrigger value="all">All Fines ({mockFines.length})</TabsTrigger>
        </TabsList>

        {['pending', 'all'].map(tab => {
          const fines = tab === 'pending' ? payableFines : mockFines
          return (
            <TabsContent key={tab} value={tab}>
              <div className="space-y-3">
                {fines.length === 0 && (
                  <Card>
                    <CardContent className="py-12 text-center">
                      <CheckCircle className="h-10 w-10 text-emerald-500 mx-auto mb-3" />
                      <p className="text-muted-foreground">No fines to show</p>
                    </CardContent>
                  </Card>
                )}
                {fines.map((fine, i) => {
                  const config = statusConfig[fine.status] ?? statusConfig.pending
                  return (
                    <motion.div
                      key={fine.id}
                      initial={{ opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.04 }}
                    >
                      <Card className={fine.status === 'approved' ? 'border-orange-300 dark:border-orange-800' : ''}>
                        <CardContent className="p-4">
                          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap mb-1">
                                <Badge variant={config.variant} className="flex items-center gap-1">
                                  {config.icon}{config.label}
                                </Badge>
                                <span className="text-xs text-muted-foreground capitalize">
                                  {fine.type.replace(/_/g, ' ')}
                                </span>
                              </div>
                              <p className="text-sm font-medium">{fine.reason}</p>
                              <div className="flex flex-wrap gap-3 mt-1 text-xs text-muted-foreground">
                                <span>Issued: {formatDate(fine.issued_at)}</span>
                                {fine.due_date && <span className="text-orange-500">Due: {formatDate(fine.due_date)}</span>}
                                {fine.paid_at && <span className="text-emerald-600">Paid: {formatDate(fine.paid_at)}</span>}
                                {fine.transaction_ref && (
                                  <code className="bg-muted px-1.5 py-0.5 rounded">{fine.transaction_ref}</code>
                                )}
                                {fine.platform_fee_collected && (
                                  <span className="text-muted-foreground">Platform fee: KSh {fine.platform_fee}</span>
                                )}
                              </div>
                            </div>

                            <div className="flex items-center gap-3 shrink-0">
                              <div className="text-right">
                                <p className="text-lg font-bold">KSh {fine.amount}</p>
                              </div>
                              <div className="flex flex-col gap-1.5">
                                {['approved', 'pending'].includes(fine.status) && (
                                  <Button size="sm" className="h-8 text-xs" onClick={() => openPayDialog(fine)}>
                                    <CreditCard className="h-3.5 w-3.5" /> Pay
                                  </Button>
                                )}
                                {['approved', 'pending', 'pending_approval'].includes(fine.status) && (
                                  <Button size="sm" variant="outline" className="h-8 text-xs" onClick={() => openDisputeDialog(fine)}>
                                    <MessageSquare className="h-3.5 w-3.5" /> Dispute
                                  </Button>
                                )}
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  )
                })}
              </div>
            </TabsContent>
          )
        })}
      </Tabs>

      {/* Payment Dialog */}
      <Dialog open={payOpen} onOpenChange={setPayOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Pay Fine via M-Pesa</DialogTitle>
            <DialogDescription>Full payment breakdown — no hidden fees</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            {/* Fine details */}
            <div className="rounded-lg bg-muted/50 p-4 space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Fine Type</span>
                <span className="capitalize">{selected?.type.replace(/_/g, ' ')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Reason</span>
                <span className="text-right max-w-48">{selected?.reason}</span>
              </div>
              {selected?.due_date && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Due Date</span>
                  <span>{formatDate(selected.due_date)}</span>
                </div>
              )}
            </div>

            {/* Fee breakdown */}
            {breakdown && (
              <div className="rounded-lg border border-border p-4 space-y-2 text-sm">
                <p className="font-semibold text-foreground mb-2">Payment Breakdown</p>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Fine Amount</span>
                  <span className="font-semibold">KSh {breakdown.fine_amount}</span>
                </div>
                {breakdown.fee_enabled && breakdown.platform_fee > 0 && (
                  <div className="flex justify-between text-orange-600">
                    <span className="flex items-center gap-1">
                      <Info className="h-3.5 w-3.5" />
                      SmartChama platform fee
                    </span>
                    <span>KSh {breakdown.platform_fee}</span>
                  </div>
                )}
                <Separator />
                <div className="flex justify-between font-bold text-base">
                  <span>You Pay</span>
                  <span>KSh {breakdown.total_member_pays}</span>
                </div>
                {breakdown.fee_enabled && (
                  <div className="flex justify-between text-muted-foreground text-xs">
                    <span>Chama receives</span>
                    <span>KSh {breakdown.chama_receives}</span>
                  </div>
                )}
                <p className="text-xs text-muted-foreground pt-1">{breakdown.fee_disclosure}</p>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="mpesa-phone">M-Pesa Phone Number</Label>
              <Input
                id="mpesa-phone"
                type="tel"
                placeholder="0712 345 678"
                value={phone}
                onChange={e => setPhone(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                You will receive a push notification to confirm. Do NOT close this page until you receive the prompt.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPayOpen(false)}>Cancel</Button>
            <Button
              onClick={handlePay}
              loading={loading}
              className="bg-[#00A550] hover:bg-[#008C44] text-white"
              disabled={!breakdown}
            >
              <CreditCard className="h-4 w-4" />
              Send M-Pesa Prompt — KSh {breakdown?.total_member_pays ?? selected?.amount ?? 0}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dispute Dialog */}
      <Dialog open={disputeOpen} onOpenChange={setDisputeOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Dispute This Fine</DialogTitle>
            <DialogDescription>
              Raise a dispute if you believe this fine was issued incorrectly.
              An admin will review your dispute and respond.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="rounded-lg bg-muted/50 p-3 text-sm space-y-1">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Fine</span>
                <span className="font-semibold">KSh {selected?.amount}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Reason</span>
                <span className="text-right max-w-48">{selected?.reason}</span>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="dispute-reason">
                Why are you disputing this fine? <span className="text-destructive">*</span>
              </Label>
              <textarea
                id="dispute-reason"
                className="w-full min-h-24 rounded-md border border-input bg-background px-3 py-2 text-sm resize-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                placeholder="e.g. I was present at the meeting but my arrival was not recorded correctly..."
                value={disputeReason}
                onChange={e => setDisputeReason(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                The admin team will review your dispute and may correct the attendance record if appropriate.
                Fines that are disputed are not due for payment until the dispute is resolved.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDisputeOpen(false)}>Cancel</Button>
            <Button onClick={handleDispute} loading={loading}>Submit Dispute</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
