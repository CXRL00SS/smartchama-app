import React from 'react'
import { motion } from 'framer-motion'
import { Building2, Users, Wallet, TrendingUp, CheckCircle, XCircle, Clock, HelpCircle } from 'lucide-react'
import { StatsCard } from '@/components/shared/StatsCard'
import { PageHeader } from '@/components/shared/PageHeader'
import { DataTable, Column } from '@/components/shared/DataTable'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { formatCurrency, formatDate, getInitials } from '@/lib/utils'
import { toast } from 'sonner'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, Legend
} from 'recharts'

const revenueData = [
  { month: 'Jan', subscriptions: 45000, transactions: 12000 },
  { month: 'Feb', subscriptions: 48000, transactions: 14000 },
  { month: 'Mar', subscriptions: 52000, transactions: 16000 },
  { month: 'Apr', subscriptions: 55000, transactions: 15000 },
  { month: 'May', subscriptions: 60000, transactions: 18000 },
  { month: 'Jun', subscriptions: 65000, transactions: 20000 },
  { month: 'Jul', subscriptions: 70000, transactions: 22000 },
]

const groupsData = [
  { id: 'g1', name: 'Pamoja Savings', location: 'Nairobi', members: 47, savings: 2450000, plan: 'premium', status: 'active', joined: '2024-01-15' },
  { id: 'g2', name: 'Amani Chama', location: 'Mombasa', members: 32, savings: 1800000, plan: 'basic', status: 'active', joined: '2024-03-10' },
  { id: 'g3', name: 'Faida Group', location: 'Kisumu', members: 25, savings: 980000, plan: 'free', status: 'pending', joined: '2026-07-01' },
  { id: 'g4', name: 'Nguvu Savings', location: 'Nakuru', members: 58, savings: 3200000, plan: 'enterprise', status: 'active', joined: '2023-06-20' },
  { id: 'g5', name: 'Matumaini Group', location: 'Eldoret', members: 18, savings: 450000, plan: 'basic', status: 'suspended', joined: '2025-02-14' },
]

const supportTickets = [
  { id: 't1', subject: 'M-Pesa payment not reflecting', group: 'Pamoja Savings', priority: 'high', status: 'open', created: '2026-08-03' },
  { id: 't2', subject: 'Member cannot login', group: 'Amani Chama', priority: 'medium', status: 'open', created: '2026-08-02' },
  { id: 't3', subject: 'Export report not working', group: 'Faida Group', priority: 'low', status: 'resolved', created: '2026-07-30' },
]

const planColors: Record<string, string> = { free: 'secondary', basic: 'info', premium: 'success', enterprise: 'gold' }
const statusColors: Record<string, string> = { active: 'success', pending: 'warning', suspended: 'destructive', inactive: 'secondary' }
const priorityColors: Record<string, string> = { high: 'destructive', medium: 'warning', low: 'secondary' }
const ticketStatusColors: Record<string, string> = { open: 'warning', in_progress: 'info', resolved: 'success', closed: 'secondary' }

export function SuperAdminDashboard() {
  const totalRevenue = revenueData.reduce((s, d) => s + d.subscriptions + d.transactions, 0)

  const groupColumns: Column<typeof groupsData[0]>[] = [
    {
      key: 'name',
      header: 'Group',
      render: (v) => (
        <div className="flex items-center gap-2">
          <div className="h-7 w-7 rounded-md bg-primary/10 flex items-center justify-center">
            <span className="text-xs font-bold text-primary">{String(v).slice(0, 2).toUpperCase()}</span>
          </div>
          <span className="font-medium text-sm">{v as string}</span>
        </div>
      ),
    },
    { key: 'location', header: 'Location' },
    { key: 'members', header: 'Members', render: (v) => <span className="font-semibold">{String(v)}</span> },
    { key: 'savings', header: 'Savings', render: (v) => formatCurrency(v as number) },
    { key: 'plan', header: 'Plan', render: (v) => <Badge variant={planColors[v as string] as 'success'} className="capitalize">{v as string}</Badge> },
    { key: 'status', header: 'Status', render: (v) => <Badge variant={statusColors[v as string] as 'success'} className="capitalize">{v as string}</Badge> },
    {
      key: 'id',
      header: 'Actions',
      render: (v, row) => (
        <div className="flex gap-1">
          {row.status !== 'active' ? (
            <Button size="sm" className="h-7 text-xs" onClick={() => toast.success(`${row.name} approved`)}>
              <CheckCircle className="h-3 w-3" /> Approve
            </Button>
          ) : (
            <Button size="sm" variant="destructive" className="h-7 text-xs" onClick={() => toast.warning(`${row.name} suspended`)}>
              <XCircle className="h-3 w-3" /> Suspend
            </Button>
          )}
        </div>
      ),
    },
  ]

  return (
    <div className="space-y-6">
      <PageHeader title="Platform Dashboard" description="Super Admin — Full Platform Overview" />

      {/* Platform stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { title: 'Total Groups', value: '142', icon: Building2, variant: 'primary' as const, trend: 8 },
          { title: 'Total Members', value: '4,287', icon: Users, variant: 'success' as const, trend: 12 },
          { title: 'Platform Savings', value: formatCurrency(285000000), icon: Wallet, variant: 'gold' as const, trend: 15 },
          { title: 'Monthly Revenue', value: formatCurrency(92000), icon: TrendingUp, variant: 'warning' as const, trend: 7 },
        ].map((s, i) => (
          <motion.div key={s.title} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}>
            <StatsCard {...s} />
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <StatsCard title="Active Groups" value="128" icon={CheckCircle} variant="success" />
        <StatsCard title="Pending Approval" value="7" icon={Clock} variant="warning" />
        <StatsCard title="Suspended" value="7" icon={XCircle} variant="danger" />
        <StatsCard title="Open Tickets" value="12" icon={HelpCircle} variant="default" />
      </div>

      {/* Revenue chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Revenue Trend</CardTitle>
            <CardDescription>Subscription + transaction fees (Total: {formatCurrency(totalRevenue)})</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={revenueData} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} tickFormatter={v => `${v / 1000}k`} />
                <Tooltip formatter={(v: number) => formatCurrency(v)} />
                <Legend />
                <Bar dataKey="subscriptions" name="Subscriptions" fill="#059669" radius={[4, 4, 0, 0]} />
                <Bar dataKey="transactions" name="Transaction Fees" fill="#f59e0b" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Ticket summary */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Support Tickets</CardTitle>
            <CardDescription>Open issues requiring attention</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {supportTickets.map(t => (
                <div key={t.id} className="p-3 rounded-lg bg-muted/40 space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-medium truncate">{t.subject}</p>
                    <Badge variant={ticketStatusColors[t.status] as 'success'} className="text-xs shrink-0">{t.status}</Badge>
                  </div>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>{t.group}</span>
                    <Badge variant={priorityColors[t.priority] as 'destructive'} className="text-xs">{t.priority}</Badge>
                  </div>
                </div>
              ))}
              <Button variant="outline" size="sm" className="w-full">View All Tickets</Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Groups table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">All Registered Groups</CardTitle>
          <CardDescription>Platform-wide group management</CardDescription>
        </CardHeader>
        <CardContent>
          <DataTable
            data={groupsData as unknown as Record<string, unknown>[]}
            columns={groupColumns as unknown as Column<Record<string, unknown>>[]}
            searchKeys={['name', 'location'] as unknown as (keyof Record<string, unknown>)[]}
            searchPlaceholder="Search groups..."
          />
        </CardContent>
      </Card>
    </div>
  )
}
