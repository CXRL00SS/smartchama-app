import React, { useState } from 'react'
import { CheckCircle, XCircle, Eye, Landmark } from 'lucide-react'
import { PageHeader } from '@/components/shared/PageHeader'
import { DataTable, Column } from '@/components/shared/DataTable'
import { StatsCard } from '@/components/shared/StatsCard'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { formatCurrency, formatDate, getInitials } from '@/lib/utils'
import { toast } from 'sonner'
import { TrendingUp, AlertTriangle } from 'lucide-react'

const loans = [
  { id: 'l1', member: 'Alice Wanjiku', member_id: 'm1', amount: 75000, purpose: 'Business capital', status: 'pending', applied_at: '2026-07-30', monthly_installment: 7000, balance: 75000 },
  { id: 'l2', member: 'Bob Kipchoge', member_id: 'm2', amount: 50000, purpose: 'Education', status: 'pending', applied_at: '2026-07-28', monthly_installment: 4700, balance: 50000 },
  { id: 'l3', member: 'Carol Achieng', member_id: 'm3', amount: 100000, purpose: 'Land purchase', status: 'disbursed', applied_at: '2026-06-01', monthly_installment: 9500, balance: 72000, disbursed_at: '2026-06-05' },
  { id: 'l4', member: 'David Mwenda', member_id: 'm4', amount: 30000, purpose: 'Medical', status: 'repaid', applied_at: '2025-01-10', monthly_installment: 2800, balance: 0 },
  { id: 'l5', member: 'Eva Njoki', member_id: 'm5', amount: 45000, purpose: 'Business', status: 'defaulted', applied_at: '2025-06-01', monthly_installment: 4200, balance: 22000 },
]

const statusColors: Record<string, string> = {
  pending: 'warning',
  approved: 'info',
  rejected: 'destructive',
  disbursed: 'success',
  repaid: 'secondary',
  defaulted: 'destructive',
}

export function AdminLoansPage() {
  const [selected, setSelected] = useState<typeof loans[0] | null>(null)
  const [viewOpen, setViewOpen] = useState(false)
  const [actionLoading, setActionLoading] = useState<string | null>(null)

  const pending = loans.filter(l => l.status === 'pending')
  const active = loans.filter(l => l.status === 'disbursed')
  const totalDisbursed = loans.filter(l => ['disbursed', 'repaid'].includes(l.status)).reduce((s, l) => s + l.amount, 0)
  const totalBalance = loans.filter(l => l.status === 'disbursed').reduce((s, l) => s + l.balance, 0)

  const handleAction = async (id: string, action: 'approve' | 'reject') => {
    setActionLoading(id + action)
    await new Promise(r => setTimeout(r, 1200))
    setActionLoading(null)
    toast.success(`Loan ${action === 'approve' ? 'approved' : 'rejected'}`)
  }

  const columns: Column<typeof loans[0]>[] = [
    {
      key: 'member',
      header: 'Member',
      render: (v) => (
        <div className="flex items-center gap-2">
          <Avatar className="h-7 w-7"><AvatarFallback className="text-xs">{getInitials(v as string)}</AvatarFallback></Avatar>
          <span className="text-sm font-medium">{v as string}</span>
        </div>
      ),
    },
    { key: 'amount', header: 'Amount', render: (v) => formatCurrency(v as number) },
    { key: 'purpose', header: 'Purpose' },
    { key: 'monthly_installment', header: 'Monthly', render: (v) => formatCurrency(v as number) },
    { key: 'balance', header: 'Balance', render: (v) => <span className={v === 0 ? 'text-muted-foreground' : 'text-orange-500 font-semibold'}>{formatCurrency(v as number)}</span> },
    { key: 'applied_at', header: 'Applied', render: (v) => formatDate(v as string) },
    {
      key: 'status',
      header: 'Status',
      render: (v) => <Badge variant={statusColors[v as string] as 'success'} className="capitalize">{String(v)}</Badge>,
    },
    {
      key: 'id',
      header: 'Actions',
      render: (v, row) => (
        <div className="flex gap-1">
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { setSelected(row as typeof loans[0]); setViewOpen(true) }}>
            <Eye className="h-3.5 w-3.5" />
          </Button>
          {row.status === 'pending' && (
            <>
              <Button size="icon" className="h-7 w-7 bg-emerald-600 hover:bg-emerald-700" loading={actionLoading === v + 'approve'} onClick={() => handleAction(v as string, 'approve')}>
                <CheckCircle className="h-3.5 w-3.5" />
              </Button>
              <Button variant="destructive" size="icon" className="h-7 w-7" loading={actionLoading === v + 'reject'} onClick={() => handleAction(v as string, 'reject')}>
                <XCircle className="h-3.5 w-3.5" />
              </Button>
            </>
          )}
        </div>
      ),
    },
  ]

  return (
    <div className="space-y-6">
      <PageHeader title="Loan Management" description="Review and manage all loan applications" />

      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <StatsCard title="Pending Approvals" value={pending.length} icon={AlertTriangle} variant="warning" />
        <StatsCard title="Active Loans" value={active.length} icon={Landmark} variant="primary" />
        <StatsCard title="Total Disbursed" value={formatCurrency(totalDisbursed)} icon={TrendingUp} variant="success" />
        <StatsCard title="Outstanding Balance" value={formatCurrency(totalBalance)} icon={Landmark} variant="danger" />
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">All Loan Applications</CardTitle></CardHeader>
        <CardContent>
          <Tabs defaultValue="all">
            <TabsList className="mb-4">
              <TabsTrigger value="all">All ({loans.length})</TabsTrigger>
              <TabsTrigger value="pending">Pending ({pending.length})</TabsTrigger>
              <TabsTrigger value="active">Active ({active.length})</TabsTrigger>
            </TabsList>
            <TabsContent value="all">
              <DataTable data={loans as unknown as Record<string, unknown>[]} columns={columns as unknown as Column<Record<string, unknown>>[]} searchable={false} />
            </TabsContent>
            <TabsContent value="pending">
              <DataTable data={pending as unknown as Record<string, unknown>[]} columns={columns as unknown as Column<Record<string, unknown>>[]} searchable={false} />
            </TabsContent>
            <TabsContent value="active">
              <DataTable data={active as unknown as Record<string, unknown>[]} columns={columns as unknown as Column<Record<string, unknown>>[]} searchable={false} />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Loan detail dialog */}
      <Dialog open={viewOpen} onOpenChange={setViewOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Loan Details</DialogTitle></DialogHeader>
          {selected && (
            <div className="space-y-3 py-2 text-sm">
              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                <Avatar className="h-10 w-10"><AvatarFallback>{getInitials(selected.member)}</AvatarFallback></Avatar>
                <div>
                  <p className="font-semibold">{selected.member}</p>
                  <Badge variant={statusColors[selected.status] as 'success'} className="capitalize text-xs">{selected.status}</Badge>
                </div>
              </div>
              {[
                ['Loan Amount', formatCurrency(selected.amount)],
                ['Purpose', selected.purpose],
                ['Monthly Installment', formatCurrency(selected.monthly_installment)],
                ['Outstanding Balance', formatCurrency(selected.balance)],
                ['Application Date', formatDate(selected.applied_at)],
              ].map(([label, value]) => (
                <div key={label} className="flex justify-between py-1.5 border-b border-border last:border-0">
                  <span className="text-muted-foreground">{label}</span>
                  <span className="font-medium">{value}</span>
                </div>
              ))}
            </div>
          )}
          <DialogFooter>
            {selected?.status === 'pending' && (
              <>
                <Button variant="destructive" onClick={() => { handleAction(selected.id, 'reject'); setViewOpen(false) }}>Reject</Button>
                <Button onClick={() => { handleAction(selected.id, 'approve'); setViewOpen(false) }}>Approve</Button>
              </>
            )}
            {selected?.status !== 'pending' && <Button onClick={() => setViewOpen(false)}>Close</Button>}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
