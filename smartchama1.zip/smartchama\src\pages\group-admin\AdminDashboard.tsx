import React from 'react'
import { motion } from 'framer-motion'
import { Users, Wallet, Landmark, AlertTriangle, TrendingUp, CheckCircle, Clock, XCircle } from 'lucide-react'
import { StatsCard } from '@/components/shared/StatsCard'
import { PageHeader } from '@/components/shared/PageHeader'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { formatCurrency, formatDate, getInitials } from '@/lib/utils'
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend, BarChart, Bar
} from 'recharts'
import { useNavigate } from 'react-router-dom'

const monthlyData = [
  { month: 'Jan', contributions: 125000, loans: 80000, expenses: 20000 },
  { month: 'Feb', contributions: 130000, loans: 60000, expenses: 15000 },
  { month: 'Mar', contributions: 128000, loans: 90000, expenses: 25000 },
  { month: 'Apr', contributions: 135000, loans: 70000, expenses: 18000 },
  { month: 'May', contributions: 140000, loans: 85000, expenses: 22000 },
  { month: 'Jun', contributions: 145000, loans: 95000, expenses: 30000 },
  { month: 'Jul', contributions: 142000, loans: 75000, expenses: 20000 },
]

const loanStatusData = [
  { name: 'Active', value: 15, color: '#059669' },
  { name: 'Pending', value: 4, color: '#f59e0b' },
  { name: 'Defaulted', value: 2, color: '#ef4444' },
  { name: 'Repaid', value: 28, color: '#3b82f6' },
]

const recentMembers = [
  { name: 'Alice Wanjiku', joined: '2026-07-15', status: 'active', contributions: 35000 },
  { name: 'Bob Kipchoge', joined: '2026-07-10', status: 'active', contributions: 25000 },
  { name: 'Carol Achieng', joined: '2026-06-28', status: 'active', contributions: 40000 },
]

const pendingLoans = [
  { member: 'David Mwenda', amount: 75000, purpose: 'Business', applied: '2026-07-30' },
  { member: 'Eva Njoki', amount: 50000, purpose: 'Education', applied: '2026-07-28' },
]

export function AdminDashboard() {
  const navigate = useNavigate()

  return (
    <div className="space-y-6">
      <PageHeader
        title="Group Dashboard"
        description="Pamoja Savings Group — Overview & Analytics"
      />

      {/* Key stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { title: 'Total Members', value: '47', icon: Users, variant: 'primary' as const, trend: 6, trendLabel: 'vs last month' },
          { title: 'Total Savings', value: formatCurrency(2450000), icon: Wallet, variant: 'success' as const, trend: 12 },
          { title: 'Active Loans', value: '15', icon: Landmark, variant: 'warning' as const },
          { title: 'Outstanding Fines', value: formatCurrency(18500), icon: AlertTriangle, variant: 'danger' as const },
        ].map((s, i) => (
          <motion.div key={s.title} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}>
            <StatsCard {...s} />
          </motion.div>
        ))}
      </div>

      {/* Secondary stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatsCard title="Monthly Contributions" value={formatCurrency(142000)} icon={TrendingUp} variant="primary" trend={2.4} trendLabel="vs June" />
        <StatsCard title="Contributions This Month" value="38 / 47" icon={CheckCircle} variant="success" description="Members paid" />
        <StatsCard title="Pending Contributions" value="9" icon={Clock} variant="warning" description="Due this month" />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Monthly trend */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Financial Trend</CardTitle>
            <CardDescription>Monthly contributions, loans, and expenses</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <AreaChart data={monthlyData} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
                <defs>
                  <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#059669" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#059669" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="g2" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} tickFormatter={v => `${v / 1000}k`} />
                <Tooltip formatter={(v: number) => formatCurrency(v)} />
                <Legend />
                <Area type="monotone" dataKey="contributions" name="Contributions" stroke="#059669" fill="url(#g1)" strokeWidth={2} />
                <Area type="monotone" dataKey="loans" name="Loans" stroke="#3b82f6" fill="url(#g2)" strokeWidth={2} />
                <Area type="monotone" dataKey="expenses" name="Expenses" stroke="#ef4444" fill="none" strokeWidth={2} strokeDasharray="4 4" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Loan status pie */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Loan Portfolio</CardTitle>
            <CardDescription>Breakdown by status</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={loanStatusData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3} dataKey="value">
                  {loanStatusData.map((entry, i) => (
                    <Cell key={i} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend iconSize={10} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Bottom tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pending loan approvals */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-base">Pending Loan Approvals</CardTitle>
              <CardDescription>{pendingLoans.length} applications awaiting review</CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={() => navigate('/admin/loans')}>View All</Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {pendingLoans.map((loan, i) => (
                <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-muted/40">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-9 w-9">
                      <AvatarFallback className="text-xs">{getInitials(loan.member)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-medium">{loan.member}</p>
                      <p className="text-xs text-muted-foreground">{loan.purpose} · Applied {formatDate(loan.applied)}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-sm">{formatCurrency(loan.amount)}</p>
                    <div className="flex gap-1 mt-1">
                      <Button size="sm" className="h-6 px-2 text-xs"><CheckCircle className="h-3 w-3" /></Button>
                      <Button size="sm" variant="destructive" className="h-6 px-2 text-xs"><XCircle className="h-3 w-3" /></Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recent new members */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-base">Recent Members</CardTitle>
              <CardDescription>Latest additions to the group</CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={() => navigate('/admin/members')}>View All</Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentMembers.map((m, i) => (
                <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-muted/40">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-9 w-9">
                      <AvatarFallback className="text-xs">{getInitials(m.name)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-medium">{m.name}</p>
                      <p className="text-xs text-muted-foreground">Joined {formatDate(m.joined)}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold">{formatCurrency(m.contributions)}</p>
                    <Badge variant="success" className="text-xs">Active</Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
