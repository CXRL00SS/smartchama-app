import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'

// Layout
import { DashboardLayout } from '@/components/layout/DashboardLayout'

// Auth pages
import { LoginPage } from '@/pages/auth/LoginPage'
import { RegisterPage } from '@/pages/auth/RegisterPage'
import { ForgotPasswordPage } from '@/pages/auth/ForgotPasswordPage'

// Member pages
import { MemberDashboard } from '@/pages/member/MemberDashboard'
import { ContributionsPage } from '@/pages/member/ContributionsPage'
import { LoansPage } from '@/pages/member/LoansPage'
import { FinesPage } from '@/pages/member/FinesPage'
import { MeetingsPage } from '@/pages/member/MeetingsPage'
import { AnnouncementsPage } from '@/pages/member/AnnouncementsPage'
import { DocumentsPage } from '@/pages/member/DocumentsPage'
import { StatementsPage } from '@/pages/member/StatementsPage'
import { NotificationsPage } from '@/pages/member/NotificationsPage'
import { ProfilePage } from '@/pages/member/ProfilePage'
import { JoinGroupPage } from '@/pages/member/JoinGroupPage'

// Group Admin pages
import { AdminDashboard } from '@/pages/group-admin/AdminDashboard'
import { MembersPage } from '@/pages/group-admin/MembersPage'
import { AdminContributionsPage } from '@/pages/group-admin/AdminContributionsPage'
import { AdminLoansPage } from '@/pages/group-admin/AdminLoansPage'
import { AdminFinesPage } from '@/pages/group-admin/AdminFinesPage'
import { AdminMeetingsPage } from '@/pages/group-admin/AdminMeetingsPage'
import { AnalyticsPage } from '@/pages/group-admin/AnalyticsPage'
import { ReportsPage } from '@/pages/group-admin/ReportsPage'
import { AdminSettingsPage } from '@/pages/group-admin/AdminSettingsPage'
import { AppointRolesPage } from '@/pages/group-admin/AppointRolesPage'

// Super Admin pages
import { SuperAdminDashboard } from '@/pages/super-admin/SuperAdminDashboard'
import { SuperAdminFinesPage } from '@/pages/super-admin/SuperAdminFinesPage'
import { PlatformFeeSettingsPage } from '@/pages/super-admin/PlatformFeeSettingsPage'
import { AuditLogsPage } from '@/pages/super-admin/AuditLogsPage'

// New group admin pages
import { MeetingAttendancePage } from '@/pages/group-admin/MeetingAttendancePage'
import { FineDisputesPage } from '@/pages/group-admin/FineDisputesPage'

import type { UserRole } from '@/types'

// ─── Loading Screen ────────────────────────────────────────────────

function LoadingScreen() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="text-center space-y-4">
        <img
          src="/logo.png"
          alt="Smart Chama"
          className="h-20 object-contain mx-auto animate-pulse"
        />
        <p className="text-muted-foreground text-sm">Loading Smart Chama...</p>
      </div>
    </div>
  )
}

// ─── Protected Route ───────────────────────────────────────────────

interface ProtectedRouteProps {
  children: React.ReactNode
  allowedRoles?: UserRole[]
}

function ProtectedRoute({ children, allowedRoles }: ProtectedRouteProps) {
  const { user, loading, role } = useAuth()

  if (loading) return <LoadingScreen />
  if (!user) return <Navigate to="/auth/login" replace />

  if (allowedRoles && role && !allowedRoles.includes(role)) {
    const dest = role === 'super_admin' ? '/super-admin' : role === 'member' ? '/member' : '/admin'
    return <Navigate to={dest} replace />
  }

  return <>{children}</>
}

// ─── Root redirect ─────────────────────────────────────────────────

function RootRedirect() {
  const { user, loading, role } = useAuth()
  if (loading) return <LoadingScreen />
  if (!user) return <Navigate to="/auth/login" replace />

  switch (role) {
    case 'super_admin': return <Navigate to="/super-admin" replace />
    case 'group_admin':
    case 'chairperson':
    case 'treasurer':
    case 'secretary':
    case 'loan_committee':
      return <Navigate to="/admin" replace />
    default:
      return <Navigate to="/member" replace />
  }
}

// ─── App ──────────────────────────────────────────────────────────

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<RootRedirect />} />

      {/* Auth */}
      <Route path="/auth/login" element={<LoginPage />} />
      <Route path="/auth/register" element={<RegisterPage />} />
      <Route path="/auth/forgot-password" element={<ForgotPasswordPage />} />

      {/* Member */}
      <Route path="/member" element={
        <ProtectedRoute allowedRoles={['member', 'loan_committee']}>
          <DashboardLayout />
        </ProtectedRoute>
      }>
        <Route index element={<MemberDashboard />} />
        <Route path="contributions" element={<ContributionsPage />} />
        <Route path="loans" element={<LoansPage />} />
        <Route path="fines" element={<FinesPage />} />
        <Route path="meetings" element={<MeetingsPage />} />
        <Route path="announcements" element={<AnnouncementsPage />} />
        <Route path="documents" element={<DocumentsPage />} />
        <Route path="statements" element={<StatementsPage />} />
        <Route path="notifications" element={<NotificationsPage />} />
        <Route path="profile" element={<ProfilePage />} />
        <Route path="join-group" element={<JoinGroupPage />} />
      </Route>

      {/* Group Admin */}
      <Route path="/admin" element={
        <ProtectedRoute allowedRoles={['group_admin', 'chairperson', 'treasurer', 'secretary', 'loan_committee']}>
          <DashboardLayout />
        </ProtectedRoute>
      }>
        <Route index element={<AdminDashboard />} />
        <Route path="members" element={<MembersPage />} />
        <Route path="contributions" element={<AdminContributionsPage />} />
        <Route path="loans" element={<AdminLoansPage />} />
        <Route path="fines" element={<AdminFinesPage />} />
        <Route path="meetings" element={<AdminMeetingsPage />} />
        <Route path="announcements" element={<AnnouncementsPage />} />
        <Route path="documents" element={<DocumentsPage />} />
        <Route path="reports" element={<ReportsPage />} />
        <Route path="analytics" element={<AnalyticsPage />} />
        <Route path="settings" element={<AdminSettingsPage />} />
        <Route path="appoint-roles" element={<AppointRolesPage />} />
        <Route path="attendance" element={<MeetingAttendancePage />} />
        <Route path="disputes" element={<FineDisputesPage />} />
      </Route>

      {/* Super Admin */}
      <Route path="/super-admin" element={
        <ProtectedRoute allowedRoles={['super_admin']}>
          <DashboardLayout />
        </ProtectedRoute>
      }>
        <Route index element={<SuperAdminDashboard />} />
        <Route path="groups" element={<SuperAdminDashboard />} />
        <Route path="users" element={<SuperAdminDashboard />} />
        <Route path="fines" element={<SuperAdminFinesPage />} />
        <Route path="revenue" element={<SuperAdminFinesPage />} />
        <Route path="fee-settings" element={<PlatformFeeSettingsPage />} />
        <Route path="subscriptions" element={<SuperAdminDashboard />} />
        <Route path="analytics" element={<AnalyticsPage />} />
        <Route path="audit" element={<AuditLogsPage />} />
        <Route path="support" element={<SuperAdminDashboard />} />
        <Route path="settings" element={<AdminSettingsPage />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
