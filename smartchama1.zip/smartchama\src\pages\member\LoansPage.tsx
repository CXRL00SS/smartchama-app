import React, { useState } from 'react'
import { CreditCard, Plus, CheckCircle, Clock, AlertTriangle, TrendingDown } from 'lucide-react'
import { PageHeader } from '@/components/shared/PageHeader'
import { StatsCard } from '@/components/shared/StatsCard'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { formatCurrency, formatDate, calculateLoanSchedule } from '@/lib/utils'
import { toast } from 'sonner'

const activeLoan = {
  id: 'l1',
  amount: 50000,
  amount_paid: 22000,
  balance: 28000,
  monthly_installment: 3500,
  repayment_months: 12,
  interest_rate: 12,
  status: 'disbursed',
  purpose: 'Business capital',
  disbursed_at: '2026-01-15',
  due_date: '2027-01-15',
}

const loanHistory = [
  { id: 'l0', amount: 30000, status: 'repaid', purpose: 'School fees', disbursed_at: '2025-01-10', amount_paid: 30000 },
]

const repayments = [
  { date: '2026-07-25', amount: 3500, reference: 'MPE001' },
  { date: '2026-06-25', amount: 3500, reference: 'MPE002' },
  { date: '2026-05-25', amount: 3500, reference: 'MPE003' },
]

export function LoansPage() {
  const [applyOpen, setApplyOpen] = useState(false)
  const [repayOpen, setRepayOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [loanAmount, setLoanAmount] = useState('')
  const [loanMonths, setLoanMonths] = useState('12')
  const [loanPurpose, setLoanPurpose] = useState('')
  const [phone, setPhone] = useState('')

  const amount = parseFloat(loanAmount) || 0
  const months = parseInt(loanMonths)
  const schedule = amount > 0 ? calculateLoanSchedule(amount, 12, months) : null
  const repaymentProgress = (activeLoan.amount_paid / activeLoan.amount) * 100

  const handleApply = async () => {
    if (!loanAmount || !loanPurpose) { toast.error('Fill in all fields'); return }
    setLoading(true)
    await new Promise(r => setTimeout(r, 1500))
    setLoading(false)
    setApplyOpen(false)
    toast.success('Loan application submitted!', { description: 'Your application is under review.' })
  }

  const handleRepay = async () => {
    if (!phone) { toast.error('Enter your M-Pesa phone number'); return }
    setLoading(true)
    await new Promise(r => setTimeout(r, 1500))
    setLoading(false)
    setRepayOpen(false)
    toast.success('M-Pesa prompt sent!', { description: 'Complete payment on your phone.' })
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="My Loans"
        description="Manage loan applications and repayments"
        actions={
          <Button onClick={() => setApplyOpen(true)}>
            <Plus className="h-4 w-4" /> Apply for Loan
          </Button>
        }
      />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatsCard title="Outstanding Balance" value={formatCurrency(activeLoan.balance)} icon={CreditCard} variant="warning" />
        <StatsCard title="Amount Paid" value={formatCurrency(activeLoan.amount_paid)} icon={CheckCircle} variant="success" />
        <StatsCard title="Available Limit" value={formatCurrency(127500)} icon={TrendingDown} variant="primary" />
      </div>

      {/* Active loan */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Active Loan</CardTitle>
              <CardDescription>{activeLoan.purpose}</CardDescription>
            </div>
            <Badge variant="warning">Active</Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <p className="text-xs text-muted-foreground">Original Amount</p>
              <p className="font-semibold">{formatCurrency(activeLoan.amount)}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Balance</p>
              <p className="font-semibold text-orange-500">{formatCurrency(activeLoan.balance)}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Monthly Payment</p>
              <p className="font-semibold">{formatCurrency(activeLoan.monthly_installment)}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Due Date</p>
              <p className="font-semibold">{formatDate(activeLoan.due_date!)}</p>
            </div>
          </div>
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-muted-foreground">Repayment Progress</span>
              <span className="font-medium">{repaymentProgress.toFixed(0)}%</span>
            </div>
            <Progress value={repaymentProgress} className="h-3" />
          </div>
          <Button onClick={() => setRepayOpen(true)} className="w-full sm:w-auto">
            <CreditCard className="h-4 w-4" /> Make Repayment
          </Button>
        </CardContent>
      </Card>

      {/* Repayment history */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Repayment History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {repayments.map((r, i) => (
              <div key={i} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                <div>
                  <p className="text-sm font-medium">{formatCurrency(r.amount)}</p>
                  <p className="text-xs text-muted-foreground">{formatDate(r.date)}</p>
                </div>
                <code className="text-xs bg-muted px-2 py-0.5 rounded">{r.reference}</code>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Apply dialog */}
      <Dialog open={applyOpen} onOpenChange={setApplyOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Apply for a Loan</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label>Loan Amount (KES)</Label>
              <Input type="number" placeholder="50000" value={loanAmount} onChange={e => setLoanAmount(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Repayment Period</Label>
              <Select value={loanMonths} onValueChange={setLoanMonths}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {[3, 6, 9, 12, 18, 24].map(m => (
                    <SelectItem key={m} value={String(m)}>{m} months</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Purpose</Label>
              <Input placeholder="e.g. Business capital" value={loanPurpose} onChange={e => setLoanPurpose(e.target.value)} />
            </div>
            {schedule && (
              <div className="rounded-lg bg-muted/50 p-4 space-y-2 text-sm">
                <p className="font-medium text-foreground">Loan Summary</p>
                <div className="flex justify-between"><span className="text-muted-foreground">Monthly Payment</span><span className="font-semibold">{formatCurrency(schedule.monthlyInstallment)}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Total Interest</span><span className="font-semibold">{formatCurrency(schedule.totalInterest)}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Total Payable</span><span className="font-bold text-primary">{formatCurrency(schedule.totalPayable)}</span></div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setApplyOpen(false)}>Cancel</Button>
            <Button onClick={handleApply} loading={loading}>Submit Application</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Repay dialog */}
      <Dialog open={repayOpen} onOpenChange={setRepayOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Make Loan Repayment</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="rounded-lg bg-muted/50 p-4 space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">Monthly Installment</span><span className="font-semibold">{formatCurrency(activeLoan.monthly_installment)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Outstanding Balance</span><span className="font-semibold text-orange-500">{formatCurrency(activeLoan.balance)}</span></div>
            </div>
            <div className="space-y-2">
              <Label>M-Pesa Phone Number</Label>
              <Input type="tel" placeholder="0712 345 678" value={phone} onChange={e => setPhone(e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRepayOpen(false)}>Cancel</Button>
            <Button onClick={handleRepay} loading={loading} className="bg-[#00A550] hover:bg-[#008C44]">
              <CreditCard className="h-4 w-4" /> Pay via M-Pesa
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
