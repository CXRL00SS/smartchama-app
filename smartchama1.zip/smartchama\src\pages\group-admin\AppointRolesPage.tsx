/**
 * AppointRolesPage — Chairperson appoints roles to existing group members.
 * Secretary, Treasurer, Loan Committee, Group Admin.
 */

import React, { useState } from 'react'
import { doc, updateDoc } from 'firebase/firestore'
import { db } from '@/lib/firebase'
import { PageHeader } from '@/components/shared/PageHeader'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { getInitials, formatDate } from '@/lib/utils'
import { toast } from 'sonner'
import { Shield, Crown } from 'lucide-react'
import type { UserRole } from '@/types'

// Roles a Chairperson can appoint
const appointableRoles: { value: UserRole; label: string; emoji: string; description: string }[] = [
  { value: 'group_admin',    label: 'Group Admin',    emoji: '👑', description: 'Full group management access' },
  { value: 'secretary',      label: 'Secretary',      emoji: '📋', description: 'Manages meetings and minutes' },
  { value: 'treasurer',      label: 'Treasurer',      emoji: '💰', description: 'Manages finances and payments' },
  { value: 'loan_committee', label: 'Loan Committee', emoji: '🏦', description: 'Reviews and approves loans' },
  { value: 'member',         label: 'Member',         emoji: '👤', description: 'Regular member (remove role)' },
]

// Mock members — replace with real Firestore data
const mockMembers = [
  { id: 'm1', full_name: 'Alice Wanjiku',  email: 'alice@example.com', role: 'member' as UserRole,    joined_at: '2026-01-15', member_number: 'PAM-0001' },
  { id: 'm2', full_name: 'Bob Kipchoge',   email: 'bob@example.com',   role: 'treasurer' as UserRole, joined_at: '2026-01-15', member_number: 'PAM-0002' },
  { id: 'm3', full_name: 'Carol Achieng',  email: 'carol@example.com', role: 'secretary' as UserRole, joined_at: '2026-02-01', member_number: 'PAM-0003' },
  { id: 'm4', full_name: 'David Mwenda',   email: 'david@example.com', role: 'member' as UserRole,    joined_at: '2026-03-10', member_number: 'PAM-0004' },
  { id: 'm5', full_name: 'Eva Njoki',      email: 'eva@example.com',   role: 'loan_committee' as UserRole, joined_at: '2026-04-01', member_number: 'PAM-0005' },
]

const roleBadge: Record<UserRole, { label: string; variant: 'success' | 'gold' | 'info' | 'warning' | 'secondary' }> = {
  chairperson:    { label: 'Chairperson',    variant: 'gold' },
  group_admin:    { label: 'Group Admin',    variant: 'gold' },
  secretary:      { label: 'Secretary',      variant: 'info' },
  treasurer:      { label: 'Treasurer',      variant: 'success' },
  loan_committee: { label: 'Loan Committee', variant: 'warning' },
  member:         { label: 'Member',         variant: 'secondary' },
  super_admin:    { label: 'Super Admin',    variant: 'gold' },
}

export function AppointRolesPage() {
  const [members, setMembers] = useState(mockMembers)
  const [pendingChanges, setPendingChanges] = useState<Record<string, UserRole>>({})
  const [saving, setSaving] = useState<string | null>(null)

  const handleRoleChange = (memberId: string, newRole: UserRole) => {
    setPendingChanges(prev => ({ ...prev, [memberId]: newRole }))
  }

  const handleSave = async (memberId: string) => {
    const newRole = pendingChanges[memberId]
    if (!newRole) return

    setSaving(memberId)
    try {
      // Update in Firestore
      await updateDoc(doc(db, 'profiles', memberId), { role: newRole })
      // Update local state
      setMembers(prev => prev.map(m => m.id === memberId ? { ...m, role: newRole } : m))
      setPendingChanges(prev => { const p = { ...prev }; delete p[memberId]; return p })
      const roleLabel = appointableRoles.find(r => r.value === newRole)?.label
      toast.success(`Role updated`, { description: `${members.find(m => m.id === memberId)?.full_name} is now ${roleLabel}` })
    } catch (err) {
      toast.error('Failed to update role')
    } finally {
      setSaving(null)
    }
  }

  const currentRoles = {
    secretary:      members.find(m => m.role === 'secretary'),
    treasurer:      members.find(m => m.role === 'treasurer'),
    loan_committee: members.find(m => m.role === 'loan_committee'),
    group_admin:    members.find(m => m.role === 'group_admin'),
  }

  return (
    <div className="space-y-6 max-w-3xl">
      <PageHeader
        title="Appoint Roles"
        description="Assign responsibilities to your group members"
      />

      {/* Current role holders summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { role: 'secretary',      label: 'Secretary',      emoji: '📋' },
          { role: 'treasurer',      label: 'Treasurer',      emoji: '💰' },
          { role: 'loan_committee', label: 'Loan Committee', emoji: '🏦' },
          { role: 'group_admin',    label: 'Group Admin',    emoji: '👑' },
        ].map(({ role, label, emoji }) => {
          const holder = currentRoles[role as keyof typeof currentRoles]
          return (
            <Card key={role} className={!holder ? 'border-dashed opacity-60' : ''}>
              <CardContent className="p-3 text-center">
                <p className="text-xl mb-1">{emoji}</p>
                <p className="text-xs font-semibold text-muted-foreground">{label}</p>
                <p className="text-sm font-medium mt-1 truncate">
                  {holder ? holder.full_name.split(' ')[0] : 'Not assigned'}
                </p>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Member list with role assignment */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Group Members</CardTitle>
          <CardDescription>Click on a role to change it, then save</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="divide-y divide-border">
            {members.map(member => {
              const currentRole = pendingChanges[member.id] ?? member.role
              const hasPendingChange = !!pendingChanges[member.id]
              const badge = roleBadge[currentRole]

              return (
                <div key={member.id} className="flex items-center gap-4 py-4 first:pt-0 last:pb-0 flex-wrap">
                  <Avatar className="h-10 w-10 shrink-0">
                    <AvatarFallback>{getInitials(member.full_name)}</AvatarFallback>
                  </Avatar>

                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm">{member.full_name}</p>
                    <p className="text-xs text-muted-foreground">{member.email}</p>
                    <p className="text-xs text-muted-foreground">Joined {formatDate(member.joined_at)}</p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 flex-wrap">
                    {/* Current badge */}
                    <Badge variant={badge.variant}>{badge.label}</Badge>

                    {/* Role selector */}
                    {member.role !== 'chairperson' && (
                      <Select
                        value={currentRole}
                        onValueChange={(v) => handleRoleChange(member.id, v as UserRole)}
                      >
                        <SelectTrigger className="w-40 h-8 text-xs">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {appointableRoles.map(r => (
                            <SelectItem key={r.value} value={r.value}>
                              <span className="flex items-center gap-2">
                                <span>{r.emoji}</span>
                                <span>{r.label}</span>
                              </span>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}

                    {hasPendingChange && (
                      <Button
                        size="sm"
                        className="h-8 text-xs"
                        loading={saving === member.id}
                        onClick={() => handleSave(member.id)}
                      >
                        Save
                      </Button>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      <Card className="border-dashed">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Shield className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
            <div className="text-sm text-muted-foreground space-y-1">
              <p className="font-medium text-foreground">How role permissions work</p>
              <p><strong>Group Admin</strong> — can do everything except appoint roles</p>
              <p><strong>Treasurer</strong> — manages contributions, loans, and finances</p>
              <p><strong>Secretary</strong> — manages meetings, minutes, and documents</p>
              <p><strong>Loan Committee</strong> — reviews and approves/rejects loan applications</p>
              <p className="text-xs mt-2">Only you as Chairperson can appoint and change these roles.</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
