/**
 * Fine Payment Service
 *
 * Orchestrates the fine payment flow:
 * 1. Validate fine is payable
 * 2. Read current platform fee config
 * 3. Create a pending Payment record
 * 4. Initiate M-Pesa STK Push
 * 5. Return checkout request ID for status polling
 *
 * IMPORTANT SECURITY NOTES:
 * - Platform revenue is recorded only after verified server-side payment confirmation.
 * - A member clicking "Pay" never directly marks a payment as complete.
 * - The Cloud Function (mpesaCallback) handles payment verification and calls
 *   markFinePaid + recordPlatformRevenue atomically after provider confirmation.
 * - The platform fee (KSh 5) is only collected when fee is ENABLED in config.
 * - The fee is deducted from the chama's net receipt, not charged separately to member.
 * - Members see the breakdown (fine amount + platform fee) BEFORE confirming.
 */

import { doc, getDoc } from 'firebase/firestore'
import { db } from '@/lib/firebase'
import { initiateStkPush } from './mpesa'
import {
  createPaymentRecord,
  getPlatformFeeConfig,
  createAuditLog,
  COLLECTIONS,
} from './firestore'
import type { Fine } from '@/types'
import { normalizeKenyanPhone } from '@/lib/utils'

export interface FinePaymentBreakdown {
  fine_amount: number          // e.g. KSh 100
  platform_fee: number         // e.g. KSh 5 (0 if fee disabled)
  total_member_pays: number    // KSh 100 (fee deducted from chama side)
  chama_receives: number       // KSh 95
  fee_enabled: boolean
  fee_disclosure: string       // human-readable disclosure text
}

export interface StartFinePaymentResult {
  success: boolean
  paymentId?: string
  checkoutRequestId?: string
  breakdown?: FinePaymentBreakdown
  error?: string
}

/**
 * Get the payment breakdown before initiating payment.
 * Show this to the member so they understand all fees.
 */
export async function getFinePaymentBreakdown(fineAmount: number): Promise<FinePaymentBreakdown> {
  const config = await getPlatformFeeConfig()
  const fee = config?.is_enabled ? (config.fee_amount ?? 5) : 0

  return {
    fine_amount: fineAmount,
    platform_fee: fee,
    // Per spec: fee is deducted from chama's receipt, member pays face value
    total_member_pays: fineAmount,
    chama_receives: fineAmount - fee,
    fee_enabled: !!config?.is_enabled,
    fee_disclosure: fee > 0
      ? `A KSh ${fee} SmartChama platform service fee applies. This is deducted from the chama's net receipt. You pay KSh ${fineAmount}.`
      : 'No platform service fee currently applies.',
  }
}

/**
 * Start the fine payment process.
 * Creates a pending payment record then triggers M-Pesa STK Push.
 * Does NOT mark the payment complete — that happens via server-side callback.
 */
export async function startFinePayment(
  fine: Fine,
  phoneNumber: string,
  userId: string
): Promise<StartFinePaymentResult> {
  // 1. Guard: fine must be in a payable state
  if (!['approved', 'pending'].includes(fine.status)) {
    return { success: false, error: `Fine cannot be paid in its current status: ${fine.status}` }
  }

  // 2. Get fee config
  const config = await getPlatformFeeConfig()
  const platformFee = config?.is_enabled ? (config.fee_amount ?? 5) : 0

  // 3. Breakdown
  const breakdown: FinePaymentBreakdown = {
    fine_amount: fine.amount,
    platform_fee: platformFee,
    total_member_pays: fine.amount,
    chama_receives: fine.amount - platformFee,
    fee_enabled: !!config?.is_enabled,
    fee_disclosure: platformFee > 0
      ? `KSh ${platformFee} platform fee deducted from chama receipt. You pay KSh ${fine.amount}.`
      : 'No platform service fee.',
  }

  // 4. Create idempotency key
  const idempotencyKey = `fine_${fine.id}_${userId}_${Date.now()}`

  // 5. Create pending payment record in Firestore
  let paymentId: string
  try {
    paymentId = await createPaymentRecord({
      group_id: fine.group_id,
      member_id: fine.member_id,
      amount: fine.amount,
      currency: 'KES',
      payment_method: 'mpesa',
      reference_type: 'fine',
      reference_id: fine.id,
      status: 'pending',
      phone_number: normalizeKenyanPhone(phoneNumber),
      platform_fee: platformFee,
      platform_fee_collected: false,
      idempotency_key: idempotencyKey,
    })
  } catch (err) {
    return { success: false, error: 'Failed to create payment record. Please try again.' }
  }

  // 6. Initiate M-Pesa STK Push
  const stkResult = await initiateStkPush({
    phoneNumber,
    amount: fine.amount,
    accountReference: `FINE-${fine.id.slice(-8).toUpperCase()}`,
    transactionDesc: `SmartChama Fine Payment`,
    groupId: fine.group_id,
    memberId: fine.member_id,
    referenceType: 'fine',
    referenceId: fine.id,
  })

  if (!stkResult.success) {
    // Update payment record to failed
    const { updatePaymentStatus } = await import('./firestore')
    await updatePaymentStatus(paymentId, 'failed')
    return { success: false, error: stkResult.error ?? 'STK Push failed', breakdown }
  }

  // 7. Update payment record with checkout request ID
  const { updatePaymentStatus } = await import('./firestore')
  await updatePaymentStatus(paymentId, 'pending', undefined, {
    mpesa_checkout_request_id: stkResult.checkoutRequestId,
  })

  // 8. Audit log
  await createAuditLog({
    user_id: userId,
    group_id: fine.group_id,
    action: 'fine_payment_initiated',
    resource_type: 'payment',
    resource_id: paymentId,
    new_values: {
      fine_id: fine.id,
      amount: fine.amount,
      platform_fee: platformFee,
      checkout_request_id: stkResult.checkoutRequestId,
    },
  })

  return {
    success: true,
    paymentId,
    checkoutRequestId: stkResult.checkoutRequestId,
    breakdown,
  }
}
