import React from 'react'
import { Pin, Megaphone } from 'lucide-react'
import { PageHeader } from '@/components/shared/PageHeader'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { formatRelativeTime, getInitials } from '@/lib/utils'
import { cn } from '@/lib/utils'

const announcements = [
  {
    id: 'a1',
    title: '📅 August Meeting Confirmed',
    content: 'The August monthly meeting is confirmed for Saturday 15th August 2026 at 10:00 AM at Community Hall, Westlands. Please confirm your attendance.',
    is_pinned: true,
    created_at: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    author: { full_name: 'Jane Mwangi', role: 'Chairperson' },
  },
  {
    id: 'a2',
    title: '💰 Contribution Rate Remains KES 5,000',
    content: 'Following the July meeting resolution, the monthly contribution rate remains at KES 5,000. Members are reminded to pay by the last day of each month.',
    is_pinned: true,
    created_at: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    author: { full_name: 'Peter Otieno', role: 'Treasurer' },
  },
  {
    id: 'a3',
    title: 'Loan Applications Open for August',
    content: 'Loan applications for the August cycle are now open. Members wishing to apply must submit applications by August 10th. Maximum loan amount is 3× your total contributions.',
    is_pinned: false,
    created_at: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    author: { full_name: 'Sarah Kamau', role: 'Secretary' },
  },
  {
    id: 'a4',
    title: 'New Document: Updated Constitution',
    content: 'The updated group constitution has been uploaded to the documents section. All members are required to review and acknowledge the changes.',
    is_pinned: false,
    created_at: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
    author: { full_name: 'Jane Mwangi', role: 'Chairperson' },
  },
]

export function AnnouncementsPage() {
  const pinned = announcements.filter(a => a.is_pinned)
  const regular = announcements.filter(a => !a.is_pinned)

  return (
    <div className="space-y-6">
      <PageHeader title="Announcements" description="Important group updates and notices" />

      {pinned.length > 0 && (
        <div className="space-y-3">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide flex items-center gap-1">
            <Pin className="h-3.5 w-3.5" /> Pinned
          </h2>
          {pinned.map(a => (
            <AnnouncementCard key={a.id} announcement={a} />
          ))}
        </div>
      )}

      {regular.length > 0 && (
        <div className="space-y-3">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide flex items-center gap-1">
            <Megaphone className="h-3.5 w-3.5" /> Recent
          </h2>
          {regular.map(a => (
            <AnnouncementCard key={a.id} announcement={a} />
          ))}
        </div>
      )}
    </div>
  )
}

function AnnouncementCard({ announcement }: { announcement: typeof announcements[0] }) {
  return (
    <Card className={cn(announcement.is_pinned && 'border-primary/30 bg-primary/5')}>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <Avatar className="h-9 w-9 shrink-0">
            <AvatarFallback className="text-xs">{getInitials(announcement.author.full_name)}</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2 flex-wrap">
              <h3 className="font-semibold text-foreground text-sm">{announcement.title}</h3>
              <div className="flex items-center gap-2 shrink-0">
                {announcement.is_pinned && (
                  <Badge variant="gold" className="text-xs">
                    <Pin className="h-2.5 w-2.5 mr-1" /> Pinned
                  </Badge>
                )}
                <span className="text-xs text-muted-foreground">{formatRelativeTime(announcement.created_at)}</span>
              </div>
            </div>
            <p className="text-sm text-muted-foreground mt-1">{announcement.content}</p>
            <div className="mt-2 flex items-center gap-1">
              <span className="text-xs text-muted-foreground">{announcement.author.full_name}</span>
              <span className="text-xs text-muted-foreground">·</span>
              <Badge variant="secondary" className="text-xs">{announcement.author.role}</Badge>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
