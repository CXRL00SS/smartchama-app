import React, { useState } from 'react'
import { Save, Settings } from 'lucide-react'
import { PageHeader } from '@/components/shared/PageHeader'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { toast } from 'sonner'

export function AdminSettingsPage() {
  const [saving, setSaving] = useState(false)

  const [groupSettings, setGroupSettings] = useState({
    name: 'Pamoja Savings Group',
    description: 'A community savings group based in Nairobi',
    registration_number: 'CHM/2022/001234',
    currency: 'KES',
    timezone: 'Africa/Nairobi',
  })

  const [contributionSettings, setContributionSettings] = useState({
    frequency: 'monthly',
    amount: '5000',
    day: '31',
    grace_days: '3',
    late_penalty_type: 'fixed',
    late_penalty_value: '500',
  })

  const [loanSettings, setLoanSettings] = useState({
    interest_rate: '12',
    interest_type: 'reducing',
    max_multiplier: '3',
    repayment_months: '12',
    min_guarantors: '2',
    max_guarantors: '3',
  })

  const [meetingSettings, setMeetingSettings] = useState({
    frequency: 'monthly',
    day: '3',
    time: '10:00',
    venue: 'Community Hall, Westlands, Nairobi',
  })

  const handleSave = async () => {
    setSaving(true)
    await new Promise(r => setTimeout(r, 1200))
    setSaving(false)
    toast.success('Settings saved successfully')
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Group Settings"
        description="Configure your Chama rules and preferences"
        actions={
          <Button onClick={handleSave} loading={saving}>
            <Save className="h-4 w-4" /> Save Changes
          </Button>
        }
      />

      <Tabs defaultValue="general">
        <TabsList className="mb-4 flex-wrap">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="contributions">Contributions</TabsTrigger>
          <TabsTrigger value="loans">Loans</TabsTrigger>
          <TabsTrigger value="meetings">Meetings</TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          <Card>
            <CardHeader><CardTitle className="text-base">Group Information</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Group Name</Label>
                  <Input value={groupSettings.name} onChange={e => setGroupSettings(s => ({ ...s, name: e.target.value }))} />
                </div>
                <div className="space-y-2">
                  <Label>Registration Number</Label>
                  <Input value={groupSettings.registration_number} onChange={e => setGroupSettings(s => ({ ...s, registration_number: e.target.value }))} />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label>Description</Label>
                  <Input value={groupSettings.description} onChange={e => setGroupSettings(s => ({ ...s, description: e.target.value }))} />
                </div>
                <div className="space-y-2">
                  <Label>Currency</Label>
                  <Select value={groupSettings.currency} onValueChange={v => setGroupSettings(s => ({ ...s, currency: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="KES">KES — Kenyan Shilling</SelectItem>
                      <SelectItem value="UGX">UGX — Ugandan Shilling</SelectItem>
                      <SelectItem value="TZS">TZS — Tanzanian Shilling</SelectItem>
                      <SelectItem value="USD">USD — US Dollar</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Timezone</Label>
                  <Select value={groupSettings.timezone} onValueChange={v => setGroupSettings(s => ({ ...s, timezone: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Africa/Nairobi">Africa/Nairobi (EAT)</SelectItem>
                      <SelectItem value="Africa/Kampala">Africa/Kampala</SelectItem>
                      <SelectItem value="Africa/Dar_es_Salaam">Africa/Dar es Salaam</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="contributions">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Contribution Rules</CardTitle>
              <CardDescription>Set contribution amount, frequency, and penalties</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Frequency</Label>
                  <Select value={contributionSettings.frequency} onValueChange={v => setContributionSettings(s => ({ ...s, frequency: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="custom">Custom</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Amount (KES)</Label>
                  <Input type="number" value={contributionSettings.amount} onChange={e => setContributionSettings(s => ({ ...s, amount: e.target.value }))} />
                </div>
                <div className="space-y-2">
                  <Label>Due Day (of month)</Label>
                  <Input type="number" min="1" max="31" value={contributionSettings.day} onChange={e => setContributionSettings(s => ({ ...s, day: e.target.value }))} />
                </div>
                <div className="space-y-2">
                  <Label>Grace Period (days)</Label>
                  <Input type="number" min="0" value={contributionSettings.grace_days} onChange={e => setContributionSettings(s => ({ ...s, grace_days: e.target.value }))} />
                </div>
                <div className="space-y-2">
                  <Label>Late Penalty Type</Label>
                  <Select value={contributionSettings.late_penalty_type} onValueChange={v => setContributionSettings(s => ({ ...s, late_penalty_type: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fixed">Fixed Amount</SelectItem>
                      <SelectItem value="percentage">Percentage</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Late Penalty Value</Label>
                  <Input type="number" value={contributionSettings.late_penalty_value} onChange={e => setContributionSettings(s => ({ ...s, late_penalty_value: e.target.value }))} />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="loans">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Loan Rules</CardTitle>
              <CardDescription>Configure loan eligibility and interest rates</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Annual Interest Rate (%)</Label>
                  <Input type="number" value={loanSettings.interest_rate} onChange={e => setLoanSettings(s => ({ ...s, interest_rate: e.target.value }))} />
                </div>
                <div className="space-y-2">
                  <Label>Interest Calculation Method</Label>
                  <Select value={loanSettings.interest_type} onValueChange={v => setLoanSettings(s => ({ ...s, interest_type: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="reducing">Reducing Balance</SelectItem>
                      <SelectItem value="flat">Flat Rate</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Max Loan Multiplier (×contributions)</Label>
                  <Input type="number" min="1" max="10" value={loanSettings.max_multiplier} onChange={e => setLoanSettings(s => ({ ...s, max_multiplier: e.target.value }))} />
                </div>
                <div className="space-y-2">
                  <Label>Default Repayment Period (months)</Label>
                  <Input type="number" value={loanSettings.repayment_months} onChange={e => setLoanSettings(s => ({ ...s, repayment_months: e.target.value }))} />
                </div>
                <div className="space-y-2">
                  <Label>Minimum Guarantors Required</Label>
                  <Input type="number" min="0" value={loanSettings.min_guarantors} onChange={e => setLoanSettings(s => ({ ...s, min_guarantors: e.target.value }))} />
                </div>
                <div className="space-y-2">
                  <Label>Maximum Guarantors Allowed</Label>
                  <Input type="number" min="0" value={loanSettings.max_guarantors} onChange={e => setLoanSettings(s => ({ ...s, max_guarantors: e.target.value }))} />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="meetings">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Meeting Schedule</CardTitle>
              <CardDescription>Configure recurring meeting settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Meeting Frequency</Label>
                  <Select value={meetingSettings.frequency} onValueChange={v => setMeetingSettings(s => ({ ...s, frequency: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="biweekly">Every 2 Weeks</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Day (1=Mon ... 7=Sun)</Label>
                  <Input type="number" min="1" max="7" value={meetingSettings.day} onChange={e => setMeetingSettings(s => ({ ...s, day: e.target.value }))} />
                </div>
                <div className="space-y-2">
                  <Label>Meeting Time</Label>
                  <Input type="time" value={meetingSettings.time} onChange={e => setMeetingSettings(s => ({ ...s, time: e.target.value }))} />
                </div>
                <div className="space-y-2">
                  <Label>Default Venue</Label>
                  <Input value={meetingSettings.venue} onChange={e => setMeetingSettings(s => ({ ...s, venue: e.target.value }))} />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
