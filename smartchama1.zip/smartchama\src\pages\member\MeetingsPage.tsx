import React from 'react'
import { Calendar, MapPin, Clock, CheckCircle, XCircle, Users } from 'lucide-react'
import { PageHeader } from '@/components/shared/PageHeader'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { formatDate } from '@/lib/utils'

const meetings = [
  {
    id: 'm1', title: 'August Monthly Meeting', scheduled_at: '2026-08-15T10:00:00',
    venue: 'Community Hall, Nairobi', status: 'scheduled', agenda: ['Review July contributions', 'Loan applications review', 'AOB'],
    attendance: 'pending',
  },
  {
    id: 'm2', title: 'July Monthly Meeting', scheduled_at: '2026-07-18T10:00:00',
    venue: 'Community Hall, Nairobi', status: 'completed', agenda: ['Financial review', 'Loan approvals'],
    attendance: 'present', minutes: 'Minutes discussed July financials...',
  },
  {
    id: 'm3', title: 'June Monthly Meeting', scheduled_at: '2026-06-20T10:00:00',
    venue: 'Zoom (Online)', status: 'completed', agenda: ['Mid-year review', 'Investment proposal'],
    attendance: 'absent',
  },
]

const statusColors: Record<string, string> = {
  scheduled: 'info',
  ongoing: 'warning',
  completed: 'success',
  cancelled: 'destructive',
}

const attendanceColors: Record<string, string> = {
  present: 'success',
  absent: 'destructive',
  excused: 'warning',
  pending: 'secondary',
}

export function MeetingsPage() {
  return (
    <div className="space-y-6">
      <PageHeader title="Meetings" description="Scheduled and past Chama meetings" />

      <div className="space-y-4">
        {meetings.map(meeting => (
          <Card key={meeting.id} className="overflow-hidden">
            <CardContent className="p-0">
              <div className="flex flex-col sm:flex-row">
                {/* Date sidebar */}
                <div className="bg-primary/10 sm:w-24 flex sm:flex-col items-center justify-center p-4 gap-2 sm:gap-0">
                  <Calendar className="h-5 w-5 text-primary" />
                  <div className="text-center sm:mt-2">
                    <p className="text-2xl font-bold text-primary">
                      {new Date(meeting.scheduled_at).getDate()}
                    </p>
                    <p className="text-xs text-primary/70">
                      {new Date(meeting.scheduled_at).toLocaleString('en', { month: 'short' })}
                    </p>
                    <p className="text-xs text-primary/70">
                      {new Date(meeting.scheduled_at).getFullYear()}
                    </p>
                  </div>
                </div>

                {/* Content */}
                <div className="flex-1 p-4">
                  <div className="flex items-start justify-between gap-3 flex-wrap">
                    <div>
                      <h3 className="font-semibold text-foreground">{meeting.title}</h3>
                      <div className="flex flex-wrap items-center gap-3 mt-1 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3.5 w-3.5" />
                          {new Date(meeting.scheduled_at).toLocaleTimeString('en', { hour: '2-digit', minute: '2-digit' })}
                        </span>
                        <span className="flex items-center gap-1">
                          <MapPin className="h-3.5 w-3.5" />
                          {meeting.venue}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge variant={statusColors[meeting.status] as 'success'}>
                        {meeting.status.charAt(0).toUpperCase() + meeting.status.slice(1)}
                      </Badge>
                      {meeting.attendance !== 'pending' && (
                        <Badge variant={attendanceColors[meeting.attendance] as 'success'}>
                          {meeting.attendance.charAt(0).toUpperCase() + meeting.attendance.slice(1)}
                        </Badge>
                      )}
                    </div>
                  </div>

                  {/* Agenda */}
                  {meeting.agenda && meeting.agenda.length > 0 && (
                    <div className="mt-3">
                      <p className="text-xs font-medium text-muted-foreground mb-1">AGENDA</p>
                      <ul className="text-sm space-y-1">
                        {meeting.agenda.map((item, i) => (
                          <li key={i} className="flex items-center gap-2 text-muted-foreground">
                            <span className="w-4 h-4 rounded-full bg-muted flex items-center justify-center text-[10px] shrink-0">
                              {i + 1}
                            </span>
                            {item}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {meeting.minutes && (
                    <div className="mt-3">
                      <Button variant="outline" size="sm">
                        View Minutes
                      </Button>
                    </div>
                  )}

                  {meeting.status === 'scheduled' && (
                    <div className="mt-3 flex gap-2">
                      <Button size="sm">
                        <CheckCircle className="h-3.5 w-3.5" /> Confirm Attendance
                      </Button>
                      <Button size="sm" variant="outline">
                        <XCircle className="h-3.5 w-3.5" /> Send Apology
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
