/**
 * Firestore Service Layer
 * All database operations for Smart Chama
 */

import {
  collection, doc, getDoc, getDocs, addDoc, updateDoc, deleteDoc,
  query, where, orderBy, limit, onSnapshot, serverTimestamp,
  runTransaction, increment, Timestamp, writeBatch, setDoc,
} from 'firebase/firestore'
import { db } from '@/lib/firebase'
import type {
  Profile, ChamaGroup, GroupMember, Contribution,
  Loan, Fine, Meeting, Announcement, Document, Notification, Payment,
  FineRule, FineDispute, PlatformFeeConfig, PlatformRevenueLedger,
  Refund, MeetingAttendanceRecord, AuditLog,
} from '@/types'

// ─── Collections ──────────────────────────────────────────────────

export const COLLECTIONS = {
  PROFILES: 'profiles',
  GROUPS: 'groups',
  GROUP_SETTINGS: 'group_settings',
  GROUP_MEMBERS: 'group_members',
  CONTRIBUTIONS: 'contributions',
  LOANS: 'loans',
  LOAN_REPAYMENTS: 'loan_repayments',
  LOAN_GUARANTORS: 'loan_guarantors',
  FINES: 'fines',
  FINE_RULES: 'fine_rules',
  FINE_DISPUTES: 'fine_disputes',
  MEETINGS: 'meetings',
  MEETING_ATTENDANCE: 'meeting_attendance',
  PAYMENTS: 'payments',
  ANNOUNCEMENTS: 'announcements',
  DOCUMENTS: 'documents',
  NOTIFICATIONS: 'notifications',
  EXPENSES: 'expenses',
  INCOME: 'income',
  AUDIT_LOGS: 'audit_logs',
  PLATFORM_FEE_CONFIG: 'platform_fee_config',
  PLATFORM_REVENUE: 'platform_revenue',
  REFUNDS: 'refunds',
} as const

// ─── Profiles ─────────────────────────────────────────────────────

export async function getProfile(uid: string): Promise<Profile | null> {
  const snap = await getDoc(doc(db, COLLECTIONS.PROFILES, uid))
  if (!snap.exists()) return null
  return { id: snap.id, ...snap.data() } as Profile
}

export async function updateProfile(uid: string, data: Partial<Profile>) {
  await updateDoc(doc(db, COLLECTIONS.PROFILES, uid), {
    ...data,
    updated_at: serverTimestamp(),
  })
}

// ─── Groups ───────────────────────────────────────────────────────

export async function getGroup(groupId: string): Promise<ChamaGroup | null> {
  const snap = await getDoc(doc(db, COLLECTIONS.GROUPS, groupId))
  if (!snap.exists()) return null
  return { id: snap.id, ...snap.data() } as ChamaGroup
}

export async function getAllGroups(): Promise<ChamaGroup[]> {
  const snap = await getDocs(collection(db, COLLECTIONS.GROUPS))
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as ChamaGroup))
}

export async function createGroup(data: Omit<ChamaGroup, 'id' | 'created_at' | 'updated_at'>) {
  const ref = await addDoc(collection(db, COLLECTIONS.GROUPS), {
    ...data,
    created_at: serverTimestamp(),
    updated_at: serverTimestamp(),
  })
  return ref.id
}

// ─── Group Members ────────────────────────────────────────────────

export async function getGroupMembers(groupId: string): Promise<GroupMember[]> {
  const q = query(
    collection(db, COLLECTIONS.GROUP_MEMBERS),
    where('group_id', '==', groupId),
    where('is_active', '==', true)
  )
  const snap = await getDocs(q)
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as GroupMember))
}

export async function getMemberGroups(userId: string): Promise<GroupMember[]> {
  const q = query(
    collection(db, COLLECTIONS.GROUP_MEMBERS),
    where('user_id', '==', userId),
    where('is_active', '==', true)
  )
  const snap = await getDocs(q)
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as GroupMember))
}

// ─── Contributions ────────────────────────────────────────────────

export async function getMemberContributions(memberId: string): Promise<Contribution[]> {
  const q = query(
    collection(db, COLLECTIONS.CONTRIBUTIONS),
    where('member_id', '==', memberId),
    orderBy('due_date', 'desc')
  )
  const snap = await getDocs(q)
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as Contribution))
}

export async function getGroupContributions(groupId: string, limitCount = 50): Promise<Contribution[]> {
  const q = query(
    collection(db, COLLECTIONS.CONTRIBUTIONS),
    where('group_id', '==', groupId),
    orderBy('due_date', 'desc'),
    limit(limitCount)
  )
  const snap = await getDocs(q)
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as Contribution))
}

export async function recordContributionPayment(
  contributionId: string,
  paymentData: { paid_date: string; payment_method: string; transaction_ref: string }
) {
  await updateDoc(doc(db, COLLECTIONS.CONTRIBUTIONS, contributionId), {
    ...paymentData,
    status: 'paid',
    updated_at: serverTimestamp(),
  })
}

// ─── Loans ────────────────────────────────────────────────────────

export async function getMemberLoans(memberId: string): Promise<Loan[]> {
  const q = query(
    collection(db, COLLECTIONS.LOANS),
    where('member_id', '==', memberId),
    orderBy('applied_at', 'desc')
  )
  const snap = await getDocs(q)
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as Loan))
}

export async function getGroupLoans(groupId: string): Promise<Loan[]> {
  const q = query(
    collection(db, COLLECTIONS.LOANS),
    where('group_id', '==', groupId),
    orderBy('applied_at', 'desc')
  )
  const snap = await getDocs(q)
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as Loan))
}

export async function applyForLoan(data: Omit<Loan, 'id' | 'created_at' | 'updated_at'>) {
  const ref = await addDoc(collection(db, COLLECTIONS.LOANS), {
    ...data,
    status: 'pending',
    amount_paid: 0,
    created_at: serverTimestamp(),
    updated_at: serverTimestamp(),
  })
  return ref.id
}

export async function updateLoanStatus(
  loanId: string,
  status: string,
  extra: Record<string, unknown> = {}
) {
  await updateDoc(doc(db, COLLECTIONS.LOANS, loanId), {
    status,
    ...extra,
    updated_at: serverTimestamp(),
  })
}

// ─── Fines ────────────────────────────────────────────────────────

export async function getMemberFines(memberId: string): Promise<Fine[]> {
  const q = query(
    collection(db, COLLECTIONS.FINES),
    where('member_id', '==', memberId),
    orderBy('issued_at', 'desc')
  )
  const snap = await getDocs(q)
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as Fine))
}

export async function getGroupFines(groupId: string): Promise<Fine[]> {
  const q = query(
    collection(db, COLLECTIONS.FINES),
    where('group_id', '==', groupId),
    orderBy('issued_at', 'desc')
  )
  const snap = await getDocs(q)
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as Fine))
}

export async function issueFine(data: Omit<Fine, 'id'>) {
  const ref = await addDoc(collection(db, COLLECTIONS.FINES), {
    ...data,
    issued_at: serverTimestamp(),
  })
  return ref.id
}

// ─── Meetings ─────────────────────────────────────────────────────

export async function getGroupMeetings(groupId: string): Promise<Meeting[]> {
  const q = query(
    collection(db, COLLECTIONS.MEETINGS),
    where('group_id', '==', groupId),
    orderBy('scheduled_at', 'desc')
  )
  const snap = await getDocs(q)
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as Meeting))
}

export async function createMeeting(data: Omit<Meeting, 'id' | 'created_at'>) {
  const ref = await addDoc(collection(db, COLLECTIONS.MEETINGS), {
    ...data,
    created_at: serverTimestamp(),
  })
  return ref.id
}

// ─── Announcements ────────────────────────────────────────────────

export async function getGroupAnnouncements(groupId: string): Promise<Announcement[]> {
  const q = query(
    collection(db, COLLECTIONS.ANNOUNCEMENTS),
    where('group_id', '==', groupId),
    orderBy('created_at', 'desc'),
    limit(20)
  )
  const snap = await getDocs(q)
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as Announcement))
}

// ─── Documents ────────────────────────────────────────────────────

export async function getGroupDocuments(groupId: string): Promise<Document[]> {
  const q = query(
    collection(db, COLLECTIONS.DOCUMENTS),
    where('group_id', '==', groupId),
    orderBy('created_at', 'desc')
  )
  const snap = await getDocs(q)
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as Document))
}

// ─── Notifications ────────────────────────────────────────────────

export function subscribeToNotifications(
  userId: string,
  callback: (notifications: Notification[]) => void
) {
  const q = query(
    collection(db, COLLECTIONS.NOTIFICATIONS),
    where('user_id', '==', userId),
    orderBy('created_at', 'desc'),
    limit(30)
  )
  return onSnapshot(q, (snap) => {
    callback(snap.docs.map(d => ({ id: d.id, ...d.data() } as unknown as Notification)))
  })
}

export async function markNotificationRead(notificationId: string) {
  await updateDoc(doc(db, COLLECTIONS.NOTIFICATIONS, notificationId), { is_read: true })
}

// ─── Payments ─────────────────────────────────────────────────────

export async function createPaymentRecord(data: Omit<Payment, 'id' | 'created_at'>) {
  const ref = await addDoc(collection(db, COLLECTIONS.PAYMENTS), {
    ...data,
    status: 'pending',
    created_at: serverTimestamp(),
  })
  return ref.id
}

// FIXED: was missing doc(db, collection, id) — was calling updateDoc on the collection ref
export async function updatePaymentStatus(
  paymentId: string,
  status: string,
  mpesaReceiptNumber?: string,
  extra: Record<string, unknown> = {}
) {
  await updateDoc(doc(db, COLLECTIONS.PAYMENTS, paymentId), {
    status,
    ...(mpesaReceiptNumber ? { mpesa_receipt_number: mpesaReceiptNumber } : {}),
    ...(status === 'completed' ? { completed_at: serverTimestamp() } : {}),
    ...extra,
  })
}

// ─── Fine Rules ───────────────────────────────────────────────────

export async function getGroupFineRules(groupId: string): Promise<FineRule[]> {
  const q = query(
    collection(db, COLLECTIONS.FINE_RULES),
    where('group_id', '==', groupId),
    where('is_active', '==', true)
  )
  const snap = await getDocs(q)
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as FineRule))
}

export async function createFineRule(data: Omit<FineRule, 'id' | 'created_at' | 'updated_at'>) {
  const ref = await addDoc(collection(db, COLLECTIONS.FINE_RULES), {
    ...data,
    created_at: serverTimestamp(),
    updated_at: serverTimestamp(),
  })
  return ref.id
}

export async function updateFineRule(ruleId: string, data: Partial<FineRule>) {
  await updateDoc(doc(db, COLLECTIONS.FINE_RULES, ruleId), {
    ...data,
    updated_at: serverTimestamp(),
  })
}

// ─── Fine CRUD (extended) ─────────────────────────────────────────

export async function updateFineStatus(
  fineId: string,
  status: Fine['status'],
  extra: Record<string, unknown> = {}
) {
  await updateDoc(doc(db, COLLECTIONS.FINES, fineId), {
    status,
    ...extra,
    updated_at: serverTimestamp(),
  })
}

export async function waiveFine(fineId: string, waivedBy: string, reason: string) {
  await updateDoc(doc(db, COLLECTIONS.FINES, fineId), {
    status: 'waived',
    waived_by: waivedBy,
    waive_reason: reason,
    waived_at: serverTimestamp(),
  })
}

export async function approveFine(fineId: string, approvedBy: string) {
  await updateDoc(doc(db, COLLECTIONS.FINES, fineId), {
    status: 'approved',
    approved_by: approvedBy,
    approved_at: serverTimestamp(),
  })
}

export async function cancelFine(fineId: string, cancelledBy: string, reason: string) {
  await updateDoc(doc(db, COLLECTIONS.FINES, fineId), {
    status: 'cancelled',
    cancelled_by: cancelledBy,
    cancel_reason: reason,
    cancelled_at: serverTimestamp(),
  })
}

// Mark fine paid after confirmed payment — called only after Firestore/server confirms success
export async function markFinePaid(
  fineId: string,
  paymentId: string,
  mpesaRef: string,
  platformFee: number
) {
  await updateDoc(doc(db, COLLECTIONS.FINES, fineId), {
    status: 'paid',
    payment_id: paymentId,
    transaction_ref: mpesaRef,
    platform_fee: platformFee,
    platform_fee_collected: platformFee > 0,
    paid_at: serverTimestamp(),
  })
}

// ─── Fine Disputes ────────────────────────────────────────────────

export async function raiseDispute(data: Omit<FineDispute, 'id' | 'created_at' | 'updated_at'>) {
  const ref = await addDoc(collection(db, COLLECTIONS.FINE_DISPUTES), {
    ...data,
    status: 'open',
    created_at: serverTimestamp(),
    updated_at: serverTimestamp(),
  })
  // Mark fine as disputed
  await updateDoc(doc(db, COLLECTIONS.FINES, data.fine_id), {
    status: 'disputed',
    dispute_id: ref.id,
  })
  return ref.id
}

export async function getGroupDisputes(groupId: string): Promise<FineDispute[]> {
  const q = query(
    collection(db, COLLECTIONS.FINE_DISPUTES),
    where('group_id', '==', groupId),
    orderBy('created_at', 'desc')
  )
  const snap = await getDocs(q)
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as FineDispute))
}

export async function getMemberDisputes(memberId: string): Promise<FineDispute[]> {
  const q = query(
    collection(db, COLLECTIONS.FINE_DISPUTES),
    where('member_id', '==', memberId),
    orderBy('created_at', 'desc')
  )
  const snap = await getDocs(q)
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as FineDispute))
}

export async function resolveDispute(
  disputeId: string,
  fineId: string,
  resolution: 'resolved_cancelled' | 'resolved_upheld',
  reviewedBy: string,
  notes: string
) {
  const batch = writeBatch(db)
  batch.update(doc(db, COLLECTIONS.FINE_DISPUTES, disputeId), {
    status: resolution,
    reviewed_by: reviewedBy,
    reviewed_at: serverTimestamp(),
    resolution_notes: notes,
    updated_at: serverTimestamp(),
  })
  if (resolution === 'resolved_cancelled') {
    batch.update(doc(db, COLLECTIONS.FINES, fineId), {
      status: 'cancelled',
      cancel_reason: notes,
      cancelled_at: serverTimestamp(),
    })
  } else {
    batch.update(doc(db, COLLECTIONS.FINES, fineId), {
      status: 'approved',
      dispute_resolved_upheld: true,
    })
  }
  await batch.commit()
}

// ─── Meeting Attendance ───────────────────────────────────────────

export async function recordAttendance(records: Omit<MeetingAttendanceRecord, 'id'>[]) {
  const batch = writeBatch(db)
  records.forEach(record => {
    const ref = doc(collection(db, COLLECTIONS.MEETING_ATTENDANCE))
    batch.set(ref, {
      ...record,
      created_at: serverTimestamp(),
      updated_at: serverTimestamp(),
    })
  })
  await batch.commit()
}

export async function getMeetingAttendance(meetingId: string): Promise<MeetingAttendanceRecord[]> {
  const q = query(
    collection(db, COLLECTIONS.MEETING_ATTENDANCE),
    where('meeting_id', '==', meetingId)
  )
  const snap = await getDocs(q)
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as MeetingAttendanceRecord))
}

export async function correctAttendanceRecord(
  attendanceId: string,
  correctedBy: string,
  newStatus: MeetingAttendanceRecord['status'],
  reason: string
) {
  await updateDoc(doc(db, COLLECTIONS.MEETING_ATTENDANCE, attendanceId), {
    status: newStatus,
    manually_corrected: true,
    corrected_by: correctedBy,
    correction_reason: reason,
    updated_at: serverTimestamp(),
  })
}

// ─── Platform Fee Config ──────────────────────────────────────────

// Singleton document with a fixed ID
const FEE_CONFIG_DOC_ID = 'current'

export async function getPlatformFeeConfig(): Promise<PlatformFeeConfig | null> {
  const snap = await getDoc(doc(db, COLLECTIONS.PLATFORM_FEE_CONFIG, FEE_CONFIG_DOC_ID))
  if (!snap.exists()) return null
  return { id: snap.id, ...snap.data() } as PlatformFeeConfig
}

export async function setPlatformFeeConfig(
  config: Omit<PlatformFeeConfig, 'id' | 'created_at'>,
  changedBy: string
): Promise<void> {
  const existing = await getPlatformFeeConfig()

  // Write new config as a history entry first (immutable ledger of config changes)
  await addDoc(collection(db, COLLECTIONS.PLATFORM_FEE_CONFIG), {
    ...config,
    changed_by: changedBy,
    previous_amount: existing?.fee_amount ?? null,
    created_at: serverTimestamp(),
  })

  // Update the singleton "current" document
  await setDoc(doc(db, COLLECTIONS.PLATFORM_FEE_CONFIG, FEE_CONFIG_DOC_ID), {
    ...config,
    changed_by: changedBy,
    previous_amount: existing?.fee_amount ?? null,
    created_at: serverTimestamp(),
  })
}

export async function getPlatformFeeHistory(): Promise<PlatformFeeConfig[]> {
  const q = query(
    collection(db, COLLECTIONS.PLATFORM_FEE_CONFIG),
    orderBy('created_at', 'desc'),
    limit(50)
  )
  const snap = await getDocs(q)
  return snap.docs
    .filter(d => d.id !== FEE_CONFIG_DOC_ID) // exclude the singleton
    .map(d => ({ id: d.id, ...d.data() } as PlatformFeeConfig))
}

// ─── Platform Revenue Ledger ──────────────────────────────────────

/**
 * Record a platform revenue entry.
 * ONLY called after verified successful payment — never from frontend button click.
 * Uses idempotency_key to prevent duplicate entries.
 */
export async function recordPlatformRevenue(
  entry: Omit<PlatformRevenueLedger, 'id' | 'created_at'>
): Promise<string> {
  // Check idempotency — if same key exists, return existing ID
  const existingQ = query(
    collection(db, COLLECTIONS.PLATFORM_REVENUE),
    where('idempotency_key', '==', entry.idempotency_key)
  )
  const existingSnap = await getDocs(existingQ)
  if (!existingSnap.empty) {
    return existingSnap.docs[0].id // idempotent — return existing entry
  }

  const ref = await addDoc(collection(db, COLLECTIONS.PLATFORM_REVENUE), {
    ...entry,
    created_at: serverTimestamp(),
  })
  return ref.id
}

export async function getPlatformRevenueSummary(filters?: {
  startDate?: string
  endDate?: string
  groupId?: string
}) {
  let q = query(
    collection(db, COLLECTIONS.PLATFORM_REVENUE),
    where('status', '==', 'collected'),
    orderBy('collected_at', 'desc'),
    limit(500)
  )

  const snap = await getDocs(q)
  const entries = snap.docs.map(d => ({ id: d.id, ...d.data() } as PlatformRevenueLedger))

  let filtered = entries
  if (filters?.groupId) filtered = filtered.filter(e => e.group_id === filters.groupId)
  if (filters?.startDate) filtered = filtered.filter(e => e.collected_at >= filters.startDate!)
  if (filters?.endDate) filtered = filtered.filter(e => e.collected_at <= filters.endDate!)

  const gross = filtered.reduce((s, e) => s + e.platform_fee_amount, 0)
  const refunds = filtered.filter(e => e.status === 'refunded').reduce((s, e) => s + e.platform_fee_amount, 0)
  const providerCosts = filtered.reduce((s, e) => s + (e.provider_charge ?? 0), 0)
  const net = gross - refunds - providerCosts
  const totalPayments = filtered.length
  const today = new Date().toISOString().slice(0, 10)
  const weekAgo = new Date(Date.now() - 7 * 86400000).toISOString().slice(0, 10)
  const monthStart = new Date().toISOString().slice(0, 7) + '-01'

  return {
    entries: filtered,
    gross_revenue: gross,
    total_refunds: refunds,
    provider_costs: providerCosts,
    net_revenue: net,
    total_successful_payments: totalPayments,
    revenue_today: filtered.filter(e => e.collected_at?.startsWith(today)).reduce((s, e) => s + e.platform_fee_amount, 0),
    revenue_this_week: filtered.filter(e => e.collected_at >= weekAgo).reduce((s, e) => s + e.platform_fee_amount, 0),
    revenue_this_month: filtered.filter(e => e.collected_at >= monthStart).reduce((s, e) => s + e.platform_fee_amount, 0),
  }
}

// ─── Audit Logs ───────────────────────────────────────────────────

export async function createAuditLog(entry: Omit<AuditLog, 'id' | 'created_at'>) {
  await addDoc(collection(db, COLLECTIONS.AUDIT_LOGS), {
    ...entry,
    created_at: serverTimestamp(),
  })
}

export async function getAuditLogs(
  filters?: { groupId?: string; userId?: string; limit?: number }
): Promise<AuditLog[]> {
  const constraints: Parameters<typeof query>[1][] = [orderBy('created_at', 'desc')]
  if (filters?.groupId) constraints.push(where('group_id', '==', filters.groupId))
  if (filters?.userId) constraints.push(where('user_id', '==', filters.userId))
  if (filters?.limit) constraints.push(limit(filters.limit))
  else constraints.push(limit(100))

  const q = query(collection(db, COLLECTIONS.AUDIT_LOGS), ...constraints)
  const snap = await getDocs(q)
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as AuditLog))
}
