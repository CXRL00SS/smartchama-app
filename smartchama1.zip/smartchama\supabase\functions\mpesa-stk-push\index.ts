/**
 * Supabase Edge Function: mpesa-stk-push
 * 
 * Handles M-Pesa Daraja API STK Push in a secure server-side environment.
 * Credentials are stored as Supabase secrets, never exposed to the client.
 * 
 * Deploy with:
 *   supabase functions deploy mpesa-stk-push
 *   supabase secrets set MPESA_CONSUMER_KEY=xxx MPESA_CONSUMER_SECRET=xxx ...
 */

import { serve } from 'https://deno.land/std@0.177.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: CORS_HEADERS })
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    )

    // Verify the user is authenticated
    const authHeader = req.headers.get('Authorization')!
    const { data: { user }, error: authError } = await supabase.auth.getUser(
      authHeader.replace('Bearer ', '')
    )

    if (authError || !user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      })
    }

    const body = await req.json()
    const {
      phone_number,
      amount,
      account_reference,
      transaction_desc,
      group_id,
      member_id,
      reference_type,
      reference_id,
    } = body

    // Validate inputs
    if (!phone_number || !amount || amount < 1) {
      return new Response(JSON.stringify({ error: 'Invalid parameters' }), {
        status: 400,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      })
    }

    // Get M-Pesa credentials from environment
    const consumerKey = Deno.env.get('MPESA_CONSUMER_KEY')!
    const consumerSecret = Deno.env.get('MPESA_CONSUMER_SECRET')!
    const shortcode = Deno.env.get('MPESA_SHORTCODE')!
    const passkey = Deno.env.get('MPESA_PASSKEY')!
    const callbackUrl = Deno.env.get('MPESA_CALLBACK_URL')!
    const mpesaEnv = Deno.env.get('MPESA_ENV') || 'sandbox'

    const baseUrl = mpesaEnv === 'production'
      ? 'https://api.safaricom.co.ke'
      : 'https://sandbox.safaricom.co.ke'

    // Step 1: Get OAuth token
    const credentials = btoa(`${consumerKey}:${consumerSecret}`)
    const tokenResponse = await fetch(`${baseUrl}/oauth/v1/generate?grant_type=client_credentials`, {
      headers: { Authorization: `Basic ${credentials}` },
    })

    if (!tokenResponse.ok) {
      throw new Error('Failed to obtain M-Pesa access token')
    }

    const { access_token } = await tokenResponse.json()

    // Step 2: Generate timestamp and password
    const timestamp = new Date().toISOString().replace(/[^0-9]/g, '').slice(0, 14)
    const passwordRaw = `${shortcode}${passkey}${timestamp}`
    const password = btoa(passwordRaw)

    // Step 3: Initiate STK Push
    const stkPayload = {
      BusinessShortCode: shortcode,
      Password: password,
      Timestamp: timestamp,
      TransactionType: 'CustomerPayBillOnline',
      Amount: amount,
      PartyA: phone_number,
      PartyB: shortcode,
      PhoneNumber: phone_number,
      CallBackURL: callbackUrl,
      AccountReference: account_reference,
      TransactionDesc: transaction_desc,
    }

    const stkResponse = await fetch(`${baseUrl}/mpesa/stkpush/v1/processrequest`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${access_token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(stkPayload),
    })

    const stkData = await stkResponse.json()

    if (stkData.ResponseCode !== '0') {
      throw new Error(stkData.errorMessage || 'STK Push failed')
    }

    // Step 4: Log the pending payment in the database
    await supabase.from('payments').insert({
      group_id,
      member_id,
      amount,
      currency: 'KES',
      payment_method: 'mpesa',
      reference_type,
      reference_id,
      status: 'pending',
      mpesa_checkout_request_id: stkData.CheckoutRequestID,
      phone_number,
      created_at: new Date().toISOString(),
    })

    return new Response(JSON.stringify(stkData), {
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
    })
  } catch (error) {
    console.error('STK Push error:', error)
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
    })
  }
})
